package com.zcore.util;

import java.util.Objects;

public final class VString {
    private final String string;

    public VString(String string) {
        this.string = string;
    }

    public String string() {
        return this.string != null ? this.string : "";
    }

    public int codePointAt(int index) {
        String value = string();
        if (index < 0 || index >= value.length()) {
            return -1;
        }
        return Character.codePointAt(value, index);
    }

    @Override
    public String toString() {
        return string();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof VString other)) return false;
        return Objects.equals(string(), other.string());
    }

    @Override
    public int hashCode() {
        return Objects.hash(string());
    }
}
