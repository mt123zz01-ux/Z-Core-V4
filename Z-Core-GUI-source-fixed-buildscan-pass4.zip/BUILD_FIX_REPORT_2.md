# Z-Core GUI Source - Build Fix Pass 2

Fix batch based on GitHub Actions screenshot from 2026-05-08.

## Fixed compile errors visible in screenshot

- `AccountManager.java`
  - Removed obsolete `Session.AccountType.LEGACY` argument.
  - Updated `Session` construction for Minecraft/Yarn 1.21.11: `Session(username, uuid, accessToken, xuid, clientId)`.

- `HotbarMixin.java`
  - Replaced private field access `inventory.selectedSlot` with public API `inventory.getSelectedSlot()`.

- `CapeRendererMixin.java`
  - Replaced removed `SkinTextures#capeTexture()` with `SkinTextures#cape()`.
  - Replaced removed `PlayerEntityRenderState#name` with `PlayerEntityRenderState#playerName.getString()`.
  - Replaced Authlib `GameProfile#getName()` with `GameProfile#name()`.

- `AbstractClientPlayerEntityMixin.java`
  - Replaced Authlib `GameProfile#getName()` with `GameProfile#name()`.
  - Replaced old `SkinTextures` record components:
    - `texture()` -> `body()`
    - `textureUrl()` removed
    - cape/elytra now use `AssetInfo.TextureAssetInfo`.

- `ScoreboardMixin.java`
  - Replaced invalid `mc.player.getScoreboard()` with `mc.world.getScoreboard()`.

- `ClientUtility.java`
  - Replaced `SharedConstants.getGameVersion().getName()` with `SharedConstants.getGameVersion().name()`.

- `MathUtil.java`
  - Removed old `RenderSystem#setShaderColor(...)` calls that no longer exist in 1.21.11 GUI path.
  - Kept wrapped drawing execution compile-safe.

## Static scan after fix

No remaining active source references found for:

- `Session.AccountType`
- `inventory.selectedSlot`
- `capeTexture()`
- `PlayerEntityRenderState#name`
- `GameProfile#getName()`
- `SkinTextures#texture()` / `textureUrl()` in active code
- `ClientPlayerEntity#getScoreboard()`
- `GameVersion#getName()`
- `RenderSystem#setShaderColor(...)`

Note: a few old API names may still appear inside commented-out code blocks and do not affect compilation.

## Build note

The local sandbox cannot download Gradle/Minecraft dependencies because DNS/network access to `services.gradle.org` is blocked. Please run the GitHub Action or:

```bash
./gradlew clean build --stacktrace
```

If it still fails, send the raw text log around the first `error:` entry.
