# Build Fix Report 4

## Fixed

- Removed the invalid Loom include rule:
  - `include fileTree(dir: 'libs', include: ['*.jar'])`
- This fixes the Gradle failure at `:processIncludeJars`:
  - `Attempted to nest artifact MediaPlayerInfo.jar which is not a module component and has no capabilities`
- Kept the local `libs/MediaPlayerInfo.jar` on the compile classpath with `implementation fileTree(...)`.
- Bundled local helper jar contents through the normal `jar` task instead of Loom `include`, while excluding signature/manifest files to avoid duplicate or invalid metadata.

## Static checks performed

- Verified there is no active `include fileTree(...)` rule left in `build.gradle`.
- Re-scanned the source for the old Java/Minecraft API patterns from previous build logs.
- Repacked and tested the ZIP archive with `unzip -t`.

## Note

Full Gradle build could not be executed inside the sandbox because the environment cannot resolve `services.gradle.org`.
