# Z-Core GUI Source Build Fix Report

## What was fixed

- Updated GUI matrix rendering code for Minecraft/Fabric 1.21.11:
  - `DrawContext#getMatrices()` now uses `Matrix3x2fStack` in 2D GUI rendering.
  - Replaced old `push()` / `pop()` calls with `pushMatrix()` / `popMatrix()`.
  - Replaced old 3-argument GUI `translate` / `scale` calls with 2D variants.
  - Replaced old Quaternion-based GUI rotation calls with `Matrix3x2fStack#rotate`.
- Updated render tick code:
  - Replaced removed `getTickDelta(false)` with `getTickProgress(false)`.
  - Replaced removed frame-duration calls with `getDynamicDeltaTicks()` where appropriate.
- Updated texture code for Minecraft 1.21.11:
  - Replaced removed `NativeImageBackedTexture(NativeImage)` usages with the current supplier-name constructor.
  - Removed active `getGlId()` and `setFilter(...)` usages that are no longer compatible.
- Fixed Gradle setup:
  - Added Maven Central and Fabric Maven repositories.
  - Changed Guava from `modImplementation` to normal `implementation`.
  - Removed unused Kotlin dependencies.
  - Included local `libs/*.jar` files so `MediaPlayerInfo.jar` is available at runtime.
  - Fixed the archive license rename property.
- Changed `fabric.mod.json` environment to `client`, because this source is a client GUI mod and imports client-only Minecraft classes.

## Scans performed

- Scanned source for old 1.21.11-incompatible GUI matrix calls.
- Scanned source for old render tick methods.
- Scanned source for removed texture methods such as `getGlId()` and `setFilter(...)`.
- Ran a Java parser-style syntax scan. The sandbox cannot download Minecraft/Fabric/Lombok dependencies, so full compilation was not possible here, but the scan no longer reports syntax-shape errors after the patches.

## Build note

The full Gradle build must be run in an environment with internet access because the Gradle wrapper and Minecraft/Fabric dependencies need to be downloaded.

Recommended command:

```bash
./gradlew clean build --stacktrace
```

On Windows:

```bat
gradlew.bat clean build --stacktrace
```
