package dev.zcore.utils.rotation;

public record Rotation(float yaw, float pitch) {}