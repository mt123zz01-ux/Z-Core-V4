package dev.zcore.utils.player;

import static dev.zcore.utils.client.IMinecraft.mc;

public class MoveUtil {
    public static float speedSqrt() {
        if (mc == null || mc.player == null) return 0.0F;

        double dx = mc.player.getX() - mc.player.lastX;
        double dz = mc.player.getZ() - mc.player.lastZ;
        return (float) Math.sqrt(dx * dx + dz * dz);
    }
}
