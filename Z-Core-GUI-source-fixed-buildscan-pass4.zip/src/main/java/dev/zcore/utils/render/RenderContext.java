package dev.zcore.utils.render;

import dev.zcore.utils.render.text.Font;
import lombok.Getter;
import lombok.Setter;
import net.minecraft.client.gui.DrawContext;

import static dev.zcore.utils.client.IMinecraft.mc;

@Setter
@Getter
public class RenderContext {
    private DrawContext context;
    private double mouseX = 0, mouseY = 0;

    private static final ThreadLocal<Boolean> IS_TAB_OR_SCOREBOARD = ThreadLocal.withInitial(() -> false);

    public static void setTabOrScoreboard(boolean value) { IS_TAB_OR_SCOREBOARD.set(value); }
    public static boolean isTabOrScoreboard() { return IS_TAB_OR_SCOREBOARD.get(); }
    public static void withTabOrScoreboard(Runnable runnable) {
        boolean was = IS_TAB_OR_SCOREBOARD.get();
        IS_TAB_OR_SCOREBOARD.set(true);
        try { runnable.run(); } finally { IS_TAB_OR_SCOREBOARD.set(was); }
    }

    public RenderContext(DrawContext context) { this.context = context; }

    private static int ix(float v) { return Math.round(v); }

    public void drawRect(float x, float y, float width, float height, float radius, ColorRGBA color) {
        context.fill(ix(x), ix(y), ix(x + width), ix(y + height), color.getRGB());
    }

    public void drawRect(float x, float y, float width, float height,
                         float radiusTopLeft, float radiusBottomLeft,
                         float radiusBottomRight, float radiusTopRight, ColorRGBA color) {
        drawRect(x, y, width, height, 0, color);
    }

    public void drawRect(float x, float y, float width, float height, float radius, ColorRGBA color, float smoothness) {
        drawRect(x, y, width, height, radius, color);
    }

    public void drawRect(float x, float y, float width, float height, float radius,
                         ColorRGBA color, ColorRGBA color2, ColorRGBA color3, ColorRGBA color4) {
        drawRect(x, y, width, height, radius, color);
    }

    public void drawTexture(float x, float y, float width, float height, float radius, ColorRGBA color,
                            float u, float v, float texWidth, float texHeight, int textureId) {
        drawRect(x, y, width, height, radius, color);
    }

    public void drawTexture(float x, float y, float width, float height, float radius, ColorRGBA color,
                            float u, float v, float texWidth, float texHeight, int textureId, float smoothness) {
        drawTexture(x, y, width, height, radius, color, u, v, texWidth, texHeight, textureId);
    }

    public void drawTexture(float x, float y, float width, float height, float radius,
                            ColorRGBA color, ColorRGBA color2, ColorRGBA color3, ColorRGBA color4,
                            float u, float v, float texWidth, float texHeight, int textureId) {
        drawRect(x, y, width, height, radius, color);
    }

    public void drawBlur(float x, float y, float width, float height, float radius, float blur, ColorRGBA color) {
        drawRect(x, y, width, height, radius, color);
    }

    public void drawBlur(float x, float y, float width, float height, float radius, float blur, ColorRGBA color, float smoothness) {
        drawBlur(x, y, width, height, radius, blur, color);
    }

    public void drawBlur(float x, float y, float width, float height, float radius, float blur,
                         ColorRGBA color, ColorRGBA color2, ColorRGBA color3, ColorRGBA color4) {
        drawRect(x, y, width, height, radius, color);
    }

    public void drawBorder(float x, float y, float width, float height, float radius, float thickness, ColorRGBA color) {
        int t = Math.max(1, Math.round(thickness));
        context.fill(ix(x), ix(y), ix(x + width), ix(y + t), color.getRGB());
        context.fill(ix(x), ix(y + height - t), ix(x + width), ix(y + height), color.getRGB());
        context.fill(ix(x), ix(y), ix(x + t), ix(y + height), color.getRGB());
        context.fill(ix(x + width - t), ix(y), ix(x + width), ix(y + height), color.getRGB());
    }

    public void drawBorder(float x, float y, float width, float height, float radius, float thickness,
                           ColorRGBA color, float innersmoothness, float outersmoothnes) {
        drawBorder(x, y, width, height, radius, thickness, color);
    }

    public void drawBorder(float x, float y, float width, float height, float radius, float thickness,
                           ColorRGBA color, ColorRGBA color2, ColorRGBA color3, ColorRGBA color4) {
        drawBorder(x, y, width, height, radius, thickness, color);
    }

    public void drawText(String text, Font font, float x, float y, float size, ColorRGBA color) {
        if (mc != null && mc.textRenderer != null && text != null) {
            context.drawText(mc.textRenderer, text, ix(x), ix(y), color.getRGB(), false);
        }
    }

    public void drawText(String text, Font font, float x, float y, float size, float thickness, ColorRGBA color) {
        drawText(text, font, x, y, size, color);
    }

    public void drawStyledRect(float x, float y, float width, float height, float radius, double alpha) {
        drawRect(x, y, width, height, radius, ColorRGBA.of(255, 255, 255, (int) ((255 * 0.03) * alpha)));
        drawBorder(x, y, width, height, radius, 1f, ColorRGBA.of(255, 255, 255, (int) ((255 * 0.05) * alpha)));
    }
}
