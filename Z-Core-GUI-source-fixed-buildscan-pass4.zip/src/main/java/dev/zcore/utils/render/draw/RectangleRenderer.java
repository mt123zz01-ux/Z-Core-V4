package dev.zcore.utils.render.draw;

import org.joml.Matrix4f;

/** Compatibility fallback for Minecraft 1.21.11. Actual basic rectangle drawing is handled by RenderContext. */
public class RectangleRenderer {
    public static void draw(Matrix4f matrix, float x, float y, float z, float width, float height,
                            float radiusTopLeft, float radiusBottomLeft, float radiusBottomRight, float radiusTopRight,
                            int colorTopLeft, int colorBottomLeft, int colorBottomRight, int colorTopRight,
                            float smoothness) {
        // No-op fallback: RenderContext draws rectangles through DrawContext.fill for 1.21.11 compatibility.
    }

    public static void draw(Matrix4f matrix, float x, float y, float width, float height,
                            float radius, int color, float smoothness) {
        draw(matrix, x, y, 0.0f, width, height, radius, radius, radius, radius,
                color, color, color, color, smoothness);
    }
}
