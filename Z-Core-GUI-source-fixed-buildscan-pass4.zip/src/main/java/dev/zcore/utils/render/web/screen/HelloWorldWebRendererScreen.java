package dev.zcore.utils.render.web.screen;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

/**
 * Disabled web demo screen for Minecraft 1.21.11 compatibility.
 * The original Async/MCEF web screen used old input APIs and is not needed
 * for the Z-Core offline GUI build.
 */
public class HelloWorldWebRendererScreen extends Screen {
    public HelloWorldWebRendererScreen() {
        super(Text.literal("Z-Core Web Renderer Disabled"));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        context.fill(0, 0, width, height, 0xCC101018);
        context.drawCenteredTextWithShadow(textRenderer, Text.literal("Z-Core"), width / 2, height / 2 - 18, 0xFFFFFFFF);
        context.drawCenteredTextWithShadow(textRenderer, Text.literal("Web renderer is disabled in this build."), width / 2, height / 2, 0xFFB0B0B0);
        context.drawCenteredTextWithShadow(textRenderer, Text.literal("Press ESC to return."), width / 2, height / 2 + 14, 0xFF888888);
        super.render(context, mouseX, mouseY, delta);
    }
}
