package dev.zcore.utils.render.draw;

import org.joml.Matrix4f;

/** Compatibility fallback for Minecraft 1.21.11. Basic borders are handled by RenderContext. */
public class BorderRenderer {
    public static void draw(Matrix4f matrix, float x, float y, float width, float height, float radius,
                            int color, float thickness, float innerSmoothness, float outerSmoothness) {
        // No-op fallback.
    }

    public static void draw(Matrix4f matrix, float x, float y, float z, float width, float height,
                            float radiusTopLeft, float radiusBottomLeft, float radiusBottomRight, float radiusTopRight,
                            int colorTopLeft, int colorBottomLeft, int colorBottomRight, int colorTopRight,
                            float thickness, float innerSmoothness, float outerSmoothness) {
        // No-op fallback.
    }
}
