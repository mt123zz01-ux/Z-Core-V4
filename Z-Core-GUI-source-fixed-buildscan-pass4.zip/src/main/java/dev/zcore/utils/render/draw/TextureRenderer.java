package dev.zcore.utils.render.draw;

import org.joml.Matrix4f;

/** Compatibility fallback for Minecraft 1.21.11. */
public class TextureRenderer {
    public static void draw(Matrix4f matrix, float x, float y, float width, float height, float radius,
                            int colorTopLeft, int colorBottomLeft, int colorBottomRight, int colorTopRight,
                            float u, float v, float texWidth, float texHeight, int textureId, float smoothness) {
        // No-op fallback.
    }

    public static void draw(Matrix4f matrix, float x, float y, float z, float width, float height,
                            float radiusTopLeft, float radiusBottomLeft, float radiusBottomRight, float radiusTopRight,
                            int colorTopLeft, int colorBottomLeft, int colorBottomRight, int colorTopRight,
                            float u, float v, float texWidth, float texHeight, int textureId, float smoothness) {
        // No-op fallback.
    }
}
