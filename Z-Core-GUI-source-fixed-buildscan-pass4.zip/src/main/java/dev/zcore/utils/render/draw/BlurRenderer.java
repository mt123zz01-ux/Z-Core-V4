package dev.zcore.utils.render.draw;

import org.joml.Matrix4f;

/** Compatibility fallback for Minecraft 1.21.11. */
public class BlurRenderer {
    public static void draw(Matrix4f matrix, float x, float y, float width, float height, float radius,
                            int colorTopLeft, int colorBottomLeft, int colorBottomRight, int colorTopRight,
                            float blur, float smoothness) {
        // No-op fallback.
    }
}
