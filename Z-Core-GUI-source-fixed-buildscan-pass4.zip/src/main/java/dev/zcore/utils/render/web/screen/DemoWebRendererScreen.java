package dev.zcore.utils.render.web.screen;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

/**
 * Disabled web demo screen for Minecraft 1.21.11 compatibility.
 * Kept as a stub so old references compile without bringing MCEF input APIs.
 */
public class DemoWebRendererScreen extends Screen {
    private final String url;

    public DemoWebRendererScreen(String url) {
        super(Text.literal("Z-Core Web Demo Disabled"));
        this.url = url == null ? "" : url;
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        context.fill(0, 0, width, height, 0xCC101018);
        context.drawCenteredTextWithShadow(textRenderer, Text.literal("Z-Core"), width / 2, height / 2 - 24, 0xFFFFFFFF);
        context.drawCenteredTextWithShadow(textRenderer, Text.literal("Web demo is disabled in this build."), width / 2, height / 2 - 6, 0xFFB0B0B0);
        if (!url.isBlank()) {
            context.drawCenteredTextWithShadow(textRenderer, Text.literal(url), width / 2, height / 2 + 10, 0xFF888888);
        }
        context.drawCenteredTextWithShadow(textRenderer, Text.literal("Press ESC to return."), width / 2, height / 2 + 26, 0xFF888888);
        super.render(context, mouseX, mouseY, delta);
    }
}
