package dev.zcore.utils.render.draw;

import dev.zcore.utils.render.text.Font;
import org.joml.Matrix4f;

/** Compatibility fallback for Minecraft 1.21.11. Actual text drawing is handled by RenderContext. */
public class TextRenderer {
    public static void draw(Matrix4f matrix, float x, float y, float z, Font font, String text,
                            float size, float thickness, float smoothness, float spacing, int color,
                            int outlineColor, float outlineThickness) {
        // No-op fallback.
    }

    public static void draw(Matrix4f matrix, float x, float y, Font font, String text,
                            float size, float thickness, float smoothness, float spacing, int color) {
        draw(matrix, x, y, 0.0f, font, text, size, thickness, smoothness, spacing, color, 0, 0.0f);
    }
}
