package dev.zcore.utils.render.web;

/** Disabled compatibility shim for Minecraft 1.21.11. */
final class McefWebRendererEngine implements WebRendererEngine {
    McefWebRendererEngine() {}
    @Override
    public boolean isAvailable() { return false; }
    @Override
    public WebRendererInstance create(WebRendererConfig config) {
        return NoOpWebRendererEngine.INSTANCE.create(config);
    }
}
