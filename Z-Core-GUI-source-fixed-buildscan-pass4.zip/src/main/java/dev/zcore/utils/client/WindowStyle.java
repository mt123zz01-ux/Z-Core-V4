package dev.zcore.utils.client;

public class WindowStyle {
    public static void darkmode(long windowHandle) {
        // Disabled for cross-platform compatibility.
    }

    public static void defaultmode(long windowHandle) {
        // Disabled for cross-platform compatibility.
    }

    public static boolean isLinux() {
        String os = System.getProperty("os.name", "").toLowerCase();
        return os.contains("linux") || os.contains("nix") || os.contains("nux") || os.contains("aix");
    }
}
