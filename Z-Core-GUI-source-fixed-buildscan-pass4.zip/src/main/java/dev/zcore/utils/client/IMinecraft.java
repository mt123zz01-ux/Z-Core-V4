package dev.zcore.utils.client;

import dev.zcore.ZCore;
import dev.zcore.manager.ModuleManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.util.Window;

public interface IMinecraft {
    ModuleManager moduleManager = ZCore.getInstance().moduleManager;
    MinecraftClient mc = MinecraftClient.getInstance();
    ZCore zcore = ZCore.getInstance();
    Window mw = mc.getWindow();
    RenderTickCounter tickCounter = mc.getRenderTickCounter();
}