package dev.zcore.utils.client;

public class Constants {
    public static final String CLIENT_NAME = "Z-Core";
    public static final String BUILD = "1.21.11";
    public static final String PREFIX = "◈ Z-Core » ";
    public static final String PREFIX_TITLE = "Z-Core » ";
    public static final String IRC_TITLE = "◈ Z-Core • IRC » ";
    public static final String SUPPORT = "";
    public static final String TELEGRAM = "";
    public static final String SITES = "";
    public static final String ISBANNED = "false";

    public static final String SERVER = "";
    public static final String CONFIG_SERVER_URL = "";
    public static final String IRC_SERVER_URL = "";
    public static final String FRIEND_SERVER_URL = "";
    public static final String WEATHER_SERVER_URL = "";

    public static final String API_KEY = "";
    public static final String CONFIG_API_KEY = "";
    public static final String IRC_API_KEY = "";
    public static final String SECRET_KEY = "";
    public static final String IRC_SECRET_KEY = "";
    public static final String FRIENDS_SECRET_KEY = "";
    public static final String FRIENDS_API_KEY = "";
}
