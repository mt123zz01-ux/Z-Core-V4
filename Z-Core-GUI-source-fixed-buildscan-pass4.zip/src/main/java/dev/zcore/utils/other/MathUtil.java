package dev.zcore.utils.other;

import lombok.experimental.UtilityClass;
import org.joml.Matrix3x2fStack;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.ColorHelper;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Vector3d;

import java.util.concurrent.ThreadLocalRandom;

import static dev.zcore.utils.client.IMinecraft.mc;
import static dev.zcore.utils.client.IMinecraft.tickCounter;

@UtilityClass
public class MathUtil {
    public double PI2 = Math.PI * 2;

    public static boolean isHovered(float mouseX, float mouseY, float x, float y, float width, float height) {
        return mouseX > x && mouseX < x + width && mouseY > y && mouseY < y + height;
    }

    public static boolean isHovered(double mouseX, double mouseY, float x, float y, float width, float height) {
        return mouseX > x && mouseX < x + width && mouseY > y && mouseY < y + height;
    }

    public static float lerp(float a, float b, float t) {
        return a + t * (b - a);
    }

    public double computeGcd() {
        return (Math.pow(mc.options.getMouseSensitivity().getValue() * 0.6 + 0.2, 3.0)) * 1.2;
    }

    public int getRandom(int min, int max) {
        return (int) getRandom((float) min, (float) max + 1);
    }

    public float getRandom(float min, float max) {
        return (float) getRandom(min, (double) max);
    }

    public double getRandom(double min, double max) {
        if (min == max) {
            return min;
        } else {
            if (min > max) {
                double d = min;
                min = max;
                max = d;
            }

            return ThreadLocalRandom.current().nextDouble(min, max);
        }
    }

    public void scale(Matrix3x2fStack stack, float x, float y, float scale, Runnable data) {
        if (scale != 1) {
            float scale2 = 0.5F + scale / 2;
            stack.pushMatrix();
            stack.translate(x, y);
            stack.scale(scale2, scale2);
            stack.translate(-x, -y);
            setAlpha(scale, data);
            stack.popMatrix();
        } else {
            data.run();
        }
    }

    public void scale(Matrix3x2fStack stack, float x, float y, float scaleX, float scaleY, Runnable data) {
        float sumScale = scaleX * scaleY;
        if (sumScale != 1) {
            stack.pushMatrix();
            stack.translate(x, y);
            stack.scale(scaleX, scaleY);
            stack.translate(-x, -y);
            setAlpha(sumScale, data);
            stack.popMatrix();
        } else {
            data.run();
        }
    }

    public float blinking(double speed, float f) {
        float red = (float) (System.currentTimeMillis() % speed / (speed / f));
        if (red > f / 2) red = f - red;
        return red;
    }

    public float textScrolling(float textWidth) {
        int speed = (int) (textWidth * 75);
        return (float) MathHelper.clamp((System.currentTimeMillis() % speed * Math.PI / speed), 0, 1) * textWidth;
    }

    public void setAlpha(float alpha, Runnable data) {
        setColor(1.0F, 1.0F, 1.0F, alpha, data);
    }

    public void setColor(float red, float green, float blue, float alpha, Runnable data) {
        // Minecraft 1.21.11 removed the old global RenderSystem shader color path for GUI rendering.
        // Keep the wrapped drawing call compile-safe; per-vertex/text alpha is handled by the render helpers.
        data.run();
    }

    public double round(double num, double increment) {
        double rounded = Math.round(num / increment) * increment;
        return Math.round(rounded * 100.0) / 100.0;
    }

    public int floorNearestMulN(int x, int n) {
        return n * (int) Math.floor((double) x / (double) n);
    }

    public int getRed(int hex) {
        return hex >> 16 & 255;
    }

    public int getGreen(int hex) {
        return hex >> 8 & 255;
    }

    public int getBlue(int hex) {
        return hex & 255;
    }

    public int getAlpha(int hex) {
        return hex >> 24 & 255;
    }

    public int applyOpacity(int color, float opacity) {
        return ColorHelper.getArgb((int) (getAlpha(color) * opacity / 255), getRed(color), getGreen(color), getBlue(color));
    }

    public Vec3d cosSin(int i, int size, double width) {
        int index = Math.min(i, size);
        float cos = (float) (Math.cos(index * MathUtil.PI2 / size) * width);
        float sin = (float) (-Math.sin(index * MathUtil.PI2 / size) * width);
        return new Vec3d(cos, 0, sin);
    }

    public double absSinAnimation(double input) {
        return Math.abs(1 + Math.sin(input)) / 2;
    }

    public Vector3d interpolate(Vector3d prevPos, Vector3d pos) {
        return new Vector3d(interpolate(prevPos.x, pos.x), interpolate(prevPos.y, pos.y), interpolate(prevPos.z, pos.z));
    }

    public Vec3d interpolate(Vec3d prevPos, Vec3d pos) {
        return new Vec3d(interpolate(prevPos.x, pos.x), interpolate(prevPos.y, pos.y), interpolate(prevPos.z, pos.z));
    }

    public Vec3d interpolate(Entity entity) {
        if (entity == null) return Vec3d.ZERO;
        return new Vec3d(interpolate(entity.lastX, entity.getX()), interpolate(entity.lastY, entity.getY()), interpolate(entity.lastZ, entity.getZ()));
    }

    public float interpolate(float prev, float orig) {
        return MathHelper.lerp(tickCounter.getTickProgress(false), prev, orig);
    }

    public double interpolate(double prev, double orig) {
        return MathHelper.lerp(tickCounter.getTickProgress(false), prev, orig);
    }

    public int interpolateSmooth(double smooth, int prev, int orig) {
        return (int) MathHelper.lerp(tickCounter.getDynamicDeltaTicks() / smooth, prev, orig);
    }

    public float interpolateSmooth(double smooth, float prev, float orig) {
        return (float) MathHelper.lerp(tickCounter.getDynamicDeltaTicks() / smooth, prev, orig);
    }

    public double interpolateSmooth(double smooth, double prev, double orig) {
        return MathHelper.lerp(tickCounter.getDynamicDeltaTicks() / smooth, prev, orig);
    }

    public static final Vec3d getRotationVector(float pitch, float yaw) {
        float f = pitch * ((float)Math.PI / 180F);
        float g = -yaw * ((float)Math.PI / 180F);
        float h = MathHelper.cos(g);
        float i = MathHelper.sin(g);
        float j = MathHelper.cos(f);
        float k = MathHelper.sin(f);
        return new Vec3d((double)(i * j), (double)(-k), (double)(h * j));
    }

    public static double sin(double value) {
        return Math.sin(value);
    }

    public static double cos(double value) {
        return Math.cos(value);
    }
}
