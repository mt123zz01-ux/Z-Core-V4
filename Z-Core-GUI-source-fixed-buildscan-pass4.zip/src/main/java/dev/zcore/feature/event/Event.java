package dev.zcore.feature.event;

import dev.zcore.ZCore;
import lombok.Getter;
import lombok.Setter;

@Getter
public class Event {
    private boolean cancelled = false;
    @Setter
    private boolean pre;

    public Event(boolean pre) {
        this.pre = pre;
    }

    public void hook() {
        ZCore.getInstance().eventBus.post(this);
    }

    public void cancel() {
        cancelled = true;
    }
}