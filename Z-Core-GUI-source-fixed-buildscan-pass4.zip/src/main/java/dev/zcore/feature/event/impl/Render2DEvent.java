package dev.zcore.feature.event.impl;

import dev.zcore.feature.event.Event;
import dev.zcore.utils.render.RenderContext;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class Render2DEvent extends Event {
    private RenderContext context;

    public Render2DEvent(RenderContext context) {
        super(false);
        this.context = context;
    }
}