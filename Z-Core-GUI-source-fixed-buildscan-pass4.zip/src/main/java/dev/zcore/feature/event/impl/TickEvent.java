package dev.zcore.feature.event.impl;

import dev.zcore.feature.event.Event;

public class TickEvent extends Event {
    public TickEvent(boolean pre) {
        super(pre);
    }
}