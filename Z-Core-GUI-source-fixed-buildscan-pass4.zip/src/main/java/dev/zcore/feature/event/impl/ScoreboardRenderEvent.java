package dev.zcore.feature.event.impl;

import dev.zcore.feature.event.Event;
import dev.zcore.utils.render.RenderContext;
import lombok.Getter;
import lombok.Setter;
import net.minecraft.scoreboard.ScoreboardObjective;

@Setter
@Getter
public class ScoreboardRenderEvent extends Event {
    private RenderContext context;
    private ScoreboardObjective objective;

    public ScoreboardRenderEvent(RenderContext context, ScoreboardObjective objective) {
        super(false);
        this.context = context;
        this.objective = objective;
    }
}
