package dev.zcore.feature.event.impl;

import dev.zcore.feature.event.Event;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class KeyEvent extends Event {
    private int key, action, modifiers;

    public KeyEvent(int key, int action, int modifiers) {
        super(false);
        this.key = key;
        this.action = action;
        this.modifiers = modifiers;
    }
}