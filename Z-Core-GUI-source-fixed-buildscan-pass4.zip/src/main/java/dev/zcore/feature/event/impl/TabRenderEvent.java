package dev.zcore.feature.event.impl;

import dev.zcore.feature.event.Event;
import dev.zcore.utils.render.RenderContext;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class TabRenderEvent extends Event {
    private RenderContext context;
    private int scaledWindowWidth;

    public TabRenderEvent(RenderContext context, int scaledWindowWidth) {
        super(false);
        this.context = context;
        this.scaledWindowWidth = scaledWindowWidth;
    }
}
