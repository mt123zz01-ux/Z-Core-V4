package dev.zcore.feature.event.impl;

import dev.zcore.feature.event.Event;
import lombok.Getter;

@Getter
public class ChatSendEvent extends Event {
    private final String message;

    public ChatSendEvent(String message) {
        super(true);
        this.message = message;
    }
}
