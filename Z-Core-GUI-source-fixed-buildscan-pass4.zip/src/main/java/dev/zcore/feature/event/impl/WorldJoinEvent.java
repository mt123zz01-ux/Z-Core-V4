package dev.zcore.feature.event.impl;

import dev.zcore.feature.event.Event;

public class WorldJoinEvent extends Event {
    public WorldJoinEvent() {
        super(false);
    }
}
