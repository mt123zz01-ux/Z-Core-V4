package dev.zcore.feature.module.impl.misc;

import dev.zcore.feature.module.api.Category;
import dev.zcore.feature.module.api.Module;
import dev.zcore.feature.module.api.ModuleAnnotation;
import dev.zcore.utils.client.ClientUtility;
import org.lwjgl.glfw.GLFW;

@ModuleAnnotation(name = "AntiFT", category = Category.MISC, description = "Replace funtime text with ZCore")
public class AntiFT extends Module {

    public AntiFT() {
        super();
        setState(false);
        this.setKey(GLFW.GLFW_KEY_F4);
    }

    @Override
    public void onEnable() {
        ClientUtility.sendMessage("AntiFT enabled");
    }

    @Override
    public void onDisable() {
        ClientUtility.sendMessage("AntiFT disabled");
    }
}
