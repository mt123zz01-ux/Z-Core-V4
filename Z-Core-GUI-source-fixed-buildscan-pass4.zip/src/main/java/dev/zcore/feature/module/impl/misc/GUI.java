package dev.zcore.feature.module.impl.misc;

import com.google.common.eventbus.Subscribe;
import dev.zcore.feature.event.impl.Render2DEvent;
import dev.zcore.feature.module.api.Category;
import dev.zcore.feature.module.api.Module;
import dev.zcore.feature.module.api.ModuleAnnotation;
import dev.zcore.utils.animation.Animation;
import dev.zcore.utils.animation.Easing;
import org.lwjgl.glfw.GLFW;

@ModuleAnnotation(name = "GUI", category = Category.MISC, description = "GUI")
public class GUI extends Module {
    private final Animation scaleAnimation = new Animation(250, Easing.BAKEK_SIZE);



    @Override
    public void onEnable() {
       // ClientUtility.sendMessage("enable");
        scaleAnimation.setTarget(1.0f);
    }

    @Override
    public void onDisable() {
      //  ClientUtility.sendMessage("disable");
        scaleAnimation.setTarget(0.0f);
    }

    @Subscribe
    public void render(Render2DEvent event) {
        float scale = scaleAnimation.getValue();

        if (!isEnabled() && scale <= 0.01f) return;

        float screenWidth = mc.getWindow().getScaledWidth();
        float width = 155 * scale;
        float height = 24 * scale;
        float x = (screenWidth - width) / 2 - 300;
        float y = 20;
    }
}
