package dev.zcore.feature.module.impl.render;

import com.google.common.eventbus.Subscribe;
import com.google.gson.JsonObject;
import dev.zcore.feature.event.impl.Render2DEvent;
import dev.zcore.feature.module.api.Category;
import dev.zcore.feature.module.api.Module;
import dev.zcore.feature.module.api.ModuleAnnotation;
import dev.zcore.feature.ui.hud.*;
import dev.zcore.feature.ui.hud.drag.DragComponent;
import lombok.Getter;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

@Getter
@ModuleAnnotation(name = "Hud", category = Category.RENDER, description = "HUD элементы")
public class Hud extends Module {
    private static Hud instance;
    private final List<DragComponent> elements = new ArrayList<>();

    public static Hud getInstance() {
        return instance;
    }

    public Hud() {
        super();
        instance = this;
        this.setKey(GLFW.GLFW_KEY_F8);
        setState(true);

        registerElement(new MediaPlayerRenderer());
        registerElement(new NotificationRenderer());
        registerElement(new WatermarkRenderer());
        registerElement(new HotKeysRenderer());
        registerElement(new InformationRenderer());
    }

    public void registerElement(DragComponent element) {
        if (!elements.contains(element)) {
            elements.add(element);
        }
    }

    public void unregisterElement(DragComponent element) {
        elements.remove(element);
    }

    @Override
    public void onEnable() {
        super.onEnable();
    }

    @Override
    public void onDisable() {
        super.onDisable();
    }

    @Subscribe
    public void onRender2D(Render2DEvent event) {
        if (!isEnabled()) return;

        for (DragComponent element : elements) {
            
            if (element instanceof MediaPlayerRenderer) {
                ((MediaPlayerRenderer) element).tick();
            }
            element.render(event);
        }

        DragComponent.handleDrag(event, elements);
    }

    @Override
    public JsonObject save() {
        JsonObject base = super.save();
        JsonObject hud = new JsonObject();
        for (DragComponent element : elements) {
            if (!element.isDraggable()) continue;
            JsonObject pos = new JsonObject();
            pos.addProperty("x", element.getX());
            pos.addProperty("y", element.getY());
            hud.add(element.getClass().getSimpleName(), pos);
        }
        base.add("hudElements", hud);
        return base;
    }

    @Override
    public void load(JsonObject object) {
        super.load(object);
        try {
            if (object != null && object.has("hudElements")) {
                JsonObject hud = object.getAsJsonObject("hudElements");
                for (DragComponent element : elements) {
                    if (!element.isDraggable()) continue;
                    String key = element.getClass().getSimpleName();
                    if (hud.has(key)) {
                        JsonObject pos = hud.getAsJsonObject(key);
                        if (pos.has("x")) element.setX(pos.get("x").getAsFloat());
                        if (pos.has("y")) element.setY(pos.get("y").getAsFloat());
                    }
                }
            }
        } catch (Exception ignored) {}
    }
}
