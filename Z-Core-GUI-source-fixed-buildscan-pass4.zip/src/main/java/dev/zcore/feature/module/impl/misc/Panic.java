package dev.zcore.feature.module.impl.misc;

import dev.zcore.feature.module.api.Category;
import dev.zcore.feature.module.api.Module;
import dev.zcore.feature.module.api.ModuleAnnotation;
import dev.zcore.utils.client.ClientUtility;
import org.lwjgl.glfw.GLFW;

@ModuleAnnotation(name = "Panic", category = Category.MISC, description = "Выгружает чит с игры")
public class Panic extends Module {
    public static boolean unloaded = false;

    public Panic() {
        super();
        this.setKey(GLFW.GLFW_KEY_DELETE);
    }

    @Override
    public void onEnable() {
        unloaded = true;
        super.onEnable();
    }

    @Override
    public void onDisable() {
        unloaded = false;
        super.onDisable();
    }
}