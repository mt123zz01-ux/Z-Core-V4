package dev.zcore.feature.ui.screen.csgui.component.impl.setting;

import dev.zcore.feature.module.api.setting.Setting;
import dev.zcore.feature.ui.screen.csgui.component.impl.SettingComponent;

public class TestSetting extends SettingComponent {
    public TestSetting(float x, float y, Setting parent) {
        super(x, y, parent);
    }

    @Override
    public float getHeight() {
        return 20;
    }
}
