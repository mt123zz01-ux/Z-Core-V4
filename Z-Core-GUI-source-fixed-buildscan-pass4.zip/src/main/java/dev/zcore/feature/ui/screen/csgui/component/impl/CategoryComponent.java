package dev.zcore.feature.ui.screen.csgui.component.impl;

import dev.zcore.ZCore;
import dev.zcore.feature.module.api.Category;
import dev.zcore.feature.module.api.Module;
import dev.zcore.feature.ui.screen.csgui.CsGui;
import dev.zcore.feature.ui.screen.csgui.component.Component;
import dev.zcore.utils.animation.Animation;
import dev.zcore.utils.animation.Easing;
import dev.zcore.utils.render.ColorRGBA;
import dev.zcore.utils.render.Fonts;
import dev.zcore.utils.render.RenderContext;
import lombok.Getter;

import java.util.ArrayList;

public class CategoryComponent extends Component {
    @Getter
    private final Category parent;
    private final Animation animation;
    public final ArrayList<ModuleComponent> components = new ArrayList<>();

    public CategoryComponent(float x, float y, Category parent) {
        super(x, y);
        this.parent = parent;
        this.animation = new Animation(250, Easing.EXPO_OUT);
        float tempX = -16, tempY = 33;
        for (Module module : ZCore.getInstance().moduleManager.getModules(parent)) {
            tempX += 103;
            if (tempX > 380) {
                tempX = 103 - 16;
                tempY += 24;
            }
            components.add(new ModuleComponent(tempX, tempY, module));
        }
    }

    @Override
    public void render(RenderContext context) {
        animation.update();
        // rgba(165, 129, 238, 1) - active
        ColorRGBA back = CsGui.category == parent ? ColorRGBA.of(165, 129, 238, (int) ((((255 * 0.05) * animation.getValue())) * CsGui.alpha.getValue())) : ColorRGBA.of(233, 233, 233, (int) (255 * 0));
        context.drawRect(getX(), getY(), 78, 23, 6, back);
        context.drawText(getParent().getIcon(), Fonts.icons, getX() + 1, getY() + 1f, 11, 0.04f, ColorRGBA.of(233, 233, 233, (int) (255 * 0.45 * CsGui.alpha.getValue())));
        context.drawText(getParent().getName(), Fonts.sf_pro, getX() + 15, getY() + 2.5f, 6.5f, 0.04f, ColorRGBA.of(233, 233, 233, (int) (255 * 0.45 * CsGui.alpha.getValue())));

        if (CsGui.category == parent) {
            float startX = 103 - 16;
            float spacingX = 103f;
            int columns = 3;
            float[] colX = new float[columns];
            float[] colY = new float[columns];
            for (int c = 0; c < columns; c++) {
                colX[c] = startX + c * spacingX;
                colY[c] = 33f;
            }

            for (int i = 0; i < components.size(); i++) {
                ModuleComponent moduleComponent = components.get(i);
                int col = i % columns;
                moduleComponent.setX(colX[col]);
                moduleComponent.setY(colY[col]);
                moduleComponent.render(context);
                colY[col] += moduleComponent.getTotalHeight() + 2f;
            }
        }
    }

    @Override
    public void click(double mouseX, double mouseY, int button) {
        if (mouseX >= getX() && mouseX <= getX() + 78 && mouseY >= getY() && mouseY <= getY() + 23) {
            if (button == 0) CsGui.category = parent;
        }
        if (CsGui.category == parent) components.forEach(c -> c.click(mouseX, mouseY, button));
    }

    @Override
    public void key(int button) {
        if (CsGui.category == parent) components.forEach(moduleComponent -> moduleComponent.key(button));
    }

    @Override
    public void type(char chr) {
        if (CsGui.category == parent) components.forEach(moduleComponent -> moduleComponent.type(chr));
    }

    @Override
    public void dragged(double mouseX, double mouseY, double dX, double dY, int button) {
        if (CsGui.category == parent) components.forEach(moduleComponent -> moduleComponent.dragged(mouseX, mouseY, dX, dY, button));
    }

    @Override
    public void moved(double mouseX, double mouseY) {
        if (CsGui.category == parent) components.forEach(moduleComponent -> moduleComponent.moved(mouseX, mouseY));
    }

    @Override
    public void mReleased(double mouseX, double mouseY, int button) {
        if (CsGui.category == parent) components.forEach(moduleComponent -> moduleComponent.mReleased(mouseX, mouseY, button));
    }
}
