package dev.zcore.feature.ui.screen.csgui.component.impl;

import dev.zcore.feature.command.impl.ThemeCommand;
import dev.zcore.feature.ui.screen.csgui.CsGui;
import dev.zcore.feature.ui.screen.csgui.component.Component;
import dev.zcore.utils.animation.Animation;
import dev.zcore.utils.animation.Easing;
import dev.zcore.utils.client.ClientUtility;
import dev.zcore.utils.other.DisplayName;
import dev.zcore.utils.other.ThemeList;
import dev.zcore.utils.render.ColorRGBA;
import dev.zcore.utils.render.Fonts;
import dev.zcore.utils.render.RenderContext;
import lombok.Getter;

import java.lang.reflect.Field;

public class ThemeComponent extends Component {
    @Getter
    private final String themeName;
    private final String displayName;
    private final String[] colors;
    private final Animation hoverAnimation;

    public ThemeComponent(float x, float y, String themeName) {
        super(x, y);
        this.themeName = themeName;
        this.colors = ThemeCommand.getThemeColors(themeName);
        String displayName = getDisplayNameForTheme(themeName);
        this.displayName = (displayName == null || displayName.isEmpty()) ? themeName : displayName;
        this.hoverAnimation = new Animation(150, Easing.EXPO_OUT);
    }

    @Override
    public void render(RenderContext context) {
        try {
            hoverAnimation.update();

            boolean isSelected = ClientUtility.getCurrentTheme().equals(themeName);
            float width = 180f;
            float height = 24f;

            
            int bgAlpha = isSelected ? (int) ((255 * 0.1) * CsGui.alpha.getValue()) : (int) ((255 * 0.03) * CsGui.alpha.getValue());
            context.drawRect(getX(), getY(), width, height, 4, ColorRGBA.of(255, 255, 255, bgAlpha));

            
            if (colors != null && colors.length >= 1) {
                try {
                    int color1 = Integer.parseInt(colors[0].substring(1), 16);

                    
                    float colorWidth = 16f;
                    int r1 = (color1 >> 16) & 0xFF;
                    int g1 = (color1 >> 8) & 0xFF;
                    int b1 = color1 & 0xFF;

                    ColorRGBA c1 = ColorRGBA.of(r1, g1, b1, (int) (255 * CsGui.alpha.getValue()));
                    context.drawRect(getX() + 3, getY() + 4, colorWidth, height - 8, 2, c1);
                } catch (Exception ignored) {}
            }

            
            context.drawBorder(getX(), getY(), width, height, 4, 0.1f,
                ColorRGBA.of(255, 255, 255, (int) ((255 * 0.05) * CsGui.alpha.getValue())));

            
            if (displayName != null && !displayName.isEmpty()) {
                float textAlpha = isSelected ? 1.0f : 0.7f;
                context.drawText(displayName, Fonts.sf_pro, getX() + 22, getY() + 4, 7, 0.06f,
                    ColorRGBA.of(255, 255, 255, (int) (255 * textAlpha * CsGui.alpha.getValue())));

                
                if (isSelected) {
                    context.drawText("✓", Fonts.icons, getX() + width - 10, getY() + 3, 8, 0.06f,
                        ColorRGBA.of(165, 129, 238, (int) (255 * CsGui.alpha.getValue())));
                }
            }
        } catch (Exception e) {
        }
    }

    @Override
    public void click(double mouseX, double mouseY, int button) {
        if (isHovered(mouseX, mouseY, 180f, 24f)) {
            if (button == 0) {
                ClientUtility.setCurrentTheme(themeName);
                ClientUtility.sendMessage("Тема " + displayName + " успешно применена!");
            }
        }
    }

    @Override
    public void moved(double mouseX, double mouseY) {
        if (isHovered(mouseX, mouseY, 180f, 24f)) {
            hoverAnimation.animate(1);
        } else {
            hoverAnimation.animate(0);
        }
    }

    private String getDisplayNameForTheme(String fieldName) {
        try {
            Field f = ThemeList.class.getField(fieldName);
            DisplayName ann = f.getAnnotation(DisplayName.class);
            return ann != null ? ann.value() : fieldName;
        } catch (NoSuchFieldException e) {
            return fieldName;
        }
    }
}