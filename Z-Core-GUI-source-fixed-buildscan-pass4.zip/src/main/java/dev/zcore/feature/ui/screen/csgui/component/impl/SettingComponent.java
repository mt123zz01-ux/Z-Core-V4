package dev.zcore.feature.ui.screen.csgui.component.impl;

import dev.zcore.feature.module.api.setting.Setting;
import dev.zcore.feature.ui.screen.csgui.component.Component;

public abstract class SettingComponent extends Component {
    public Setting parent;

    public SettingComponent(float x, float y, Setting parent) {
        super(x, y);
        this.parent = parent;
    }

    public abstract float getHeight();
}