package dev.zcore.mixin;

import dev.zcore.feature.module.impl.misc.Panic;
import dev.zcore.feature.ui.screen.mainmenu.MainMenu;
import dev.zcore.utils.client.IMinecraft;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(TitleScreen.class)
public class TitleScreenMixin extends Screen implements IMinecraft {
    protected TitleScreenMixin(Text title) {
        super(title);
    }

    @Inject(method = "init", at = @At("RETURN"))
    public void init(CallbackInfo ci) {
        if (!Panic.unloaded) {
            mc.setScreen(new MainMenu());
        }
    }
}