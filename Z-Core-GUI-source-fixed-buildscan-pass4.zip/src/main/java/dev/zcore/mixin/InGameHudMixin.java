package dev.zcore.mixin;

import dev.zcore.feature.event.impl.Render2DEvent;
import dev.zcore.utils.render.RenderContext;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.render.RenderTickCounter;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(InGameHud.class)
public class InGameHudMixin {

    @Inject(method = "render", at = @At("TAIL"))
    private void render(DrawContext context, RenderTickCounter tickCounter, CallbackInfo ci) {
        new Render2DEvent(new RenderContext(context)).hook();
    }
}