package dev.zcore;

import com.google.common.eventbus.EventBus;
import com.google.common.eventbus.Subscribe;
import dev.zcore.feature.event.impl.TickEvent;
import dev.zcore.feature.ui.hud.MediaPlayerRenderer;
import dev.zcore.manager.AccountManager;
import dev.zcore.manager.CommandManager;
import dev.zcore.manager.ConfigManager;
import dev.zcore.manager.FirstLaunchManager;
import dev.zcore.manager.FriendManager;
import dev.zcore.manager.ModuleManager;
import dev.zcore.utils.client.ClientUtility;
import lombok.Getter;
import net.fabricmc.api.ModInitializer;

import static dev.zcore.utils.client.IMinecraft.mc;

public class ZCore implements ModInitializer {
    @Getter
    private static ZCore instance;

    public ModuleManager moduleManager;
    public FirstLaunchManager firstLaunchManager;
    public ConfigManager configManager;
    public CommandManager commandManager;
    public AccountManager accountManager;
    public FriendManager friendManager;
    public EventBus eventBus;
    public boolean enabled = true;

    @Getter
    private String cachedWeather = "N/A";

    public ZCore() {
        instance = this;
    }

    @Override
    public void onInitialize() {
        eventBus = new EventBus();
        eventBus.register(this);

        moduleManager = new ModuleManager();
        firstLaunchManager = new FirstLaunchManager();
        eventBus.register(firstLaunchManager);

        configManager = new ConfigManager();
        accountManager = new AccountManager();
        friendManager = new FriendManager();
        friendManager.initialize();
        ClientUtility.setCurrentTheme("CLIENT");
        commandManager = new CommandManager();
        new MediaPlayerRenderer();
    }

    @Subscribe
    public void onTick(TickEvent tickEvent) {
        if (mc.options != null && mc.options.getMonochromeLogo() != null) {
            mc.options.getMonochromeLogo().setValue(true);
        }
    }
}
