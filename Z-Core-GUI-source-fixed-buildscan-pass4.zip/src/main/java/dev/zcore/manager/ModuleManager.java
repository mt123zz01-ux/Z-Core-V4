package dev.zcore.manager;

import com.google.common.eventbus.Subscribe;
import dev.zcore.ZCore;
import dev.zcore.feature.event.impl.KeyEvent;
import dev.zcore.feature.module.api.Category;
import dev.zcore.feature.ui.screen.csgui.CsGui;
import dev.zcore.feature.module.impl.misc.AntiFT;
import dev.zcore.feature.module.impl.misc.GUI;
import dev.zcore.feature.module.impl.misc.Panic;
import dev.zcore.feature.module.impl.render.Hud;
import dev.zcore.utils.client.IMinecraft;
import dev.zcore.utils.client.Log;
import lombok.Getter;
import org.lwjgl.glfw.GLFW;
import dev.zcore.feature.module.api.Module;
import dev.zcore.feature.module.api.ModuleAnnotation;
import java.io.File;
import java.net.URL;
import java.util.*;

@Getter
public final class ModuleManager implements IMinecraft {
    private final List<Module> modules = new ArrayList<>();

    public ModuleManager() {
        init();
        ZCore.getInstance().eventBus.register(this);
    }

    private void init() {
        autoRegisterModules();
    }

    private void autoRegisterModules() {
        registerModule(new GUI());
        registerModule(new Hud());
        registerModule(new AntiFT());
        registerModule(new Panic());
    }

    private List<Class<?>> findModuleClasses(String packageName) {
        List<Class<?>> classes = new ArrayList<>();
        String path = packageName.replace('.', '/');
        try {
            ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
            URL resource = classLoader.getResource(path);
            if (resource != null) {
                File directory = new File(resource.toURI());
                if (directory.exists()) {
                    scanDirectory(directory, packageName, classes);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return classes;
    }

    private void scanDirectory(File directory, String packageName, List<Class<?>> classes) {
        File[] files = directory.listFiles();
        if (files == null) return;
        for (File file : files) {
            if (file.isDirectory()) {
                scanDirectory(file, packageName + "." + file.getName(), classes);
            } else if (file.getName().endsWith(".class")) {
                String className = packageName + '.' + file.getName().substring(0, file.getName().length() - 6);
                try {
                    Class<?> clazz = Class.forName(className);
                    classes.add(clazz);
                } catch (ClassNotFoundException e) {
                }
            }
        }
    }

    private void registerModule(Module module) {
        modules.add(module);
    }

    public Module getModule(String name) {
        return modules.stream()
                .filter(module -> module.getName().equalsIgnoreCase(name))
                .findFirst()
                .orElse(null);
    }

    public Set<Module> getActiveModules() {
        Set<Module> active = new HashSet<>();
        for (Module module : modules) {
            if (module.isEnabled()) active.add(module);
        }
        return active;
    }

    public List<Module> getModules(Category category) {
        List<Module> temp = new ArrayList<>();
        for (Module module : modules) {
            if (module.getCategory() == category) {
                temp.add(module);
            }
        }

        return temp;
    }

    @Subscribe
    public void onKey(KeyEvent event) {
        if (mc.currentScreen != null || event.getAction() != GLFW.GLFW_PRESS) return;
        for (Module module : modules) {
            if (module.getKey() == event.getKey() && module.getKey() != GLFW.GLFW_KEY_UNKNOWN) {
                module.cToggle();
            }
        }

        if (event.getKey() == GLFW.GLFW_KEY_P) {
            mc.setScreen(new CsGui());
        }
    }

    public int getActiveModules(Category cat) {
        int count = 0;
        for (Module module : modules) {
            if (module.isEnabled() && module.getCategory().equals(cat)) {
                count++;
            }
        }

        return count;
    }

    public int getModulesCount(Category cat) {
        int count = 0;
        for (Module module : modules) {
            if (module.getCategory().equals(cat)) {
                count++;
            }
        }

        return count;
    }
}