package dev.zcore.manager;

import com.google.common.eventbus.Subscribe;
import dev.zcore.feature.event.impl.WorldJoinEvent;
import dev.zcore.utils.client.ClientUtility;
import dev.zcore.utils.client.Constants;
import lombok.Getter;
import lombok.Setter;
import ru.kotopushka.compiler.sdk.classes.Profile;

import java.io.File;

public class FirstLaunchManager {

    private static final String FOLDER_NAME = "ZCore";

    @Setter
    @Getter
    private boolean isFirstLaunch;
    private boolean messageShown = false;

    public FirstLaunchManager() {
        checkFirstLaunch();
    }

    private void checkFirstLaunch() {
        File zcoreFolder = new File(getZCoreFolderPath());
        isFirstLaunch = !zcoreFolder.exists();
        if (isFirstLaunch) {
            zcoreFolder.mkdirs();
        }
    }

    private String getZCoreFolderPath() {
        String userHome = System.getProperty("user.home");
        return userHome + File.separator + FOLDER_NAME;
    }

    @Subscribe
    public void onWorldJoin(WorldJoinEvent event) {
        if (isFirstLaunch && !messageShown) {
            messageShown = true;
            sendWelcomeMessage();
        }
    }

    private void sendWelcomeMessage() {
        String welcomeMessage = "Welcome to " + Constants.CLIENT_NAME + ", " + Profile.getUsername() +
                "\nUse . as the command prefix." +
                "\nPress P to open the menu.";

        ClientUtility.sendGradientMessage(welcomeMessage);
    }

    public void resetFirstLaunch() {
        this.isFirstLaunch = true;
        this.messageShown = false;
    }
}
