package dev.zcore.manager;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public class FriendManager {
    private final Set<String> friends = new HashSet<>();

    public void initialize() {
        // Local-only friend manager. Online sync has been removed.
    }

    public boolean isFriend(String name) {
        return name != null && friends.contains(name.toLowerCase());
    }

    public void addFriend(String name) {
        if (name != null && !name.isBlank()) friends.add(name.toLowerCase());
    }

    public void removeFriend(String name) {
        if (name != null) friends.remove(name.toLowerCase());
    }

    public Set<String> getFriends() {
        return Collections.unmodifiableSet(friends);
    }
}
