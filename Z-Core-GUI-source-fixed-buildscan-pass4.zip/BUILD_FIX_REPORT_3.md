# Z-Core GUI Source - Build Fix Pass 3

Fix batch based on GitHub Actions screenshots from 2026-05-08 21:30-21:31.

## Fixed compile errors visible in screenshots

- `MathUtil.java`
  - Replaced removed entity fields `prevX`, `prevY`, `prevZ` with 1.21.11 public fields `lastX`, `lastY`, `lastZ`.

- `MoveUtil.java`
  - Replaced removed player fields `prevX`, `prevZ` with `lastX`, `lastZ`.

- `CsGui.java`
  - Updated `mouseClicked(double, double, int)` to new 1.21.11 input signature `mouseClicked(Click, boolean)`.
  - Updated `keyPressed(int, int, int)` to `keyPressed(KeyInput)`.

- `AccountManagerScreen.java`
  - Updated `mouseClicked(double, double, int)` to `mouseClicked(Click, boolean)`.
  - Updated `keyPressed(int, int, int)` to `keyPressed(KeyInput)`.
  - Updated `charTyped(char, int)` to `charTyped(CharInput)`.
  - Updated superclass calls to use the new `Click`, `KeyInput`, and `CharInput` records.

- `AltManager.java`
  - Updated `mouseClicked(double, double, int)` to `mouseClicked(Click, boolean)`.
  - Updated `keyPressed(int, int, int)` to `keyPressed(KeyInput)`.
  - Added `charTyped(CharInput)` for text input handling.
  - Fixed a possible out-of-bounds access after deleting the last alt entry.

- `MainMenu.java`
  - Updated `mouseClicked(double, double, int)` to `mouseClicked(Click, boolean)`.
  - Updated superclass call to use `super.mouseClicked(click, doubled)`.

## Static scan after fix

No remaining active source references found for the screenshot errors:

- `entity.prevX`, `entity.prevY`, `entity.prevZ`
- `mc.player.prevX`, `mc.player.prevZ`
- old screen overrides `mouseClicked(double, double, int)`
- old screen overrides `keyPressed(int, int, int)`
- old screen overrides `charTyped(char, int)`
- old super calls `super.mouseClicked(mouseX, mouseY, button)`
- old super calls `super.keyPressed(keyCode, scanCode, modifiers)`
- old super calls `super.charTyped(chr, modifiers)`

Remaining `prevX`/`prevY` names only exist as local custom HUD drag fields and are not Minecraft API fields.

## Build note

The local sandbox cannot download Gradle/Minecraft dependencies because DNS/network access to `services.gradle.org` is blocked. Please run the GitHub Action or:

```bash
./gradlew clean build --stacktrace
```

If it still fails, send the raw text log around the first `error:` entry.
