Z-Core GUI Source

Target:
- Minecraft: 1.21.11
- Fabric Loader: 0.18.2
- Fabric API: 0.141.0+1.21.11
- Java: 21
- Package: dev.zcore
- Mod ID: zcore
- GUI key: P

Included:
- Full GUI style from the provided client source, rebranded to Z-Core.
- Main menu screens.
- Theme/render/font/settings/module base needed by the GUI.
- Temporary icon/assets from the provided source.

Disabled/removed online systems:
- Discord RPC
- IRC backend
- Cloud Config backend
- Friend online backend
- Weather online backend
- ServerConnection
- Proxy screen
- Auto server injection
- First-launch Telegram/browser opening

Notes:
- This source has been statically checked and cleaned in multiple layers.
- Gradle wrapper is set to Gradle 9.2.1 for the Z-Core 1.21.11 environment.
- If GitHub Actions still fails, send the full build log so the remaining Minecraft/Yarn API mismatches can be patched precisely.
