package com.zcore.client.gui;

import com.zcore.client.client.Main;
import com.zcore.client.client.ZCoreClient;
import com.zcore.client.modules.Module;
import com.zcore.client.themes.Theme;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.List;

public final class ZCoreScreen extends Screen {
    private int panelX;
    private int panelY;
    private final int panelWidth = 420;
    private final int panelHeight = 260;

    public ZCoreScreen() {
        super(Text.literal(Main.CLIENT_NAME));
    }

    @Override
    protected void init() {
        panelX = (width - panelWidth) / 2;
        panelY = (height - panelHeight) / 2;
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        Theme theme = ZCoreClient.THEMES.current();
        context.fill(0, 0, width, height, theme.background());
        context.fill(panelX, panelY, panelX + panelWidth, panelY + panelHeight, theme.panel());
        context.fill(panelX, panelY, panelX + panelWidth, panelY + 4, theme.accent());

        int titleX = panelX + 18;
        int titleY = panelY + 16;
        context.drawTextWithShadow(textRenderer, Text.literal(Main.CLIENT_NAME), titleX, titleY, theme.text());
        context.drawTextWithShadow(textRenderer, Text.literal("Theme: " + theme.name() + "  |  Press T to change"), titleX, titleY + 14, theme.mutedText());
        context.drawTextWithShadow(textRenderer, Text.literal("Right Shift opens this GUI. Click modules to toggle."), titleX, titleY + 28, theme.mutedText());

        List<Module> modules = ZCoreClient.MODULES.all();
        int y = panelY + 68;
        for (int i = 0; i < modules.size(); i++) {
            Module module = modules.get(i);
            int rowX = panelX + 18;
            int rowY = y + i * 34;
            int rowColor = module.enabled() ? 0x553BFF65 : 0x552A2A34;
            context.fill(rowX, rowY, rowX + panelWidth - 36, rowY + 26, rowColor);
            context.drawTextWithShadow(textRenderer, Text.literal(module.name()), rowX + 10, rowY + 9, theme.text());
            context.drawTextWithShadow(textRenderer, Text.literal(module.category()), rowX + panelWidth - 120, rowY + 9, theme.mutedText());
        }

        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        double mouseX = click.x();
        double mouseY = click.y();
        int startY = panelY + 68;
        List<Module> modules = ZCoreClient.MODULES.all();
        for (int i = 0; i < modules.size(); i++) {
            int rowX = panelX + 18;
            int rowY = startY + i * 34;
            if (mouseX >= rowX && mouseX <= rowX + panelWidth - 36 && mouseY >= rowY && mouseY <= rowY + 26) {
                modules.get(i).toggle();
                return true;
            }
        }
        return super.mouseClicked(click, doubled);
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        if (input.key() == GLFW.GLFW_KEY_T) {
            ZCoreClient.THEMES.nextTheme();
            return true;
        }
        return super.keyPressed(input);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
