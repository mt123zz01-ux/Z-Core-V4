Z-Core source generated from async-recode.zip

Configuration:
- Client name: Z-Core
- Minecraft: 1.21.11
- Package: dev.zcore
- Mod ID: zcore
- GUI key: P
- MainMenu: enabled
- Online systems removed/disabled: Discord RPC, IRC, Cloud Config, online Friend System, Weather online, ServerConnection, Proxy screen, auto server injection.
- Icon: reused current client avatar/icon from the uploaded source.
- Build: GitHub Actions workflow added at .github/workflows/build.yml

Important:
This is a best-effort source conversion. Because the original project targeted Minecraft/Fabric 1.21.4, some mappings/API calls may still need small fixes when building on 1.21.11.
