package dev.zcore.feature.ui.screen.mainmenu;

import dev.zcore.utils.animation.Animation;
import dev.zcore.utils.animation.Easing;
import dev.zcore.utils.client.ClientUtility;
import dev.zcore.utils.client.Constants;
import dev.zcore.utils.client.IMinecraft;
import dev.zcore.utils.render.ColorRGBA;
import dev.zcore.utils.render.AnimatedGif;
import dev.zcore.utils.render.RenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import ru.kotopushka.compiler.sdk.classes.Profile;

import java.util.function.Supplier;

import static dev.zcore.utils.render.Fonts.icons;
import static dev.zcore.utils.render.Fonts.sf_pro;

public class MainMenu extends Screen implements IMinecraft {
    Identifier backTexture = Identifier.of("zcore", "textures/background.png");
    Button[] buttons;

    private Animation textAnimation;
    private long lastSwitchTime = 0;
    private String[] textCycle;
    private int currentTextIndex = 0;

    public MainMenu() {
        super(Text.literal("MainMenu"));
        String username = Profile.getUsername();
        textCycle = new String[]{
                "Welcome back, " + username,
                "Build: " + Constants.BUILD,
                "Version: " + ClientUtility.getVersion()
        };
        textAnimation = new Animation(2500, Easing.SINE_IN_OUT);
        textAnimation.animate(1);
        lastSwitchTime = System.currentTimeMillis();
    }

    @Override
    protected void init() {
        updateButtons();
    }

    @Override
    public void tick() {
        updateButtons();
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        var renderContext = new RenderContext(context);
        var backgroundTexture = MinecraftClient.getInstance().getTextureManager().getTexture(backTexture);
        var username = Profile.getUsername();
        var othertext = "By logging into your account you agree to all of our policies,";
        var othertext2 = "Including our ";
        var privacyText = "Privacy Policy";
        var andText = " and ";
        var termsText = "Terms of Service";

        renderContext.drawTexture(
                0,
                0,
                mc.getWindow().getScaledWidth(), mc.getWindow().getScaledHeight(),
                0, ColorRGBA.of(255, 255, 255), 0, 0, 1, 1,
                backgroundTexture.getGlId());

        textAnimation.update();
        long currentTime = System.currentTimeMillis();
        if (currentTime - lastSwitchTime >= 2500) {
            lastSwitchTime = currentTime;
            currentTextIndex = (currentTextIndex + 1) % textCycle.length;
            textAnimation = new Animation(2500, Easing.LINEAR);
            textAnimation.animate(1);
        }

        String fullText = textCycle[currentTextIndex];
        float animValue = textAnimation.getValue();

        int totalChars = fullText.length();
        int displayChars;

        float printEnd = 0.30f;
        float eraseStart = 0.70f;

        if (animValue < printEnd) {
            displayChars = (int) (totalChars * (animValue / printEnd));
        } else if (animValue < eraseStart) {
            displayChars = totalChars;
        } else {
            float eraseProgress = (animValue - eraseStart) / (1.0f - eraseStart);
            displayChars = (int) (totalChars * (1.0f - eraseProgress));
        }
        displayChars = Math.max(0, Math.min(totalChars, displayChars));

        String displayText = fullText.substring(0, displayChars);

        renderContext.drawText(
                othertext,
                sf_pro,
                (float) mc.getWindow().getScaledWidth() / 2 - (sf_pro.getWidth(othertext, 8.5f) / 2),
                (float) mc.getWindow().getScaledHeight() - 40,
                8.5f,
                ColorRGBA.of(126, 126, 131)
        );

        float baseX = (float) mc.getWindow().getScaledWidth() / 2 - (sf_pro.getWidth(othertext2 + privacyText + andText + termsText, 8.5f) / 2);
        renderContext.drawText(
                othertext2,
                sf_pro,
                baseX,
                (float) mc.getWindow().getScaledHeight() - 29,
                8.5f,
                ColorRGBA.of(126, 126, 131)
        );

        renderContext.drawText(
                privacyText,
                sf_pro,
                baseX + sf_pro.getWidth(othertext2, 8.6f),
                (float) mc.getWindow().getScaledHeight() - 29,
                8.5f,
                ColorRGBA.of(255, 255, 255)
        );

        renderContext.drawText(
                andText,
                sf_pro,
                baseX + sf_pro.getWidth(othertext2 + privacyText, 8.6f),
                (float) mc.getWindow().getScaledHeight() - 29,
                8.5f,
                ColorRGBA.of(126, 126, 131)
        );

        renderContext.drawText(
                termsText,
                sf_pro,
                baseX + sf_pro.getWidth(othertext2 + privacyText + andText, 8.55f),
                (float) mc.getWindow().getScaledHeight() - 29,
                8.5f,
                ColorRGBA.of(255, 255, 255)
        );

        float textX = (float) mc.getWindow().getScaledWidth() / 2 - sf_pro.getWidth(fullText, 12) / 2;
        float textY = (float) mc.getWindow().getScaledHeight() / 2 - 76;

        if (fullText.startsWith("Welcome back, ")) {
            String prefix = "Welcome back, ";
            int prefixLen = prefix.length();

            if (displayChars <= prefixLen) {
                renderContext.drawText(displayText, sf_pro, textX, textY, 12.0f, ColorRGBA.of(255, 255, 255));
            } else {
                String displayPrefix = displayText.substring(0, prefixLen);
                String displaySuffix = displayText.substring(prefixLen);

                renderContext.drawText(displayPrefix, sf_pro, textX, textY, 12.0f, ColorRGBA.of(255, 255, 255));
                renderContext.drawText(displaySuffix, sf_pro, textX + sf_pro.getWidth(displayPrefix, 12), textY, 12.0f, ColorRGBA.of(165, 129, 238));
            }
        } else {
            renderContext.drawText(displayText, sf_pro, textX, textY, 12.0f, ColorRGBA.of(255, 255, 255));
        }

        renderContext.drawText(
                "i",
                icons,
                (float) mc.getWindow().getScaledWidth() / 2 - icons.getWidth("i", 34) / 2,
                (float) mc.getWindow().getScaledHeight() / 2 - 115,
                34.0f,
                ColorRGBA.of(96, 67, 222)
        );

        for (Button button : buttons) {
            button.render(renderContext, mouseX, mouseY);
        }
    }

    class Button {
        int x;
        int y;
        final int width;
        final int height;
        final String text;
        final Supplier<Void> action;

        public Button(int x, int y, int width, int height, String text, Supplier<Void> action) {
            this.x = x;
            this.y = y;
            this.width = width;
            this.height = height;
            this.text = text;
            this.action = action;
        }

        public void render(RenderContext context, int mouseX, int mouseY) {

            context.drawBlur(x, y, width, height, 5.0f, 8, ColorRGBA.of(255, 255, 255, 255));
            context.drawRect(x, y, width, height, 5.0f, ColorRGBA.of(70, 70, 70, 50));

            context.drawText(
                    text,
                    sf_pro,
                    x + 7,
                    y + (float) height / 2 - 5.5f,
                    10.0f,
                    ColorRGBA.of(126, 126, 131)
            );

            context.drawText(
                    getIconSymbol(text),
                    icons,
                    x + width - 17.5f,
                    y + (float) height / 2 - 4.5f,
                    10.0f,
                    ColorRGBA.of(126, 126, 131)
            );

            context.drawBorder(x, y, width, height, 5.0f, 0.05f, ColorRGBA.of(223, 223, 223, 45), 0.4F, 0.4F);
        }

        public void onClick(int mouseX, int mouseY) {
            if (mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + height) {
                action.get();
            }
        }
    }

    String getIconSymbol(String text) {
        return switch (text) {
            case "Singleplayer" -> "Q";
            case "Multiplayer" -> "G";
            case "AccountManager" -> "H";
            case "Exit" -> "F";
            case "Settings" -> "E";
            default -> "a";
        };
    }

    void updateButtons() {
        var width = 210;
        var height = 29;

        var centerX = mc.getWindow().getScaledWidth() / 2 - width / 2;
        var spacing = 33;
        var startY = mc.getWindow().getScaledHeight() / 2 - 55;

        buttons = new Button[]{
                new Button(centerX, startY, width, height, "Singleplayer", () -> { MinecraftClient.getInstance().setScreen(new SelectWorldScreen(this)); return null; }),
                new Button(centerX, startY + spacing, width, height, "Multiplayer", () -> { MinecraftClient.getInstance().setScreen(new MultiplayerScreen(this)); return null; }),
                new Button(centerX, startY + spacing * 2, width, height, "AccountManager", () -> { MinecraftClient.getInstance().setScreen(new AccountManagerScreen(this)); return null; }),
                new Button(centerX + (width / 2) + 2, startY + spacing * 3, width / 2 - 2, height, "Settings", () -> { MinecraftClient.getInstance().setScreen(new OptionsScreen(this, mc.options)); return null; }),
                new Button(centerX, startY + spacing * 3, width / 2 - 2, height, "Exit", () -> { MinecraftClient.getInstance().scheduleStop(); return null; })
        };
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0) return false;

        for (Button buttons : buttons) {
            buttons.onClick((int) mouseX, (int) mouseY);
        }
        
        return super.mouseClicked(mouseX, mouseY, button);
    }
}
