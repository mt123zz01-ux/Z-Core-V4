Z-Core clean GUI/theme source pack

Requested changes applied:
- Client display name changed to Z-Core.
- Auth/license startup call removed from Main.java.
- Auth/network/security/account folders removed.
- Discord/Spotify bundled jars removed from fabric.mod.json and META-INF/jars removed.
- Old modules folder removed and replaced with a clean minimal module layer.
- Kept GUI/theme/render/font assets where possible.
- ClickGUI keybind set to P.
- Mixins disabled because the original mixins depended on deleted combat/automation/ESP modules.

Important notes:
- The uploaded source is decompiled source, not the original Gradle project.
- Several original GUI/HUD files were decompiler-internal-error files. I replaced the setting classes with clean stubs, but HUD editor from the original cannot be fully restored from the broken decompiled file.
- This is a cleaned source base/patch pack, not guaranteed to compile without normal Fabric Gradle project files and mappings.
- Next step: place these files into a proper Fabric 1.21.11 project, then fix compile errors from deobfuscated/intermediary mappings.

Removed on purpose:
- AuthManager / license check
- Microsoft account manager
- Webhook/network/security folder
- DiscordPresence / MediaPlayer dependencies
- Combat, Donut automation, ESP and other old modules
