package com.zcore.client.themes;

import com.zcore.client.gui.ZCoreGuiTheme;
import com.zcore.client.modules.client.HUD;





public class SciFiTheme
  implements Theme
{
  private static final int BACKGROUND = -268105195;
  private static final int SHADOW = 805339306;
  private static final int BORDER = 1342221004;
  private static final int TEXT = -16724771;
  private static final int SECONDARY_TEXT = -16736069;
  private static final int HEADER_TEXT = -16729123;
  private static final int SEPARATOR_RGB = 43724;
  private static final int HEALTH_BAR_BG = -16772830;
  private static final int HEALTH_BAR = -16733492;
  private static final int GUI_BACKGROUND = -16446955;
  private static final int GUI_CATEGORY_BG = -267907302;
  private static final int GUI_CATEGORY_HEADER = -267775456;
  private static final int GUI_MODULE_BG = -267841765;
  private static final int GUI_SETTINGS_BG = -268105195;
  private static final int GUI_BORDER = 1342221004;
  private static final int GUI_HOVER = 1610660829;
  private static final int GUI_SEPARATOR = 889233595;
  private static final int GUI_TEXT = -16724771;
  private static final int GUI_TEXT_ENABLED = -16729123;
  private static final int GUI_TEXT_DISABLED = -16736069;
  
  public int getBackgroundColor(int alphaValue) {
    float alpha = Math.max(0.0F, Math.min(1.0F, alphaValue / 255.0F));
    return ZCoreGuiTheme.applyAlpha(528154, alpha * 0.5F);
  }

  
  public int getShadowColor() {
    return 805339306;
  }


  
  public int getBorderColor() {
    return 1342221004;
  }


  
  public int getTextColor(HUD hud) {
    return -1;
  }

  
  public int getSecondaryTextColor(int pixelY, int totalHeight, HUD hud) {
    return -1;
  }

  
  public int getHeaderColor(HUD hud) {
    return -1;
  }

  
  public int getSeparatorColor(int alphaValue) {
    int separatorAlpha = (int)(alphaValue * 0.25F);
    return separatorAlpha << 24 | 0xAACC;
  }

  
  public int getHealthBarBgColor() {
    return -16772830;
  }

  
  public int getHealthBarColor(HUD hud) {
    return -16733492;
  }

  
  public int getItemPadding() {
    return 4;
  }

  
  public int getBoxPadding() {
    return 8;
  }

  
  public float getTextScale() {
    return 1.14F;
  }

  
  public int getRadius(int cornerRadius) {
    return 6;
  }

  
  public boolean useShadows() {
    return true;
  }

  
  public boolean useBorders() {
    return true;
  }

  
  public boolean useCustomFont() {
    return true;
  }


  
  public int getGuiBackground() {
    return -16446955;
  }

  
  public int getGuiCategoryBackground() {
    return -267907302;
  }

  
  public int getGuiCategoryHeader() {
    return -267775456;
  }

  
  public int getGuiModuleBackground() {
    return -267841765;
  }

  
  public int getGuiSettingsBackground() {
    return -268105195;
  }

  
  public int getGuiHoverColor() {
    return 1610660829;
  }

  
  public int getGuiBorderColor() {
    return 1342221004;
  }

  
  public int getGuiSeparatorColor() {
    return 889233595;
  }

  
  public int getGuiTextColor() {
    return -16724771;
  }

  
  public int getGuiEnabledTextColor() {
    return -16729123;
  }

  
  public int getGuiDisabledTextColor() {
    return -16736069;
  }

  
  public int getGuiAccentColor() {
    return -16729123;
  }

  
  public boolean isModernStyle() {
    return true;
  }
}


