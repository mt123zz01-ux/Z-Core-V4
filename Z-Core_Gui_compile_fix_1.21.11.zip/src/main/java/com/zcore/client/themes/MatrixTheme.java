package com.zcore.client.themes;

import com.zcore.client.gui.ZCoreGuiTheme;
import com.zcore.client.modules.client.HUD;





public class MatrixTheme
  implements Theme
{
  private static final int BACKGROUND = -268435456;
  private static final int SHADOW = 805371648;
  private static final int BORDER = 1342242560;
  private static final int TEXT = -16711936;
  private static final int SECONDARY_TEXT = -16724992;
  private static final int HEADER_TEXT = -16711936;
  private static final int SEPARATOR_RGB = 65280;
  private static final int HEALTH_BAR_BG = -16772864;
  private static final int HEALTH_BAR = -16711936;
  private static final int GUI_BACKGROUND = -16777216;
  private static final int GUI_CATEGORY_BG = -268106491;
  private static final int GUI_CATEGORY_HEADER = -267909112;
  private static final int GUI_MODULE_BG = -268238077;
  private static final int GUI_SETTINGS_BG = -268369663;
  private static final int GUI_BORDER = 1610678016;
  private static final int GUI_HOVER = -2147418368;
  private static final int GUI_SEPARATOR = 1073807104;
  private static final int GUI_TEXT = -16711936;
  private static final int GUI_TEXT_ENABLED = -16711936;
  private static final int GUI_TEXT_DISABLED = -16733696;
  
  public int getBackgroundColor(int alphaValue) {
    float alpha = Math.max(0.0F, Math.min(1.0F, alphaValue / 255.0F));
    return ZCoreGuiTheme.applyAlpha(328965, alpha * 0.5F);
  }

  
  public int getShadowColor() {
    return 805371648;
  }


  
  public int getBorderColor() {
    return 1610678016;
  }


  
  public int getTextColor(HUD hud) {
    return -1;
  }

  
  public int getSecondaryTextColor(int pixelY, int totalHeight, HUD hud) {
    return -1;
  }

  
  public int getHeaderColor(HUD hud) {
    return -1;
  }

  
  public int getSeparatorColor(int alphaValue) {
    int separatorAlpha = (int)(alphaValue * 0.3F);
    return separatorAlpha << 24 | 0xFF00;
  }

  
  public int getHealthBarBgColor() {
    return -16772864;
  }

  
  public int getHealthBarColor(HUD hud) {
    return -16711936;
  }

  
  public int getItemPadding() {
    return 4;
  }

  
  public int getBoxPadding() {
    return 8;
  }

  
  public float getTextScale() {
    return 1.14F;
  }

  
  public int getRadius(int cornerRadius) {
    return 6;
  }

  
  public boolean useShadows() {
    return true;
  }

  
  public boolean useBorders() {
    return true;
  }

  
  public boolean useCustomFont() {
    return true;
  }


  
  public int getGuiBackground() {
    return -16777216;
  }

  
  public int getGuiCategoryBackground() {
    return -268106491;
  }

  
  public int getGuiCategoryHeader() {
    return -267909112;
  }

  
  public int getGuiModuleBackground() {
    return -268238077;
  }

  
  public int getGuiSettingsBackground() {
    return -268369663;
  }

  
  public int getGuiHoverColor() {
    return -2147418368;
  }

  
  public int getGuiBorderColor() {
    return 1610678016;
  }

  
  public int getGuiSeparatorColor() {
    return 1073807104;
  }

  
  public int getGuiTextColor() {
    return -16711936;
  }

  
  public int getGuiEnabledTextColor() {
    return -16711936;
  }

  
  public int getGuiDisabledTextColor() {
    return -16733696;
  }

  
  public int getGuiAccentColor() {
    return -16711936;
  }

  
  public boolean isModernStyle() {
    return true;
  }
}


