package com.zcore.client.themes;

import com.zcore.client.gui.ZCoreGuiTheme;
import com.zcore.client.modules.client.HUD;





public class ForestTheme
  implements Theme
{
  private static final int BACKGROUND = -266719718;
  private static final int SHADOW = 1079036024;
  private static final int BORDER = 1616955512;
  private static final int TEXT = -7278960;
  private static final int SECONDARY_TEXT = -7357297;
  private static final int HEADER_TEXT = -6751336;
  private static final int SEPARATOR_RGB = 9139029;
  private static final int HEALTH_BAR_BG = -14008790;
  private static final int HEALTH_BAR = -7278960;
  private static final int GUI_BACKGROUND = -15061478;
  private static final int GUI_CATEGORY_BG = -266324704;
  private static final int GUI_CATEGORY_HEADER = -265995739;
  private static final int GUI_MODULE_BG = -266522595;
  private static final int GUI_SETTINGS_BG = -266851816;
  private static final int GUI_BORDER = 1888187221;
  private static final int GUI_HOVER = -1873753992;
  private static final int GUI_SEPARATOR = 1351316309;
  private static final int GUI_TEXT = -7278960;
  private static final int GUI_TEXT_ENABLED = -6751336;
  private static final int GUI_TEXT_DISABLED = -7357297;
  
  public int getBackgroundColor(int alphaValue) {
    float alpha = Math.max(0.0F, Math.min(1.0F, alphaValue / 255.0F));
    return ZCoreGuiTheme.applyAlpha(2110752, alpha * 0.5F);
  }

  
  public int getShadowColor() {
    return 1079036024;
  }


  
  public int getBorderColor() {
    return 1888187221;
  }


  
  public int getTextColor(HUD hud) {
    return -1;
  }

  
  public int getSecondaryTextColor(int pixelY, int totalHeight, HUD hud) {
    return -1;
  }

  
  public int getHeaderColor(HUD hud) {
    return -1;
  }

  
  public int getSeparatorColor(int alphaValue) {
    int separatorAlpha = (int)(alphaValue * 0.2F);
    return separatorAlpha << 24 | 0x8B7355;
  }

  
  public int getHealthBarBgColor() {
    return -14008790;
  }

  
  public int getHealthBarColor(HUD hud) {
    return -7278960;
  }

  
  public int getItemPadding() {
    return 4;
  }

  
  public int getBoxPadding() {
    return 8;
  }

  
  public float getTextScale() {
    return 1.14F;
  }

  
  public int getRadius(int cornerRadius) {
    return 7;
  }

  
  public boolean useShadows() {
    return true;
  }

  
  public boolean useBorders() {
    return true;
  }

  
  public boolean useCustomFont() {
    return true;
  }


  
  public int getGuiBackground() {
    return -15061478;
  }

  
  public int getGuiCategoryBackground() {
    return -266324704;
  }

  
  public int getGuiCategoryHeader() {
    return -265995739;
  }

  
  public int getGuiModuleBackground() {
    return -266522595;
  }

  
  public int getGuiSettingsBackground() {
    return -266851816;
  }

  
  public int getGuiHoverColor() {
    return -1873753992;
  }

  
  public int getGuiBorderColor() {
    return 1888187221;
  }

  
  public int getGuiSeparatorColor() {
    return 1351316309;
  }

  
  public int getGuiTextColor() {
    return -7278960;
  }

  
  public int getGuiEnabledTextColor() {
    return -6751336;
  }

  
  public int getGuiDisabledTextColor() {
    return -7357297;
  }

  
  public int getGuiAccentColor() {
    return -7278960;
  }

  
  public boolean isModernStyle() {
    return true;
  }
}


