package com.zcore.client.themes;

import com.zcore.client.modules.client.HUD;



public class CrystalTheme
  implements Theme
{
  private static final int BACKGROUND = 1073741824;
  private static final int SHADOW = 805306368;
  private static final int BORDER = -2130706433;
  private static final int TEXT = -1;
  private static final int SECONDARY_TEXT = -3355444;
  private static final int ACCENT = -6596122;
  
  public int getBackgroundColor(int alphaValue) {
    return 1073741824;
  }

  
  public int getShadowColor() {
    return 805306368;
  }

  
  public int getBorderColor() {
    return -2130706433;
  }

  
  public int getTextColor(HUD hud) {
    return -1;
  }

  
  public int getSecondaryTextColor(int pixelY, int totalHeight, HUD hud) {
    return -3355444;
  }

  
  public int getHeaderColor(HUD hud) {
    return hud.getHudColorInt();
  }

  
  public int getSeparatorColor(int alphaValue) {
    return 1090519039;
  }

  
  public int getHealthBarBgColor() {
    return 1073741824;
  }

  
  public int getHealthBarColor(HUD hud) {
    return hud.getHudColorInt();
  }

  
  public int getItemPadding() {
    return 4;
  }

  
  public int getBoxPadding() {
    return 8;
  }

  
  public float getTextScale() {
    return 1.15F;
  }

  
  public int getRadius(int cornerRadius) {
    return 8;
  }

  
  public boolean useShadows() {
    return true;
  }

  
  public boolean useBorders() {
    return true;
  }

  
  public boolean useCustomFont() {
    return true;
  }

  
  public int getGuiBackground() {
    return -268106491;
  }

  
  public int getGuiCategoryBackground() {
    return -535818224;
  }

  
  public int getGuiCategoryHeader() {
    return -267053803;
  }

  
  public int getGuiModuleBackground() {
    return -267777526;
  }

  
  public int getGuiSettingsBackground() {
    return -268106491;
  }

  
  public int getGuiHoverColor() {
    return 1090519039;
  }

  
  public int getGuiBorderColor() {
    return 822083583;
  }

  
  public int getGuiSeparatorColor() {
    return 553648127;
  }

  
  public int getGuiTextColor() {
    return -986896;
  }

  
  public int getGuiEnabledTextColor() {
    return -6596122;
  }

  
  public int getGuiDisabledTextColor() {
    return -5592406;
  }

  
  public int getGuiAccentColor() {
    return -6596122;
  }

  
  public boolean isModernStyle() {
    return true;
  }
}


