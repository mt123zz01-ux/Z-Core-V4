package com.zcore.client.themes;

import com.zcore.client.modules.client.HUD;

public interface Theme {
  int getBackgroundColor(int paramInt);
  
  int getShadowColor();
  
  int getBorderColor();
  
  int getTextColor(HUD paramHUD);
  
  int getSecondaryTextColor(int paramInt1, int paramInt2, HUD paramHUD);
  
  int getHeaderColor(HUD paramHUD);
  
  int getSeparatorColor(int paramInt);
  
  int getHealthBarBgColor();
  
  int getHealthBarColor(HUD paramHUD);
  
  int getItemPadding();
  
  int getBoxPadding();
  
  float getTextScale();
  
  int getRadius(int paramInt);
  
  boolean useShadows();
  
  boolean useBorders();
  
  boolean useCustomFont();
  
  int getGuiBackground();
  
  int getGuiCategoryBackground();
  
  int getGuiCategoryHeader();
  
  int getGuiModuleBackground();
  
  int getGuiSettingsBackground();
  
  int getGuiHoverColor();
  
  int getGuiBorderColor();
  
  int getGuiSeparatorColor();
  
  int getGuiTextColor();
  
  int getGuiEnabledTextColor();
  
  int getGuiDisabledTextColor();
  
  int getGuiAccentColor();
  
  boolean isModernStyle();
}


