package com.zcore.client.themes;

import com.zcore.client.gui.ZCoreGuiTheme;
import com.zcore.client.modules.client.HUD;





public class NeonTokyoTheme
  implements Theme
{
  private static final int BACKGROUND = -267385584;
  private static final int SHADOW = 1358889215;
  private static final int BORDER = -2130771713;
  private static final int TEXT = -65281;
  private static final int SECONDARY_TEXT = -16711681;
  private static final int HEADER_TEXT = -65281;
  private static final int SEPARATOR_RGB = 16711935;
  private static final int HEALTH_BAR_BG = -15070694;
  private static final int HEALTH_BAR = -65281;
  private static final int GUI_BACKGROUND = -15727344;
  private static final int GUI_CATEGORY_BG = -267056619;
  private static final int GUI_CATEGORY_HEADER = -266727654;
  private static final int GUI_MODULE_BG = -267253742;
  private static final int GUI_SETTINGS_BG = -267385584;
  private static final int GUI_BORDER = -1862336257;
  private static final int GUI_HOVER = -1325465345;
  private static final int GUI_SEPARATOR = 1627324671;
  private static final int GUI_TEXT = -65281;
  private static final int GUI_TEXT_ENABLED = -65281;
  private static final int GUI_TEXT_DISABLED = -16711681;
  
  public int getBackgroundColor(int alphaValue) {
    float alpha = Math.max(0.0F, Math.min(1.0F, alphaValue / 255.0F));
    return ZCoreGuiTheme.applyAlpha(1378837, alpha * 0.5F);
  }

  
  public int getShadowColor() {
    return 1358889215;
  }


  
  public int getBorderColor() {
    return -1862336257;
  }


  
  public int getTextColor(HUD hud) {
    return -1;
  }

  
  public int getSecondaryTextColor(int pixelY, int totalHeight, HUD hud) {
    return -1;
  }

  
  public int getHeaderColor(HUD hud) {
    return -1;
  }

  
  public int getSeparatorColor(int alphaValue) {
    int separatorAlpha = (int)(alphaValue * 0.35F);
    return separatorAlpha << 24 | 0xFF00FF;
  }

  
  public int getHealthBarBgColor() {
    return -15070694;
  }

  
  public int getHealthBarColor(HUD hud) {
    return -65281;
  }

  
  public int getItemPadding() {
    return 4;
  }

  
  public int getBoxPadding() {
    return 8;
  }

  
  public float getTextScale() {
    return 1.14F;
  }

  
  public int getRadius(int cornerRadius) {
    return 6;
  }

  
  public boolean useShadows() {
    return true;
  }

  
  public boolean useBorders() {
    return true;
  }

  
  public boolean useCustomFont() {
    return true;
  }


  
  public int getGuiBackground() {
    return -15727344;
  }

  
  public int getGuiCategoryBackground() {
    return -267056619;
  }

  
  public int getGuiCategoryHeader() {
    return -266727654;
  }

  
  public int getGuiModuleBackground() {
    return -267253742;
  }

  
  public int getGuiSettingsBackground() {
    return -267385584;
  }

  
  public int getGuiHoverColor() {
    return -1325465345;
  }

  
  public int getGuiBorderColor() {
    return -1862336257;
  }

  
  public int getGuiSeparatorColor() {
    return 1627324671;
  }

  
  public int getGuiTextColor() {
    return -65281;
  }

  
  public int getGuiEnabledTextColor() {
    return -65281;
  }

  
  public int getGuiDisabledTextColor() {
    return -16711681;
  }

  
  public int getGuiAccentColor() {
    return -65281;
  }

  
  public boolean isModernStyle() {
    return true;
  }
}


