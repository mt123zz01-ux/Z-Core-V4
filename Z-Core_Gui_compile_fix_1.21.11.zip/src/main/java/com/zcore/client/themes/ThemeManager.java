package com.zcore.client.themes;

import com.zcore.client.client.ZCoreClient;
import com.zcore.client.modules.client.Themes;

public class ThemeManager
{
  public static Theme getHudTheme() {
    if (ZCoreClient.moduleManager == null) return new DefaultTheme(); 
    Themes themesModule = (Themes)ZCoreClient.moduleManager.getModule(Themes.class);
    Themes.HudTheme theme = (themesModule != null) ? (Themes.HudTheme)themesModule.hudTheme.getValue() : Themes.HudTheme.MIDNIGHT;
    
    switch (theme) { default: throw new MatchException(null, null);case DEFAULT: case MIDNIGHT: case SCIFI: case NEBULA: case MATRIX: case OCEAN: case FOREST: case NEON_TOKYO: case CRYSTAL: break; }  return 







      
      new CrystalTheme();
  }

  
  public static Theme getClickGuiTheme() {
    if (ZCoreClient.moduleManager == null) return new DefaultTheme(); 
    Themes themesModule = (Themes)ZCoreClient.moduleManager.getModule(Themes.class);
    Themes.ClickGuiTheme theme = (themesModule != null) ? (Themes.ClickGuiTheme)themesModule.clickGuiTheme.getValue() : Themes.ClickGuiTheme.MIDNIGHT;
    
    switch (theme) { default: throw new MatchException(null, null);case DEFAULT: case MIDNIGHT: case SCIFI: case NEBULA: case MATRIX: case OCEAN: case FOREST: case NEON_TOKYO: case CRYSTAL: break; }  return 







      
      new CrystalTheme();
  }
}


