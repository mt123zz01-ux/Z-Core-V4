package com.zcore.client.themes;

import com.zcore.client.gui.ZCoreGuiTheme;
import com.zcore.client.modules.client.HUD;





public class OceanTheme
  implements Theme
{
  private static final int BACKGROUND = -268363218;
  private static final int SHADOW = 1073794769;
  private static final int BORDER = 1610665681;
  private static final int TEXT = -16724271;
  private static final int SECONDARY_TEXT = -10510688;
  private static final int HEADER_TEXT = -16718337;
  private static final int SEPARATOR_RGB = 52945;
  private static final int HEALTH_BAR_BG = -16111042;
  private static final int HEALTH_BAR = -16724271;
  private static final int GUI_BACKGROUND = -16704978;
  private static final int GUI_CATEGORY_BG = -268099787;
  private static final int GUI_CATEGORY_HEADER = -267901632;
  private static final int GUI_MODULE_BG = -268231632;
  private static final int GUI_SETTINGS_BG = -268298198;
  private static final int GUI_BORDER = 1879101137;
  private static final int GUI_HOVER = -1878995247;
  private static final int GUI_SEPARATOR = 1342230225;
  private static final int GUI_TEXT = -16724271;
  private static final int GUI_TEXT_ENABLED = -16718337;
  private static final int GUI_TEXT_DISABLED = -10510688;
  
  public int getBackgroundColor(int alphaValue) {
    float alpha = Math.max(0.0F, Math.min(1.0F, alphaValue / 255.0F));
    return ZCoreGuiTheme.applyAlpha(335669, alpha * 0.5F);
  }

  
  public int getShadowColor() {
    return 1073794769;
  }


  
  public int getBorderColor() {
    return 1879101137;
  }


  
  public int getTextColor(HUD hud) {
    return -1;
  }

  
  public int getSecondaryTextColor(int pixelY, int totalHeight, HUD hud) {
    return -1;
  }

  
  public int getHeaderColor(HUD hud) {
    return -1;
  }

  
  public int getSeparatorColor(int alphaValue) {
    int separatorAlpha = (int)(alphaValue * 0.25F);
    return separatorAlpha << 24 | 0xCED1;
  }

  
  public int getHealthBarBgColor() {
    return -16111042;
  }

  
  public int getHealthBarColor(HUD hud) {
    return -16724271;
  }

  
  public int getItemPadding() {
    return 4;
  }

  
  public int getBoxPadding() {
    return 8;
  }

  
  public float getTextScale() {
    return 1.14F;
  }

  
  public int getRadius(int cornerRadius) {
    return 7;
  }

  
  public boolean useShadows() {
    return true;
  }

  
  public boolean useBorders() {
    return true;
  }

  
  public boolean useCustomFont() {
    return true;
  }


  
  public int getGuiBackground() {
    return -16704978;
  }

  
  public int getGuiCategoryBackground() {
    return -268099787;
  }

  
  public int getGuiCategoryHeader() {
    return -267901632;
  }

  
  public int getGuiModuleBackground() {
    return -268231632;
  }

  
  public int getGuiSettingsBackground() {
    return -268298198;
  }

  
  public int getGuiHoverColor() {
    return -1878995247;
  }

  
  public int getGuiBorderColor() {
    return 1879101137;
  }

  
  public int getGuiSeparatorColor() {
    return 1342230225;
  }

  
  public int getGuiTextColor() {
    return -16724271;
  }

  
  public int getGuiEnabledTextColor() {
    return -16718337;
  }

  
  public int getGuiDisabledTextColor() {
    return -10510688;
  }

  
  public int getGuiAccentColor() {
    return -16724271;
  }

  
  public boolean isModernStyle() {
    return true;
  }
}


