package com.zcore.client.themes;

import com.zcore.client.gui.ZCoreGuiTheme;
import com.zcore.client.modules.client.HUD;



public class DefaultTheme
  implements Theme
{
  private static final int BACKGROUND = -16250868;
  private static final int CATEGORY_BG = -15527654;
  private static final int CATEGORY_HEADER = -14936026;
  private static final int MODULE_BG = -15330782;
  private static final int SETTINGS_BG = -15790824;
  private static final int BORDER = -11850354;
  private static final int HOVER = -14016699;
  private static final int SEPARATOR = -13424302;
  private static final int TEXT = -1;
  private static final int TEXT_ENABLED = -1;
  private static final int TEXT_DISABLED = -5726016;
  
  public int getBackgroundColor(int alphaValue) {
    float alpha = Math.max(0.0F, Math.min(1.0F, alphaValue / 255.0F));
    return ZCoreGuiTheme.applyAlpha(1249562, alpha * 0.5F);
  }

  
  public int getShadowColor() {
    return 0;
  }

  
  public int getBorderColor() {
    return 0;
  }

  
  public int getTextColor(HUD hud) {
    return hud.getHudColorInt();
  }

  
  public int getSecondaryTextColor(int pixelY, int totalHeight, HUD hud) {
    return hud.getColorAtHeight(pixelY, totalHeight);
  }

  
  public int getHeaderColor(HUD hud) {
    return hud.getHudColorInt();
  }

  
  public int getSeparatorColor(int alphaValue) {
    int separatorAlpha = (int)(alphaValue * 0.15F);
    return separatorAlpha << 24 | 0xFFFFFF;
  }

  
  public int getHealthBarBgColor() {
    return 1073741824;
  }

  
  public int getHealthBarColor(HUD hud) {
    return hud.getHudColorInt();
  }

  
  public int getItemPadding() {
    return 4;
  }

  
  public int getBoxPadding() {
    return 8;
  }

  
  public float getTextScale() {
    return 1.235F;
  }

  
  public int getRadius(int cornerRadius) {
    return cornerRadius * 2;
  }

  
  public boolean useShadows() {
    return false;
  }

  
  public boolean useBorders() {
    return false;
  }

  
  public boolean useCustomFont() {
    return false;
  }


  
  public int getGuiBackground() {
    return -16250868;
  }

  
  public int getGuiCategoryBackground() {
    return -15527654;
  }

  
  public int getGuiCategoryHeader() {
    return -14936026;
  }

  
  public int getGuiModuleBackground() {
    return -15330782;
  }

  
  public int getGuiSettingsBackground() {
    return -15790824;
  }

  
  public int getGuiHoverColor() {
    return -14016699;
  }

  
  public int getGuiBorderColor() {
    return -11850354;
  }

  
  public int getGuiSeparatorColor() {
    return -13424302;
  }

  
  public int getGuiTextColor() {
    return -1;
  }

  
  public int getGuiEnabledTextColor() {
    return -1;
  }

  
  public int getGuiDisabledTextColor() {
    return -5726016;
  }

  
  public int getGuiAccentColor() {
    return -6596122;
  }

  
  public boolean isModernStyle() {
    return false;
  }
}


