package com.zcore.client.themes;

import com.zcore.client.gui.ZCoreGuiTheme;
import com.zcore.client.modules.client.HUD;





public class NebulaTheme
  implements Theme
{
  private static final int BACKGROUND = -267777510;
  private static final int SHADOW = 1351112191;
  private static final int BORDER = 1889097215;
  private static final int TEXT = -5601025;
  private static final int SECONDARY_TEXT = -7824897;
  private static final int HEADER_TEXT = -4482561;
  private static final int SEPARATOR_RGB = 10049023;
  private static final int HEALTH_BAR_BG = -15066578;
  private static final int HEALTH_BAR = -5601025;
  private static final int GUI_BACKGROUND = -16119270;
  private static final int GUI_CATEGORY_BG = -267053787;
  private static final int GUI_CATEGORY_HEADER = -266330064;
  private static final int GUI_MODULE_BG = -267251166;
  private static final int GUI_SETTINGS_BG = -267382752;
  private static final int GUI_BORDER = -2137434625;
  private static final int GUI_HOVER = -1601677825;
  private static final int GUI_SEPARATOR = 1619547647;
  private static final int GUI_TEXT = -5601025;
  private static final int GUI_TEXT_ENABLED = -4482561;
  private static final int GUI_TEXT_DISABLED = -7824982;
  
  public int getBackgroundColor(int alphaValue) {
    float alpha = Math.max(0.0F, Math.min(1.0F, alphaValue / 255.0F));
    return ZCoreGuiTheme.applyAlpha(1381669, alpha * 0.5F);
  }

  
  public int getShadowColor() {
    return 1351112191;
  }


  
  public int getBorderColor() {
    return -2137434625;
  }


  
  public int getTextColor(HUD hud) {
    return -1;
  }

  
  public int getSecondaryTextColor(int pixelY, int totalHeight, HUD hud) {
    return -1;
  }

  
  public int getHeaderColor(HUD hud) {
    return -1;
  }

  
  public int getSeparatorColor(int alphaValue) {
    int separatorAlpha = (int)(alphaValue * 0.3F);
    return separatorAlpha << 24 | 0x9955FF;
  }

  
  public int getHealthBarBgColor() {
    return -15066578;
  }

  
  public int getHealthBarColor(HUD hud) {
    return -5601025;
  }

  
  public int getItemPadding() {
    return 4;
  }

  
  public int getBoxPadding() {
    return 8;
  }

  
  public float getTextScale() {
    return 1.14F;
  }

  
  public int getRadius(int cornerRadius) {
    return 7;
  }

  
  public boolean useShadows() {
    return true;
  }

  
  public boolean useBorders() {
    return true;
  }

  
  public boolean useCustomFont() {
    return true;
  }


  
  public int getGuiBackground() {
    return -16119270;
  }

  
  public int getGuiCategoryBackground() {
    return -267053787;
  }

  
  public int getGuiCategoryHeader() {
    return -266330064;
  }

  
  public int getGuiModuleBackground() {
    return -267251166;
  }

  
  public int getGuiSettingsBackground() {
    return -267382752;
  }

  
  public int getGuiHoverColor() {
    return -1601677825;
  }

  
  public int getGuiBorderColor() {
    return -2137434625;
  }

  
  public int getGuiSeparatorColor() {
    return 1619547647;
  }

  
  public int getGuiTextColor() {
    return -5601025;
  }

  
  public int getGuiEnabledTextColor() {
    return -4482561;
  }

  
  public int getGuiDisabledTextColor() {
    return -7824982;
  }

  
  public int getGuiAccentColor() {
    return -5601025;
  }

  
  public boolean isModernStyle() {
    return true;
  }
}


