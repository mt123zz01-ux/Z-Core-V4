package com.zcore.client.themes;

import com.zcore.client.modules.client.HUD;






public class MidnightTheme
  implements Theme
{
  private static final int BACKGROUND = -536542710;
  private static final int SHADOW = 1342177280;
  private static final int BORDER = 812253439;
  private static final int TEXT = -988181;
  private static final int SECONDARY_TEXT = -6386805;
  private static final int HEADER_TEXT = -2372918;
  private static final int SEPARATOR_RGB = 4915330;
  private static final int HEALTH_BAR_BG = -15596256;
  private static final int HEALTH_BAR = -6596122;
  private static final int GUI_BACKGROUND = -16580347;
  private static final int GUI_CATEGORY_BG = -536215022;
  private static final int GUI_CATEGORY_HEADER = -267189467;
  private static final int GUI_MODULE_BG = -267582952;
  private static final int GUI_SETTINGS_BG = -267910896;
  private static final int GUI_BORDER = 1083922918;
  private static final int GUI_HOVER = 1354265599;
  private static final int GUI_SEPARATOR = 812253439;
  private static final int GUI_TEXT = -986896;
  private static final int GUI_TEXT_ENABLED = -6596122;
  private static final int GUI_TEXT_DISABLED = -6642504;
  
  public int getBackgroundColor(int alphaValue) {
    return 0;
  }

  
  public int getShadowColor() {
    return 1342177280;
  }


  
  public int getBorderColor() {
    return 1083922918;
  }


  
  public int getTextColor(HUD hud) {
    return -1;
  }

  
  public int getSecondaryTextColor(int pixelY, int totalHeight, HUD hud) {
    return -1;
  }

  
  public int getHeaderColor(HUD hud) {
    return -1;
  }

  
  public int getSeparatorColor(int alphaValue) {
    int separatorAlpha = (int)(alphaValue * 0.15F);
    return separatorAlpha << 24 | 0x4B0082;
  }

  
  public int getHealthBarBgColor() {
    return -15596256;
  }

  
  public int getHealthBarColor(HUD hud) {
    return -6596122;
  }

  
  public int getItemPadding() {
    return 4;
  }

  
  public int getBoxPadding() {
    return 8;
  }

  
  public float getTextScale() {
    return 1.14F;
  }

  
  public int getRadius(int cornerRadius) {
    return 7;
  }

  
  public boolean useShadows() {
    return false;
  }

  
  public boolean useBorders() {
    return false;
  }

  
  public boolean useCustomFont() {
    return true;
  }


  
  public int getGuiBackground() {
    return -16580347;
  }

  
  public int getGuiCategoryBackground() {
    return -536215022;
  }

  
  public int getGuiCategoryHeader() {
    return -267189467;
  }

  
  public int getGuiModuleBackground() {
    return -267582952;
  }

  
  public int getGuiSettingsBackground() {
    return -267910896;
  }

  
  public int getGuiHoverColor() {
    return 1354265599;
  }

  
  public int getGuiBorderColor() {
    return 1083922918;
  }

  
  public int getGuiSeparatorColor() {
    return 812253439;
  }

  
  public int getGuiTextColor() {
    return -986896;
  }

  
  public int getGuiEnabledTextColor() {
    return -6596122;
  }

  
  public int getGuiDisabledTextColor() {
    return -6642504;
  }

  
  public int getGuiAccentColor() {
    return -6596122;
  }

  
  public boolean isModernStyle() {
    return true;
  }
}


