package com.zcore.client.events.event;

import com.zcore.client.events.CancellableEvent;
import java.util.ArrayList;
import net.minecraft.class_2596;





public class PacketReceiveEvent
  extends CancellableEvent<PacketReceiveListener>
{
  public class_2596<?> packet;
  
  public PacketReceiveEvent(class_2596<?> packet) {
    this.packet = packet;
  }

  
  public void fire(ArrayList<PacketReceiveListener> listeners) {
    listeners.forEach(listener -> listener.onPacketReceive(this));
  }

  
  public Class<PacketReceiveListener> getListenerType() {
    return PacketReceiveListener.class;
  }
}


