package com.zcore.client.events.event;

import com.zcore.client.events.CancellableEvent;
import java.util.ArrayList;






public class ItemUseEvent
  extends CancellableEvent<ItemUseListener>
{
  public void fire(ArrayList<ItemUseListener> listeners) {
    listeners.forEach(e -> e.onItemUse(this));
  }

  
  public Class<ItemUseListener> getListenerType() {
    return ItemUseListener.class;
  }
}


