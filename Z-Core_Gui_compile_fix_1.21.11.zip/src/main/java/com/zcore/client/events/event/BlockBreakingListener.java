package com.zcore.client.events.event;

import com.zcore.client.events.CancellableEvent;
import com.zcore.client.events.Listener;
import java.util.ArrayList;

public interface BlockBreakingListener
  extends Listener
{
  void onBlockBreaking(BlockBreakingEvent paramBlockBreakingEvent);
  
  public static class BlockBreakingEvent
    extends CancellableEvent<BlockBreakingListener>
  {
    public void fire(ArrayList<BlockBreakingListener> listeners) {
      listeners.forEach(e -> e.onBlockBreaking(this));
    }

    
    public Class<BlockBreakingListener> getListenerType() {
      return BlockBreakingListener.class;
    }
  }
}


