package com.zcore.client.events.event;

import com.zcore.client.events.CancellableEvent;
import java.util.ArrayList;
import net.minecraft.class_437;





public class OpenScreenEvent
  extends CancellableEvent<OpenScreenListener>
{
  public class_437 screen;
  
  public OpenScreenEvent(class_437 screen) {
    this.screen = screen;
  }

  
  public void fire(ArrayList<OpenScreenListener> listeners) {
    listeners.forEach(e -> e.onOpenScreen(this));
  }

  
  public Class<OpenScreenListener> getListenerType() {
    return OpenScreenListener.class;
  }
}


