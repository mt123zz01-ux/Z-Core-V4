package com.zcore.client.events.event;

import com.zcore.client.events.CancellableEvent;
import com.zcore.client.events.Listener;
import java.util.ArrayList;
import net.minecraft.class_1297;

public interface AttackListener2
  extends Listener {
  void onAttack(AttackEvent2 paramAttackEvent2);
  
  public static class AttackEvent2
    extends CancellableEvent<AttackListener2> {
    public final class_1297 entity;
    
    public AttackEvent2(class_1297 entity) {
      this.entity = entity;
    }

    
    public void fire(ArrayList<AttackListener2> listeners) {
      listeners.forEach(e -> e.onAttack(this));
    }

    
    public Class<AttackListener2> getListenerType() {
      return AttackListener2.class;
    }
  }
}


