package com.zcore.client.events.event;

import com.zcore.client.events.CancellableEvent;
import java.util.ArrayList;
import net.minecraft.class_2596;





public class PacketSendEvent
  extends CancellableEvent<PacketSendListener>
{
  public class_2596<?> packet;
  
  public PacketSendEvent(class_2596<?> packet) {
    this.packet = packet;
  }

  
  public void fire(ArrayList<PacketSendListener> listeners) {
    for (PacketSendListener listener : listeners) {
      listener.onPacketSend(this);
    }
  }

  
  public Class<PacketSendListener> getListenerType() {
    return PacketSendListener.class;
  }
}


