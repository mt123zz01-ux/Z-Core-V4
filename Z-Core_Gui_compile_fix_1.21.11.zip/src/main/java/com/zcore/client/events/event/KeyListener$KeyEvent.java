package com.zcore.client.events.event;

import com.zcore.client.events.CancellableEvent;
import java.util.ArrayList;





public class KeyEvent
  extends CancellableEvent<KeyListener>
{
  public int key;
  public int mode;
  public long window;
  
  public KeyEvent(int key, int mode, long window) {
    this.key = key;
    this.mode = mode;
    this.window = window;
  }

  
  public void fire(ArrayList<KeyListener> listeners) {
    listeners.forEach(e -> e.onKey(this));
  }

  
  public Class<KeyListener> getListenerType() {
    return KeyListener.class;
  }
}


