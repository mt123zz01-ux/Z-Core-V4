package com.zcore.client.events;

import com.zcore.client.client.ZCoreClient;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;

public final class EventManager {
    private final HashMap<Class<? extends Listener>, ArrayList<PrioritizedListener<? extends Listener>>> listenerMap = new HashMap<>();

    public static <L extends Listener, E extends Event<L>> void fire(E event) {
        EventManager eventManager = ZCoreClient.getEventManager();
        if (eventManager != null) eventManager.fireImpl(event);
    }

    @SuppressWarnings("unchecked")
    private <L extends Listener, E extends Event<L>> void fireImpl(E event) {
        Class<L> listenerType = event.getListenerType();
        ArrayList<PrioritizedListener<L>> listeners = (ArrayList<PrioritizedListener<L>>) (ArrayList<?>) listenerMap.get(listenerType);
        if (listeners == null || listeners.isEmpty()) return;

        ArrayList<PrioritizedListener<L>> copy = new ArrayList<>(listeners);
        copy.removeIf(java.util.Objects::isNull);
        copy.sort(Comparator.comparingInt(l -> Integer.MAX_VALUE - l.priority()));

        ArrayList<L> plainListeners = new ArrayList<>();
        for (PrioritizedListener<L> listener : copy) plainListeners.add(listener.listener());
        event.fire(plainListeners);
    }

    public <L extends Listener> void add(Class<L> type, L listener) {
        add(type, listener, 0);
    }

    @SuppressWarnings("unchecked")
    public <L extends Listener> void add(Class<L> type, L listener, int priority) {
        ArrayList<PrioritizedListener<L>> listeners = (ArrayList<PrioritizedListener<L>>) (ArrayList<?>) listenerMap.get(type);
        if (listeners == null) {
            listeners = new ArrayList<>();
            listenerMap.put(type, (ArrayList<PrioritizedListener<? extends Listener>>) (ArrayList<?>) listeners);
        }
        listeners.add(new PrioritizedListener<>(listener, priority));
    }

    @SuppressWarnings("unchecked")
    public <L extends Listener> void remove(Class<L> type, L listener) {
        ArrayList<PrioritizedListener<L>> listeners = (ArrayList<PrioritizedListener<L>>) (ArrayList<?>) listenerMap.get(type);
        if (listeners != null) listeners.removeIf(l -> l.listener().equals(listener));
    }

    private record PrioritizedListener<L extends Listener>(L listener, int priority) {}
}
