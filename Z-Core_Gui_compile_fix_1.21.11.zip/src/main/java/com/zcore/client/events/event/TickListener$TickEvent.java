package com.zcore.client.events.event;

import com.zcore.client.events.Event;
import java.util.ArrayList;







public class TickEvent
  extends Event<TickListener>
{
  public void fire(ArrayList<TickListener> listeners) {
    listeners.forEach(TickListener::onTick2);
  }

  
  public Class<TickListener> getListenerType() {
    return TickListener.class;
  }
}


