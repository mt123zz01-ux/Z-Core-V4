package com.zcore.client.events.event;

import com.zcore.client.events.CancellableEvent;
import com.zcore.client.events.Listener;
import java.util.ArrayList;

public interface MouseMoveListener
  extends Listener {
  void onMouseMove(MouseMoveEvent paramMouseMoveEvent);
  
  public static class MouseMoveEvent extends CancellableEvent<MouseMoveListener> {
    public double x;
    public double y;
    
    public MouseMoveEvent(double x, double y) {
      this.x = x;
      this.y = y;
    }

    
    public void fire(ArrayList<MouseMoveListener> listeners) {
      listeners.forEach(listener -> listener.onMouseMove(this));
    }

    
    public Class<MouseMoveListener> getListenerType() {
      return MouseMoveListener.class;
    }
  }
}


