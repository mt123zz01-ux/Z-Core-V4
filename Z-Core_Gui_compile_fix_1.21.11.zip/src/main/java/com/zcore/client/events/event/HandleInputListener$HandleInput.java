package com.zcore.client.events.event;

import com.zcore.client.events.Event;
import java.util.ArrayList;







public class HandleInput
  extends Event<HandleInputListener>
{
  public void fire(ArrayList<HandleInputListener> listeners) {
    listeners.forEach(HandleInputListener::onHandleInput);
  }

  
  public Class<HandleInputListener> getListenerType() {
    return HandleInputListener.class;
  }
}


