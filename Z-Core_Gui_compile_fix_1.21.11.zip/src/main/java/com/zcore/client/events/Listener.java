package com.zcore.client.events;

import java.util.EventListener;

public interface Listener extends EventListener {}


