package com.zcore.client.events.event;

import com.zcore.client.events.CancellableEvent;
import java.util.ArrayList;







public class AttackEvent
  extends CancellableEvent<AttackListener>
{
  public void fire(ArrayList<AttackListener> listeners) {
    listeners.forEach(e -> e.onAttack(this));
  }

  
  public Class<AttackListener> getListenerType() {
    return AttackListener.class;
  }
}


