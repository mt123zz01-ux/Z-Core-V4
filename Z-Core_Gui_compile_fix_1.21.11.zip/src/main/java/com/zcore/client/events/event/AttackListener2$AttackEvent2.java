package com.zcore.client.events.event;

import com.zcore.client.events.CancellableEvent;
import java.util.ArrayList;
import net.minecraft.class_1297;





public class AttackEvent2
  extends CancellableEvent<AttackListener2>
{
  public final class_1297 entity;
  
  public AttackEvent2(class_1297 entity) {
    this.entity = entity;
  }

  
  public void fire(ArrayList<AttackListener2> listeners) {
    listeners.forEach(e -> e.onAttack(this));
  }

  
  public Class<AttackListener2> getListenerType() {
    return AttackListener2.class;
  }
}


