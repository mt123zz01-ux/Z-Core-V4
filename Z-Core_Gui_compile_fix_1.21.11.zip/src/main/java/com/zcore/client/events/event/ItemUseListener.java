package com.zcore.client.events.event;

import com.zcore.client.events.CancellableEvent;
import com.zcore.client.events.Listener;
import java.util.ArrayList;

public interface ItemUseListener
  extends Listener
{
  void onItemUse(ItemUseEvent paramItemUseEvent);
  
  public static class ItemUseEvent
    extends CancellableEvent<ItemUseListener> {
    public void fire(ArrayList<ItemUseListener> listeners) {
      listeners.forEach(e -> e.onItemUse(this));
    }

    
    public Class<ItemUseListener> getListenerType() {
      return ItemUseListener.class;
    }
  }
}


