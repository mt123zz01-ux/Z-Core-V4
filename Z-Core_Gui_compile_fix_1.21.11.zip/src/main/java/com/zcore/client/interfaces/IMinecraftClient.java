package com.zcore.client.interfaces;

public interface IMinecraftClient {
  void setItemUseCooldown(int paramInt);
}


