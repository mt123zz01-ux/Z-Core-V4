package com.zcore.client.gui.settings;

public class RandomBetweenDoubleSetting extends MinMaxSetting {
    public RandomBetweenDoubleSetting(String name, double minDefault, double maxDefault) { super(name, minDefault, maxDefault); }
}
