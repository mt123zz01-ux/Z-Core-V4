package com.zcore.client.gui.utils;

import com.zcore.client.gui.ZCoreGuiTheme;
import net.minecraft.class_332;

public class ScrollHandler
{
  private final float scrollSmoothing = 0.2F;
  private float scrollOffset = 0.0F;
  private float maxScroll = 0.0F;
  private boolean isDragging = false;
  private float targetScroll = 0.0F;
  private float currentScroll = 0.0F;
  
  public void setMaxScroll(float maxScroll) {
    this.maxScroll = Math.max(0.0F, maxScroll);
    if (this.scrollOffset > this.maxScroll) {
      this.scrollOffset = this.maxScroll;
      this.targetScroll = this.maxScroll;
    } 
  }
  
  public void scroll(double amount) {
    this.targetScroll = (float)(this.targetScroll - amount * 10.0D);
    this.targetScroll = Math.max(0.0F, Math.min(this.targetScroll, this.maxScroll));
  }
  
  public void update() {
    if (Math.abs(this.targetScroll - this.currentScroll) > 0.1F) {
      this.currentScroll += (this.targetScroll - this.currentScroll) * 0.2F;
    } else {
      this.currentScroll = this.targetScroll;
    } 
    this.scrollOffset = this.currentScroll;
  }

  
  public boolean handleScroll(double mouseX, double mouseY, double hAmount, double vAmount, int panelX, int panelY, int panelWidth) {
    if (GuiUtils.isHovered(mouseX, mouseY, panelX, panelY, panelWidth, 200) && 
      this.maxScroll > 0.0F) {
      scroll(vAmount);
      return true;
    } 
    
    return false;
  }

  
  public boolean handleScrollbarDrag(double mouseX, double mouseY, int panelX, int panelY, int panelWidth, int panelHeight) {
    if (this.maxScroll <= 0.0F) return false;
    
    int scrollBarX = panelX + panelWidth - 6;
    int scrollBarY = panelY;
    
    if (GuiUtils.isHovered(mouseX, mouseY, scrollBarX, scrollBarY, 6, panelHeight)) {
      float scrollRatio = (float)(mouseY - scrollBarY) / panelHeight;
      this.targetScroll = scrollRatio * this.maxScroll;
      this.targetScroll = Math.max(0.0F, Math.min(this.targetScroll, this.maxScroll));
      this.isDragging = true;
      return true;
    } 
    
    return false;
  }

  
  public void renderScrollbar(class_332 context, int panelX, int panelY, int panelWidth, float animationProgress) {
    if (this.maxScroll <= 0.0F)
      return; 
    int scrollBarX = panelX + panelWidth - 6;
    int scrollBarY = panelY + 18;
    int scrollBarHeight = 150;
    int scrollBarWidth = 4;
    
    GuiUtils.drawRoundedRect(context, scrollBarX, scrollBarY, scrollBarWidth, scrollBarHeight, 2, 
        ZCoreGuiTheme.applyAlpha(1342177280, animationProgress));
    
    float scrollProgress = this.scrollOffset / this.maxScroll;
    int handleHeight = Math.max(20, (int)(0.3F * scrollBarHeight));
    int handleY = scrollBarY + (int)((scrollBarHeight - handleHeight) * scrollProgress);
    
    GuiUtils.drawRoundedRect(context, scrollBarX, handleY, scrollBarWidth, handleHeight, 2, 
        ZCoreGuiTheme.applyAlpha(ZCoreGuiTheme.getAccentColor(), animationProgress));
  }
  
  public void stopDrag() {
    this.isDragging = false;
  }
  
  public boolean isDragging() {
    return this.isDragging;
  }
  
  public int getScrollOffset() {
    return -((int)this.scrollOffset);
  }
  
  public void reset() {
    this.scrollOffset = 0.0F;
    this.targetScroll = 0.0F;
    this.currentScroll = 0.0F;
    this.maxScroll = 0.0F;
  }
}


