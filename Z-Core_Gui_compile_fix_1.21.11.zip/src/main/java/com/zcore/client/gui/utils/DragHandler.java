package com.zcore.client.gui.utils;

import net.minecraft.class_310;

public class DragHandler
{
  private final int animationDuration = 300;
  private final class_310 client = class_310.method_1551();
  private boolean isDragging = false;
  private int dragOffsetX = 0;
  private int dragOffsetY = 0;
  private int targetX = 0;
  private int targetY = 0;
  private float currentX = 0.0F;
  private float currentY = 0.0F;
  private long animationStartTime = 0L;
  private boolean isAnimating = false;
  
  public void startDrag(double mouseX, double mouseY, int elementX, int elementY) {
    this.isDragging = true;
    this.dragOffsetX = (int)mouseX - elementX;
    this.dragOffsetY = (int)mouseY - elementY;
    this.currentX = elementX;
    this.currentY = elementY;
    this.targetX = elementX;
    this.targetY = elementY;
    this.isAnimating = false;
  }
  
  public int[] updatePosition(double mouseX, double mouseY) {
    if (!this.isDragging) return new int[] { this.targetX, this.targetY };
    
    int newX = (int)mouseX - this.dragOffsetX;
    int newY = (int)mouseY - this.dragOffsetY;

    
    if (this.client != null && this.client.method_22683() != null) {
      int screenWidth = this.client.method_22683().method_4480();
      int screenHeight = this.client.method_22683().method_4507();

      
      newX = Math.max(-50, Math.min(screenWidth - 50, newX));
      newY = Math.max(0, Math.min(screenHeight - 50, newY));
    } else {
      
      newX = Math.max(0, newX);
      newY = Math.max(0, newY);
    } 
    
    this.targetX = newX;
    this.targetY = newY;
    this.currentX = newX;
    this.currentY = newY;
    
    return new int[] { newX, newY };
  }
  
  public void stopDrag() {
    if (this.isDragging) {
      this.isDragging = false;
      this.isAnimating = true;
      this.animationStartTime = System.currentTimeMillis();
    } 
  }
  
  public int[] getAnimatedPosition() {
    if (this.isDragging)
    {
      return new int[] { this.targetX, this.targetY };
    }
    
    if (!this.isAnimating) {
      return new int[] { this.targetX, this.targetY };
    }
    
    long elapsed = System.currentTimeMillis() - this.animationStartTime;
    float progress = Math.min(1.0F, (float)elapsed / 300.0F);
    progress = easeOutCubic(progress);
    
    if (progress >= 1.0F) {
      this.isAnimating = false;
      this.currentX = this.targetX;
      this.currentY = this.targetY;
    } else {
      
      float deltaX = this.targetX - this.currentX;
      float deltaY = this.targetY - this.currentY;
      this.currentX += deltaX * progress * 0.3F;
      this.currentY += deltaY * progress * 0.3F;
    } 
    
    return new int[] { Math.round(this.currentX), Math.round(this.currentY) };
  }
  
  private float easeOutCubic(float t) {
    return 1.0F - (float)Math.pow((1.0F - t), 3.0D);
  }
  
  public boolean isDragging() {
    return this.isDragging;
  }
  
  public boolean isAnimating() {
    return this.isAnimating;
  }

  
  public void setScreenBounds(int width, int height, int elementWidth, int elementHeight) {
    this.targetX = Math.max(0, Math.min(width - elementWidth, this.targetX));
    this.targetY = Math.max(0, Math.min(height - elementHeight, this.targetY));
    
    if (!this.isDragging) {
      this.currentX = this.targetX;
      this.currentY = this.targetY;
    } 
  }
  
  public void setPosition(int x, int y) {
    this.targetX = x;
    this.targetY = y;
    this.currentX = x;
    this.currentY = y;
    this.isAnimating = false;
    this.isDragging = false;
  }
}


