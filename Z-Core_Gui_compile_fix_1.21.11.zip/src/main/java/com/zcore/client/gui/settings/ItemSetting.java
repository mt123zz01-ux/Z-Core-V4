package com.zcore.client.gui.settings;

import net.minecraft.class_1792;

public class ItemSetting
  extends Setting<class_1792> {
  public ItemSetting(String name, class_1792 defaultValue) {
    super(name, defaultValue);
  }
  
  public class_1792 getItem() {
    return getValue();
  }
}


