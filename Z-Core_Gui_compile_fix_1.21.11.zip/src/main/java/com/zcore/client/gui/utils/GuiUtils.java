package com.zcore.client.gui.utils;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_332;
import org.joml.Matrix4f;

public class GuiUtils {
  public static boolean isHovered(double mx, double my, int x, int y, int width, int height) {
    return (mx >= x && mx <= (x + width) && my >= y && my <= (y + height));
  }

  
  public static void drawRoundedRect(class_332 context, int x, int y, int width, int height, int radius, int color) {
    if (radius <= 0) {
      context.method_25294(x, y, x + width, y + height, color);
      
      return;
    } 
    radius = Math.min(radius, Math.min(width, height) / 2);
    Matrix4f matrix = context.method_51448().method_23760().method_23761();
    
    float r = (color >> 16 & 0xFF) / 255.0F;
    float g = (color >> 8 & 0xFF) / 255.0F;
    float b = (color & 0xFF) / 255.0F;
    float a = (color >> 24 & 0xFF) / 255.0F;
    
    RenderSystem.enableBlend();
    RenderSystem.setShader(class_10142.field_53876);
    
    class_287 bufferBuilder = class_289.method_1348().method_60827(class_293.class_5596.field_27381, class_290.field_1576);

    
    bufferBuilder.method_22918(matrix, (x + radius), (y + radius), 0.0F).method_22915(r, g, b, a);
    bufferBuilder.method_22918(matrix, (x + radius), (y + height - radius), 0.0F).method_22915(r, g, b, a);
    bufferBuilder.method_22918(matrix, (x + width - radius), (y + height - radius), 0.0F).method_22915(r, g, b, a);
    bufferBuilder.method_22918(matrix, (x + width - radius), (y + radius), 0.0F).method_22915(r, g, b, a);
    class_286.method_43433(bufferBuilder.method_60800());

    
    context.method_25294(x + radius, y, x + width - radius, y + radius, color);
    context.method_25294(x + radius, y + height - radius, x + width - radius, y + height, color);
    context.method_25294(x, y + radius, x + radius, y + height - radius, color);
    context.method_25294(x + width - radius, y + radius, x + width, y + height - radius, color);

    
    drawCorner(matrix, x, y, radius, r, g, b, a, 180, 270);
    drawCorner(matrix, x + width - radius, y, radius, r, g, b, a, 270, 360);
    drawCorner(matrix, x + width - radius, y + height - radius, radius, r, g, b, a, 0, 90);
    drawCorner(matrix, x, y + height - radius, radius, r, g, b, a, 90, 180);
    
    RenderSystem.disableBlend();
  }
  
  private static void drawCorner(Matrix4f matrix, int x, int y, int radius, float r, float g, float b, float a, int startAngle, int endAngle) {
    class_287 bufferBuilder = class_289.method_1348().method_60827(class_293.class_5596.field_27381, class_290.field_1576);
    bufferBuilder.method_22918(matrix, (x + radius), (y + radius), 0.0F).method_22915(r, g, b, a);
    
    for (int i = startAngle; i <= endAngle; i += 3) {
      double angle = Math.toRadians(i);
      bufferBuilder.method_22918(matrix, (float)((x + radius) + Math.cos(angle) * radius), (float)((y + radius) + Math.sin(angle) * radius), 0.0F).method_22915(r, g, b, a);
    } 
    class_286.method_43433(bufferBuilder.method_60800());
  }
}


