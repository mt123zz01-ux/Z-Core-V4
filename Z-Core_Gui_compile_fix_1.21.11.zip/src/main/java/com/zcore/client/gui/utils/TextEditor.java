package com.zcore.client.gui.utils;

import net.minecraft.class_310;
import net.minecraft.class_437;


public class TextEditor
{
  private final class_310 client = class_310.method_1551();
  private String text = "";
  private int cursorPosition = 0;
  private int selectionStart = -1;
  private int selectionEnd = -1;
  private boolean isActive = false;
  
  public void startEditing(String initialText) {
    this.text = (initialText != null) ? initialText : "";
    this.cursorPosition = this.text.length();
    this.selectionStart = -1;
    this.selectionEnd = -1;
    this.isActive = true;
  }
  
  public void stopEditing() {
    this.isActive = false;
  }
  
  public void cancelEditing() {
    this.text = "";
    this.cursorPosition = 0;
    this.selectionStart = -1;
    this.selectionEnd = -1;
    this.isActive = false;
  }
  
  private boolean hasSelection() {
    return (this.selectionStart != -1 && this.selectionEnd != -1 && this.selectionStart != this.selectionEnd);
  }
  
  private int getSelectionStartPos() {
    if (!hasSelection()) return this.cursorPosition; 
    return Math.min(this.selectionStart, this.selectionEnd);
  }
  
  private int getSelectionEndPos() {
    if (!hasSelection()) return this.cursorPosition; 
    return Math.max(this.selectionStart, this.selectionEnd);
  }
  
  private String getSelectedText() {
    if (!hasSelection()) return ""; 
    int start = getSelectionStartPos();
    int end = getSelectionEndPos();
    return this.text.substring(start, end);
  }
  
  private void deleteSelection() {
    if (!hasSelection())
      return;  int start = getSelectionStartPos();
    int end = getSelectionEndPos();
    this.text = this.text.substring(0, start) + this.text.substring(0, start);
    this.cursorPosition = start;
    this.selectionStart = -1;
    this.selectionEnd = -1;
  }
  
  private void insertText(String insertText) {
    if (hasSelection()) {
      deleteSelection();
    }
    this.text = this.text.substring(0, this.cursorPosition) + this.text.substring(0, this.cursorPosition) + insertText;
    this.cursorPosition += insertText.length();
  }
  
  private void moveCursor(int direction, boolean extendSelection) {
    if (extendSelection) {
      if (this.selectionStart == -1) {
        this.selectionStart = this.cursorPosition;
      }
      this.selectionEnd = this.cursorPosition;
    } else {
      this.selectionStart = -1;
      this.selectionEnd = -1;
    } 
    this.cursorPosition = Math.max(0, Math.min(this.text.length(), this.cursorPosition + direction));
    if (extendSelection) {
      this.selectionEnd = this.cursorPosition;
    }
  }
  
  public boolean handleKeyPress(int keyCode, int scanCode, int modifiers) {
    if (!this.isActive) {
      return false;
    }
    
    boolean ctrlPressed = ((modifiers & 0x2) != 0);
    boolean shiftPressed = ((modifiers & 0x1) != 0);

    
    if (ctrlPressed && keyCode == 65) {
      this.selectionStart = 0;
      this.selectionEnd = this.text.length();
      this.cursorPosition = this.text.length();
      return true;
    } 

    
    if (ctrlPressed && keyCode == 67) {
      if (hasSelection()) {
        String selected = getSelectedText();
        this.client.field_1774.method_1455(selected);
      } 
      return true;
    } 

    
    if (ctrlPressed && keyCode == 88) {
      if (hasSelection()) {
        String selected = getSelectedText();
        this.client.field_1774.method_1455(selected);
        deleteSelection();
      } 
      return true;
    } 

    
    if (class_437.method_25437(keyCode)) {
      String clipboardContent = this.client.field_1774.method_1460();
      if (clipboardContent != null) {
        insertText(clipboardContent);
      }
      return true;
    } 
    
    switch (keyCode) {
      case 256:
        cancelEditing();
        return true;
      case 257:
        stopEditing();
        return true;
      case 259:
        if (hasSelection()) {
          deleteSelection();
        } else if (this.cursorPosition > 0) {
          this.text = this.text.substring(0, this.cursorPosition - 1) + this.text.substring(0, this.cursorPosition - 1);
          this.cursorPosition--;
        } 
        return true;
      case 261:
        if (hasSelection()) {
          deleteSelection();
        } else if (this.cursorPosition < this.text.length()) {
          this.text = this.text.substring(0, this.cursorPosition) + this.text.substring(0, this.cursorPosition);
        } 
        return true;
      case 263:
        moveCursor(-1, shiftPressed);
        return true;
      case 262:
        moveCursor(1, shiftPressed);
        return true;
      case 268:
        if (shiftPressed) {
          if (this.selectionStart == -1) {
            this.selectionStart = this.cursorPosition;
          }
          this.selectionEnd = 0;
        } else {
          this.selectionStart = -1;
          this.selectionEnd = -1;
        } 
        this.cursorPosition = 0;
        return true;
      case 269:
        if (shiftPressed) {
          if (this.selectionStart == -1) {
            this.selectionStart = this.cursorPosition;
          }
          this.selectionEnd = this.text.length();
        } else {
          this.selectionStart = -1;
          this.selectionEnd = -1;
        } 
        this.cursorPosition = this.text.length();
        return true;
    } 
    
    return false;
  }
  
  public boolean handleCharType(char chr, int modifiers) {
    if (!this.isActive) {
      return false;
    }

    
    if (chr >= ' ' && chr != '') {
      insertText(String.valueOf(chr));
      return true;
    } 
    
    return false;
  }
  
  public String getText() {
    return this.text;
  }
  
  public void setText(String newText) {
    this.text = (newText != null) ? newText : "";
    this.cursorPosition = Math.min(this.cursorPosition, this.text.length());
  }
  
  public boolean isActive() {
    return this.isActive;
  }
  
  public int getCursorPosition() {
    return this.cursorPosition;
  }
  
  public int getSelectionStart() {
    return this.selectionStart;
  }
  
  public int getSelectionEnd() {
    return this.selectionEnd;
  }
  
  public boolean hasSelectionPublic() {
    return hasSelection();
  }
}


