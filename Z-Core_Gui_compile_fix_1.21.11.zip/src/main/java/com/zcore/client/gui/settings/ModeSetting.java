package com.zcore.client.gui.settings;

public class ModeSetting<T extends Enum<T>>
  extends Setting<T> {
  private final Class<T> enumClass;
  private String description;
  
  public ModeSetting(String name, T defaultValue, Class<T> enumClass) {
    super(name, defaultValue);
    this.enumClass = enumClass;
  }
  
  public String getDescription() {
    return this.description;
  }
  
  public ModeSetting<T> setDescription(String description) {
    this.description = description;
    return this;
  }
  
  public boolean isMode(T mode) {
    return (getValue() == mode);
  }
  
  public T[] getModes() {
    return this.enumClass.getEnumConstants();
  }
  
  public void cycleMode() {
    T[] modes = getModes();
    Enum enum_ = (Enum)getValue();
    int currentIndex = -1;
    
    for (int i = 0; i < modes.length; i++) {
      if (modes[i] == enum_) {
        currentIndex = i;
        
        break;
      } 
    } 
    if (currentIndex != -1) {
      int nextIndex = (currentIndex + 1) % modes.length;
      setValue(modes[nextIndex]);
    } 
  }
  
  public void setValue(String modeName) {
    if (modeName == null) {
      return;
    }
    try {
      T mode = Enum.valueOf(this.enumClass, modeName.toUpperCase());
      setValue(mode);
      return;
    } catch (Exception exception) {


      
      for (Enum enum_ : (Enum[])this.enumClass.getEnumConstants()) {
        if (enum_.toString().equalsIgnoreCase(modeName)) {
          setValue((T)enum_);
          return;
        } 
      } 
      return;
    } 
  }
  
  public String toString() {
    return ((Enum)getValue()).name();
  }
}


