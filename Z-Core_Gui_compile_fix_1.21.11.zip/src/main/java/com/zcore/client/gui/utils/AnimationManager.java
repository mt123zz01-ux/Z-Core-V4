package com.zcore.client.gui.utils;

import java.util.HashMap;
import java.util.Map;

public class AnimationManager
{
  private final Map<String, Animation> animations = new HashMap<>();
  private final long startTime;
  private boolean isGlobalAnimating = false;
  
  public AnimationManager() {
    this.startTime = System.currentTimeMillis();
    this.isGlobalAnimating = true;
  }
  
  public void update() {
    long currentTime = System.currentTimeMillis();
    
    if (this.isGlobalAnimating) {
      long elapsed = currentTime - this.startTime;
      if (elapsed >= 350L) {
        this.isGlobalAnimating = false;
      }
    } 
    
    this.animations.entrySet().removeIf(entry -> {
          Animation anim = (Animation)entry.getValue();
          anim.update(currentTime);
          return anim.isFinished();
        });
  }
  
  public float getProgress() {
    if (!this.isGlobalAnimating) return 1.0F;
    
    long elapsed = System.currentTimeMillis() - this.startTime;
    float progress = Math.min(1.0F, (float)elapsed / 350.0F);
    return easeOutCubic(progress);
  }
  
  public void startAnimation(String key, float from, float to, long duration) {
    this.animations.put(key, new Animation(from, to, duration, System.currentTimeMillis()));
  }
  
  public float getAnimationValue(String key, float defaultValue) {
    Animation anim = this.animations.get(key);
    return (anim != null) ? anim.getValue() : defaultValue;
  }
  
  public boolean isAnimating(String key) {
    Animation anim = this.animations.get(key);
    return (anim != null && !anim.isFinished());
  }
  
  private float easeOutCubic(float t) {
    return 1.0F - (float)Math.pow((1.0F - t), 3.0D);
  }
  
  private float easeInOutCubic(float t) {
    return (t < 0.5F) ? (4.0F * t * t * t) : (float)(1.0D - Math.pow((-2.0F * t + 2.0F), 3.0D) / 2.0D);
  }
  
  private static class Animation {
    private final float from;
    private final float to;
    private final long duration;
    private final long startTime;
    private boolean finished = false;
    
    public Animation(float from, float to, long duration, long startTime) {
      this.from = from;
      this.to = to;
      this.duration = duration;
      this.startTime = startTime;
    }
    
    public void update(long currentTime) {
      long elapsed = currentTime - this.startTime;
      if (elapsed >= this.duration) {
        this.finished = true;
      }
    }
    
    public float getValue() {
      if (this.finished) return this.to;
      
      long elapsed = System.currentTimeMillis() - this.startTime;
      float progress = Math.min(1.0F, (float)elapsed / (float)this.duration);
      progress = easeOutCubic(progress);
      
      return this.from + (this.to - this.from) * progress;
    }
    
    public boolean isFinished() {
      return this.finished;
    }
    
    private float easeOutCubic(float t) {
      return 1.0F - (float)Math.pow((1.0F - t), 3.0D);
    }
  }
}


