package com.zcore.client.gui.settings;

public class DoubleSetting extends Setting<Double> {
    private final double min, max, increment;
    public DoubleSetting(String name, Double defaultValue) { this(name, defaultValue, 0.0, 100.0, 1.0); }
    public DoubleSetting(String name, double defaultValue, double min, double max, double increment) {
        super(name, defaultValue);
        this.min = min; this.max = max; this.increment = increment;
    }
    public double getMin() { return min; }
    public double getMax() { return max; }
    public double getIncrement() { return increment; }
}
