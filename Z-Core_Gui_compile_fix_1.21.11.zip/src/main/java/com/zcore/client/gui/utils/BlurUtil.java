package com.zcore.client.gui.utils;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.class_276;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_310;
import net.minecraft.class_5944;

public class BlurUtil {
  private static final class_310 client = class_310.method_1551();
  private static class_5944 blurShader = null;

  
  public static void applyBlur(int intensity) {
    if (client.field_1687 == null || client.field_1724 == null)
      return; 
    class_276 framebuffer = client.method_1522();
    if (framebuffer == null) {
      return;
    }
















    
    int actualIntensity = Math.min(intensity, 3);

    
    class_276 mainFramebuffer = client.method_1522();
    
    try {
      RenderSystem.enableBlend();
      RenderSystem.setShader(blurShader);

      
      if (blurShader.method_34582("Radius") != null) {
        blurShader.method_34582("Radius").method_1251(actualIntensity);
      }
      if (blurShader.method_34582("TexelSize") != null) {
        blurShader.method_34582("TexelSize").method_1255(1.0F / client
            .method_22683().method_4489(), 1.0F / client
            .method_22683().method_4506());
      }


      
      class_289 tessellator = class_289.method_1348();
      class_287 bufferBuilder = tessellator.method_60827(class_293.class_5596.field_27382, class_290.field_1585);
      
      float width = client.method_22683().method_4489();
      float height = client.method_22683().method_4506();
      
      bufferBuilder.method_22912(0.0F, height, 0.0F).method_22913(0.0F, 0.0F);
      bufferBuilder.method_22912(width, height, 0.0F).method_22913(1.0F, 0.0F);
      bufferBuilder.method_22912(width, 0.0F, 0.0F).method_22913(1.0F, 1.0F);
      bufferBuilder.method_22912(0.0F, 0.0F, 0.0F).method_22913(0.0F, 1.0F);

      
      class_286.method_43433(bufferBuilder.method_60800());
      RenderSystem.disableBlend();
    } catch (Exception exception) {}
  }



  
  public static void cleanup() {
    if (blurShader != null) {
      blurShader.close();
      blurShader = null;
    } 
  }
}


