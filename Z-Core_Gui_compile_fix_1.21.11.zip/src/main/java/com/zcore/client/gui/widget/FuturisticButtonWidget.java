package com.zcore.client.gui.widget;

import com.zcore.client.gui.ZCoreGuiTheme;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4185;

public class FuturisticButtonWidget
  extends class_4185
{
  public FuturisticButtonWidget(int x, int y, int width, int height, class_2561 message, class_4185.class_4241 onPress) {
    super(x, y, width, height, message, onPress, field_40754);
  }

  
  public void method_48579(class_332 context, int mouseX, int mouseY, float delta) {
    class_310 client = class_310.method_1551();
    int mainColor = method_49606() ? ZCoreGuiTheme.getAccentColorDark() : -15658733;
    int borderColor = ZCoreGuiTheme.getAccentColor();
    int textColor = -2039584;

    
    context.method_25294(method_46426(), method_46427(), method_46426() + this.field_22758, method_46427() + this.field_22759, mainColor);

    
    context.method_25294(method_46426(), method_46427(), method_46426() + this.field_22758, method_46427() + 1, borderColor);
    context.method_25294(method_46426(), method_46427() + this.field_22759 - 1, method_46426() + this.field_22758, method_46427() + this.field_22759, borderColor);

    
    context.method_27534(client.field_1772, 
        
        method_25369(), 
        method_46426() + this.field_22758 / 2, 
        method_46427() + (this.field_22759 - 8) / 2, textColor);
  }
}


