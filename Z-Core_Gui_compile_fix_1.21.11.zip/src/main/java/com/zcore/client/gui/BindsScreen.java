package com.zcore.client.gui;

import com.zcore.client.client.KeybindManager;
import com.zcore.client.client.ZCoreClient;
import com.zcore.client.gui.utils.BlurUtil;
import com.zcore.client.modules.Module;
import java.util.List;
import java.util.stream.Collectors;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;



public class BindsScreen
  extends class_437
{
  private int selectedKey = -1;
  
  public BindsScreen() {
    super((class_2561)class_2561.method_43470("Keybinds"));
  }


  
  public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
    BlurUtil.applyBlur(2);
    
    method_25420(context, mouseX, mouseY, delta);
    drawKeyboard(context, mouseX, mouseY);
    
    if (this.selectedKey != -1) {
      drawUnboundModules(context, mouseX, mouseY);
    }
    
    super.method_25394(context, mouseX, mouseY, delta);
  }
  
  private void drawKeyboard(class_332 context, int mouseX, int mouseY) {
    int keyWidth = 24;
    int keyHeight = 24;
    int keySpacing = 8;
    int startY = this.field_22790 / 2 - 140;
    
    int[] rowLengths = { 14, 14, 13, 12, 7 };
    int[][] keyCodes = { { 96, 49, 50, 51, 52, 53, 54, 55, 56, 57, 48, 45, 61, 259 }, { 258, 81, 87, 69, 82, 84, 89, 85, 73, 79, 80, 91, 93, 92 }, { 280, 65, 83, 68, 70, 71, 72, 74, 75, 76, 59, 39, 257 }, { 340, 90, 88, 67, 86, 66, 78, 77, 44, 46, 47, 344 }, { 341, 343, 342, 32, 346, 347, 345 } };






    
    int keyboardWidth = rowLengths[0] * (keyWidth + keySpacing) + 10;
    int keyboardHeight = rowLengths.length * (keyHeight + keySpacing) + 10;
    int keyboardX = (this.field_22789 - keyboardWidth) / 2;
    int keyboardY = startY - 5;
    
    context.method_25294(keyboardX, keyboardY, keyboardX + keyboardWidth, keyboardY + keyboardHeight, -2147483648);
    context.method_49601(keyboardX, keyboardY, keyboardWidth, keyboardHeight, -1);

    
    for (int row = 0; row < rowLengths.length; row++) {
      int rowWidth = rowLengths[row] * (keyWidth + keySpacing) - keySpacing;
      int rowStartX = (this.field_22789 - rowWidth) / 2;
      for (int col = 0; col < rowLengths[row]; col++) {
        int keyCode = keyCodes[row][col];
        String keyName = KeybindManager.getKeyName(keyCode);
        int x = rowStartX + col * (keyWidth + keySpacing);
        int y = startY + row * (keyHeight + keySpacing);
        
        boolean hovered = (mouseX >= x && mouseX <= x + keyWidth && mouseY >= y && mouseY <= y + keyHeight);
        int color = hovered ? -8355712 : -12566464;
        if (this.selectedKey == keyCode) {
          color = -1;
        }
        
        context.method_25294(x, y, x + keyWidth, y + keyHeight, color);
        context.method_25300(this.field_22793, keyName, x + keyWidth / 2, y + (keyHeight - 8) / 2, -1);
      } 
    } 
  }


  
  private void drawUnboundModules(class_332 context, int mouseX, int mouseY) {
    List<Module> unboundModules = (List<Module>)ZCoreClient.moduleManager.getModules().stream().filter(module -> (module.getKeyBind() == -1)).collect(Collectors.toList());
    
    if (unboundModules.isEmpty()) {
      return;
    }
    
    int listWidth = 120;
    int listHeight = unboundModules.size() * 14 + 6;
    int listX = (this.field_22789 - listWidth) / 2;
    int listY = this.field_22790 / 2 + 60;
    
    context.method_25294(listX, listY, listX + listWidth, listY + listHeight, -1073741824);
    
    int moduleY = listY + 4;
    for (Module module : unboundModules) {
      boolean hovered = (mouseX >= listX && mouseX <= listX + listWidth && mouseY >= moduleY && mouseY <= moduleY + 12);
      int color = hovered ? -1 : -6250336;
      context.method_25303(this.field_22793, module.getName(), listX + 4, moduleY, color);
      moduleY += 14;
    } 
  }

  
  public boolean method_25402(double mouseX, double mouseY, int button) {
    int keyWidth = 24;
    int keyHeight = 24;
    int keySpacing = 8;
    int startY = this.field_22790 / 2 - 120;
    
    int[] rowLengths = { 14, 14, 13, 12, 7 };
    int[][] keyCodes = { { 96, 49, 50, 51, 52, 53, 54, 55, 56, 57, 48, 45, 61, 259 }, { 258, 81, 87, 69, 82, 84, 89, 85, 73, 79, 80, 91, 93, 92 }, { 280, 65, 83, 68, 70, 71, 72, 74, 75, 76, 59, 39, 257 }, { 340, 90, 88, 67, 86, 66, 78, 77, 44, 46, 47, 344 }, { 341, 343, 342, 32, 346, 347, 345 } };






    
    for (int row = 0; row < rowLengths.length; row++) {
      int rowWidth = rowLengths[row] * (keyWidth + keySpacing) - keySpacing;
      int rowStartX = (this.field_22789 - rowWidth) / 2;
      for (int col = 0; col < rowLengths[row]; col++) {
        int x = rowStartX + col * (keyWidth + keySpacing);
        int y = startY + row * (keyHeight + keySpacing);
        
        if (mouseX >= x && mouseX <= (x + keyWidth) && mouseY >= y && mouseY <= (y + keyHeight)) {
          this.selectedKey = keyCodes[row][col];
          return true;
        } 
      } 
    } 
    
    if (this.selectedKey != -1) {

      
      List<Module> unboundModules = (List<Module>)ZCoreClient.moduleManager.getModules().stream().filter(module -> (module.getKeyBind() == -1)).collect(Collectors.toList());
      
      if (unboundModules.isEmpty()) {
        this.selectedKey = -1;
        return false;
      } 
      
      int listWidth = 120;
      int listX = (this.field_22789 - listWidth) / 2;
      int listY = this.field_22790 / 2 + 60;
      int moduleY = listY + 4;
      
      for (Module module : unboundModules) {
        if (mouseX >= listX && mouseX <= (listX + listWidth) && mouseY >= moduleY && mouseY <= (moduleY + 12)) {
          module.setKeyBind(this.selectedKey);
          this.selectedKey = -1;
          return true;
        } 
        moduleY += 14;
      } 
    } 
    
    return super.method_25402(mouseX, mouseY, button);
  }

  
  public boolean method_25421() {
    return false;
  }
}


