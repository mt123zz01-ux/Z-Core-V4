package com.zcore.client.gui.utils;

import com.zcore.client.gui.ZCoreGuiTheme;
import com.zcore.client.modules.Module;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;

public class TooltipRenderer
{
  private final int tooltipDelay = 500;
  private final class_310 client = class_310.method_1551();
  private final class_327 textRenderer = this.client.field_1772;
  private Module hoveredModule = null;
  private long hoverStartTime = 0L;
  private boolean showingTooltip = false;
  private int tooltipX = 0;
  private int tooltipY = 0;
  
  public void update(int mouseX, int mouseY) {
    long currentTime = System.currentTimeMillis();
    
    if (this.hoveredModule != null && !this.showingTooltip && 
      currentTime - this.hoverStartTime > 500L) {
      this.showingTooltip = true;
      this.tooltipX = mouseX;
      this.tooltipY = mouseY;
    } 

    
    if (this.hoveredModule == null) {
      this.showingTooltip = false;
    }
  }
  
  public void setHoveredModule(Module module, int mouseX, int mouseY) {
    if (this.hoveredModule != module) {
      this.hoveredModule = module;
      this.hoverStartTime = System.currentTimeMillis();
      this.showingTooltip = false;
      this.tooltipX = mouseX;
      this.tooltipY = mouseY;
    } 
  }
  
  public void clearHover() {
    this.hoveredModule = null;
    this.showingTooltip = false;
  }
  
  public void render(class_332 context, float animationProgress) {
    if (!this.showingTooltip || this.hoveredModule == null)
      return; 
    String description = this.hoveredModule.getDescription();
    if (description == null || description.trim().isEmpty()) {
      description = "No description available";
    }
    
    String moduleName = this.hoveredModule.getName();
    int moduleNameWidth = this.textRenderer.method_1727(moduleName);
    
    List<String> lines = wrapText(description, 250);
    Objects.requireNonNull(this.textRenderer); int maxLineWidth = lines.stream().mapToInt(this.textRenderer::method_1727).max().orElse(0);
    
    int contentWidth = Math.max(moduleNameWidth, maxLineWidth);
    int tooltipWidth = Math.max(120, contentWidth + 16);
    
    if (tooltipWidth < 250) {
      lines = wrapText(description, tooltipWidth - 16);
      Objects.requireNonNull(this.textRenderer); maxLineWidth = lines.stream().mapToInt(this.textRenderer::method_1727).max().orElse(0);
      tooltipWidth = Math.max(120, Math.max(moduleNameWidth, maxLineWidth) + 16);
    } 
    
    int tooltipHeight = 18 + lines.size() * 10 + 8;
    
    int finalTooltipX = this.tooltipX + 10;
    int finalTooltipY = this.tooltipY - tooltipHeight - 5;
    
    int screenWidth = this.client.method_22683().method_4480();
    int screenHeight = this.client.method_22683().method_4507();
    
    if (finalTooltipX + tooltipWidth > screenWidth) {
      finalTooltipX = this.tooltipX - tooltipWidth - 10;
    }
    if (finalTooltipY < 0) {
      finalTooltipY = this.tooltipY + 20;
    }
    if (finalTooltipX < 0) {
      finalTooltipX = 5;
    }
    
    long elapsed = System.currentTimeMillis() - this.hoverStartTime + 500L;
    float tooltipAlpha = Math.min(1.0F, (float)elapsed / 150.0F);
    
    if (tooltipAlpha <= 0.0F)
      return; 
    renderTooltip(context, finalTooltipX, finalTooltipY, tooltipWidth, tooltipHeight, moduleName, lines, tooltipAlpha, animationProgress);
  }



  
  private void renderTooltip(class_332 context, int x, int y, int width, int height, String moduleName, List<String> descriptionLines, float tooltipAlpha, float animationProgress) {
    int cornerRadius = 12;
    
    int bgColor = ZCoreGuiTheme.applyAlpha(ZCoreGuiTheme.getSettingsPanelColor(), tooltipAlpha * 0.95F);
    GuiUtils.drawRoundedRect(context, x, y, width, height, cornerRadius, bgColor);
    
    int borderColor = ZCoreGuiTheme.applyAlpha(ZCoreGuiTheme.getBorderColor(), tooltipAlpha * 0.8F);
    drawRoundedRectOutline(context, x, y, width, height, cornerRadius, borderColor);
    
    int headerColor = ZCoreGuiTheme.applyAlpha(ZCoreGuiTheme.getAccentColor(), (int)(tooltipAlpha * 255.0F)) | 0xFF000000;
    context.method_51433(this.textRenderer, moduleName, x + 8, y + 4, headerColor, false);
    
    int separatorY = y + 16;
    int separatorColor = ZCoreGuiTheme.applyAlpha(ZCoreGuiTheme.getSeparatorColor(), tooltipAlpha);
    context.method_25294(x + 8, separatorY, x + width - 8, separatorY + 1, separatorColor);
    
    int textColor = ZCoreGuiTheme.applyAlpha(-3355444, (int)(tooltipAlpha * 255.0F)) | 0xFF000000;
    int textY = separatorY + 4;
    for (String line : descriptionLines) {
      context.method_51433(this.textRenderer, line, x + 8, textY, textColor, false);
      textY += 10;
    } 
  }

  
  private void drawRoundedRectOutline(class_332 context, int x, int y, int width, int height, int radius, int color) {
    if (radius <= 0) {
      context.method_25294(x, y, x + width, y + 1, color);
      context.method_25294(x, y + height - 1, x + width, y + height, color);
      context.method_25294(x, y, x + 1, y + height, color);
      context.method_25294(x + width - 1, y, x + width, y + height, color);
      
      return;
    } 
    radius = Math.min(radius, Math.min(width, height) / 2);
    
    context.method_25294(x + radius, y, x + width - radius, y + 1, color);
    context.method_25294(x + radius, y + height - 1, x + width - radius, y + height, color);
    context.method_25294(x, y + radius, x + 1, y + height - radius, color);
    context.method_25294(x + width - 1, y + radius, x + width, y + height - radius, color);
    
    drawCornerOutline(context, x, y, radius, color, true, true);
    drawCornerOutline(context, x + width - radius, y, radius, color, false, true);
    drawCornerOutline(context, x, y + height - radius, radius, color, true, false);
    drawCornerOutline(context, x + width - radius, y + height - radius, radius, color, false, false);
  }

  
  private void drawCornerOutline(class_332 context, int x, int y, int radius, int color, boolean left, boolean top) {
    for (int i = 0; i < radius; i++) {
      for (int j = 0; j < radius; j++) {
        double distance = Math.sqrt(((radius - i) - 0.5D) * ((radius - i) - 0.5D) + ((radius - j) - 0.5D) * ((radius - j) - 0.5D));
        
        if (distance >= (radius - 1) && distance <= radius) {
          int pixelX = left ? (x + i) : (x + radius - i - 1);
          int pixelY = top ? (y + j) : (y + radius - j - 1);
          context.method_25294(pixelX, pixelY, pixelX + 1, pixelY + 1, color);
        } 
      } 
    } 
  }
  
  private List<String> wrapText(String text, int maxWidth) {
    if (text == null || text.trim().isEmpty()) {
      List<String> result = new ArrayList<>();
      result.add("No description available");
      return result;
    } 
    
    int availableWidth = maxWidth - 16;
    if (availableWidth <= 0) availableWidth = 100;
    
    String[] words = text.split(" ");
    List<String> lines = new ArrayList<>();
    StringBuilder currentLine = new StringBuilder();
    
    for (String word : words) {
      String testLine = (currentLine.length() == 0) ? word : (String.valueOf(currentLine) + " " + String.valueOf(currentLine));
      int testWidth = this.textRenderer.method_1727(testLine);
      
      if (testWidth <= availableWidth || currentLine.length() == 0) {
        if (currentLine.length() > 0) {
          currentLine.append(" ");
        }
        currentLine.append(word);
      } else {
        lines.add(currentLine.toString());
        currentLine = new StringBuilder(word);
        
        if (this.textRenderer.method_1727(word) > availableWidth) {
          String truncated = this.textRenderer.method_27523(word, availableWidth - this.textRenderer.method_1727("...")) + "...";
          currentLine = new StringBuilder(truncated);
        } 
      } 
    } 
    
    if (currentLine.length() > 0) {
      lines.add(currentLine.toString());
    }
    
    return lines.isEmpty() ? List.<String>of("No description available") : lines;
  }
  
  public boolean isShowingTooltip() {
    return this.showingTooltip;
  }
}


