package com.zcore.client.gui;
import com.zcore.client.client.ZCoreClient;
import com.zcore.client.gui.settings.BlockSetting;
import com.zcore.client.gui.settings.BooleanSetting;
import com.zcore.client.gui.settings.ColorSetting;
import com.zcore.client.gui.settings.DoubleSetting;
import com.zcore.client.gui.settings.EnchantmentSetting;
import com.zcore.client.gui.settings.ItemSetting;
import com.zcore.client.gui.settings.KeybindSetting;
import com.zcore.client.gui.settings.ModeSetting;
import com.zcore.client.gui.settings.NumberSetting;
import com.zcore.client.gui.settings.ProfileSetting;
import com.zcore.client.gui.settings.Setting;
import com.zcore.client.gui.settings.SliderSetting;
import com.zcore.client.gui.settings.StringListSetting;
import com.zcore.client.gui.settings.StringSetting;
import com.zcore.client.gui.utils.TextEditor;
import com.zcore.client.modules.Module;
import com.zcore.client.modules.client.ClickGUI;
import com.zcore.client.utils.render.RenderUtils;
import java.awt.Color;
import java.util.List;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;

public class ClickGuiScreen extends class_437 {
  private static final Map<Module.Category, class_2960> CATEGORY_ICONS = new HashMap<>();
  private final class_310 client = class_310.method_1551();
  private final int categoryWidth = 115;
  private final int moduleHeight = 15;
  private final int headerHeight = 15;
  private Module.Category currentCategory = Module.Category.COMBAT;
  private final int dashboardWidth = 450;
  private final int dashboardHeight = 300;
  private final int sidebarWidth = 100;
  private final int panelWidth = 180;
  private final int panelHeaderHeight = 18;
  private final int settingHeight = 20;
  private final TextEditor itemSearchEditor = new TextEditor();
  private final TextEditor moduleSearchEditor = new TextEditor();
  private final int itemPanelWidth = 150;
  private final int itemPanelHeight = 180;
  private final TextEditor stringEditor = new TextEditor();
  private long animationStartTime;
  private final int maxPanelHeight = 200;
  private final EnchantmentSelectionPanel enchantmentPanel = new EnchantmentSelectionPanel();
  private final BlockSelectionPanel blockSelectionPanel = new BlockSelectionPanel();
  private final ColorPickerPanel colorPickerPanel = new ColorPickerPanel();
  private final StringListPanel stringListPanel = new StringListPanel(); int yOffset;
  private boolean draggingCategory = false;
  private Module.Category dragCategory;
  private int dragOffsetX;
  private int dragOffsetY;
  private Module selectedModule = null;
  private boolean draggingPanel = false;
  private int panelDragOffsetX = 0;
  private int panelDragOffsetY = 0;
  private int panelX = 700;
  private int panelY = 200;
  private float panelTargetX = 700.0F;
  private float panelTargetY = 200.0F;
  private long panelDragStartTime = 0L;
  private boolean panelIsDragging = false;
  private ItemSetting editingItem = null;
  private int itemScrollOffset = 0;
  private int searchScrollOffset = 0;
  private int itemPanelX = 100;
  private int itemPanelY = 100;
  private float itemPanelTargetX = 100.0F;
  private float itemPanelTargetY = 100.0F;
  private long itemPanelDragStartTime = 0L;
  private boolean itemPanelIsDragging = false;
  private boolean draggingItemPanel = false;
  private int itemPanelDragOffsetX = 0;
  private int itemPanelDragOffsetY = 0;
  private boolean draggingSlider = false;
  private SliderSetting draggedSlider = null;
  private boolean draggingNumber = false;
  private NumberSetting draggedNumber = null;
  private boolean draggingDouble = false;
  private DoubleSetting draggedDouble = null;
  private boolean listeningForKeybind = false;
  private Module keybindModule = null;
  private StringSetting editingString = null;
  private boolean isAnimating;
  private float settingsScrollOffset = 0.0F;
  private float maxScroll = 0.0F;
  private float moduleScrollOffset = 0.0F;
  private float maxModuleScroll = 0.0F;
  private boolean draggingScrollBar = false;
  private boolean renderingDropdown = false;
  private float pulseAnimation = 0.0F;
  private float hoverAnimation = 0.0F;
  private int hoveredModuleIndex = -1;
  private Module.Category hoveredCategory = null;
  private Module hoveredModule = null;
  private int cachedCornerRadius = -1;
  private int cachedAccentColor = -1;
  private int cachedHoverColor = -1;
  private int cachedTextColor = -1;
  private float cachedPanelAlpha = -1.0F;
  private KeybindSetting listeningKeybindSetting = null;
  private BlockSetting editingBlock = null;
  
  public ClickGuiScreen() {
    super((class_2561)class_2561.method_43470("Z-Core ClickGUI"));
    this.animationStartTime = System.currentTimeMillis();
    this.isAnimating = true;
    
    ZCoreClient.sendKeepAliveIfAllowed();
    
    if (CATEGORY_ICONS.isEmpty()) {
      CATEGORY_ICONS.put(Module.Category.CLIENT, class_2960.method_60655("zcore", "textures/client.png"));
      CATEGORY_ICONS.put(Module.Category.COMBAT, class_2960.method_60655("zcore", "textures/combat.png"));
      CATEGORY_ICONS.put(Module.Category.MISC, class_2960.method_60655("zcore", "textures/misc.png"));
      CATEGORY_ICONS.put(Module.Category.VISUAL, class_2960.method_60655("zcore", "textures/render.png"));
      CATEGORY_ICONS.put(Module.Category.DONUT, class_2960.method_60655("zcore", "textures/donut.png"));
    } 
  }
  
  private double scaleInput(double value) {
    return value * this.client.method_22683().method_4495() / 2.0D;
  }

  
  protected void method_25426() {
    this.field_22789 = this.client.method_22683().method_4489() / 2;
    this.field_22790 = this.client.method_22683().method_4506() / 2;
    super.method_25426();
    constrainPanelPositions();
    resetAnimation();
  }
  
  public void resetAnimation() {
    this.animationStartTime = System.currentTimeMillis();
    this.isAnimating = true;
  }

  
  public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
    ClickGUI clickGUI = (ClickGUI)ZCoreClient.getModuleManager().getModule(ClickGUI.class);
    if (clickGUI != null && ((Boolean)clickGUI.blur.getValue()).booleanValue()) {
      BlurManager.render(1.0F);
    }
    
    mouseX = (int)scaleInput(mouseX);
    mouseY = (int)scaleInput(mouseY);
    this.hoveredModule = null;
    this.hoveredCategory = null;
    RenderUtils.customScaledProjection(2.0D);
    
    int screenWidth = this.client.method_22683().method_4489() / 2;
    int screenHeight = this.client.method_22683().method_4506() / 2;
    
    this.pulseAnimation += delta * 0.08F;
    if (this.pulseAnimation > 1.0F) this.pulseAnimation = 0.0F;
    
    float animationProgress = 1.0F;
    if (this.isAnimating) {
      long elapsed = System.currentTimeMillis() - this.animationStartTime;
      animationProgress = easeOutCubic(Math.min(1.0F, (float)elapsed / 300.0F));
      if (animationProgress >= 1.0F) this.isAnimating = false;
    
    } 
    method_25420(context, mouseX, mouseY, delta);
    context.method_25294(0, 0, screenWidth, screenHeight, ZCoreGuiTheme.applyAlpha(0, 0.4F * animationProgress));
    
    int dashX = (screenWidth - 450) / 2;
    int dashY = (screenHeight - 300) / 2;
    
    context.method_51448().method_22903();
    if (animationProgress < 1.0F) {
      float scale = 0.9F + 0.1F * animationProgress;
      context.method_51448().method_46416(screenWidth / 2.0F, screenHeight / 2.0F, 0.0F);
      context.method_51448().method_22905(scale, scale, 1.0F);
      context.method_51448().method_46416(-screenWidth / 2.0F, -screenHeight / 2.0F, 0.0F);
    } 
    
    cacheThemeValues();
    renderDashboard(context, dashX, dashY, mouseX, mouseY, animationProgress);
    
    if (this.selectedModule != null) {
      renderSettingsPanel(context, mouseX, mouseY, animationProgress);
    }
    
    renderTooltips(context, mouseX, mouseY, animationProgress);
    
    if (this.editingItem != null) {
      renderItemSelection(context, mouseX, mouseY, animationProgress);
    }
    
    if (this.colorPickerPanel.isOpen()) {
      this.colorPickerPanel.render(context, mouseX, mouseY, animationProgress);
    }
    
    if (this.stringListPanel.isOpen()) {
      this.stringListPanel.render(context, mouseX, mouseY, animationProgress);
    }
    
    if (this.enchantmentPanel.isOpen()) {
      this.enchantmentPanel.render(context, mouseX, mouseY, animationProgress);
    }
    
    if (this.blockSelectionPanel.isOpen()) {
      this.blockSelectionPanel.render(context, mouseX, mouseY, animationProgress);
    }
    
    context.method_51448().method_22909();
    RenderUtils.customScaledProjection(2.0D);
  }
  
  private void renderDashboard(class_332 context, int x, int y, int mouseX, int mouseY, float animationProgress) {
    int cornerRadius = 10;
    int bgColor = ZCoreGuiTheme.applyAlpha(657930, 0.85F * animationProgress);
    int borderColor = ZCoreGuiTheme.applyAlpha(this.cachedAccentColor, 0.3F * animationProgress);
    
    ClickGUI clickGUI = (ClickGUI)ZCoreClient.getModuleManager().getModule(ClickGUI.class);
    boolean showGlow = (clickGUI != null && ((Boolean)clickGUI.glow.getValue()).booleanValue());
    boolean showIcons = (clickGUI != null && ((Boolean)clickGUI.icons.getValue()).booleanValue());

    
    if (showGlow) {
      int glowColor = ZCoreGuiTheme.applyAlpha(this.cachedAccentColor, 0.15F * animationProgress);
      RenderUtils.fillRoundRect(context, x - 2, y - 2, 454, 304, cornerRadius + 2, glowColor);
    } 

    
    RenderUtils.fillRoundRect(context, x, y, 450, 300, cornerRadius, bgColor);
    RenderUtils.drawRoundRect(context, x, y, 450, 300, cornerRadius, borderColor);

    
    int sidebarColor = ZCoreGuiTheme.applyAlpha(0, 0.2F * animationProgress);
    RenderUtils.fillRoundRect(context, x, y, 100, 300, cornerRadius, 0, 0, cornerRadius, sidebarColor);
    RenderUtils.drawRoundRect(context, x, y, 100, 300, cornerRadius, borderColor);

    
    context.method_51433(this.field_22793, "Z-CORE", x + 15, y + 15, ZCoreGuiTheme.applyAlpha(this.cachedAccentColor, animationProgress), true);

    
    int catY = y + 45;
    for (Module.Category cat : Module.Category.values()) {
      if (cat != Module.Category.SEARCH) {
        
        boolean isSelected = (this.currentCategory == cat);
        boolean hovered = isHovered(mouseX, mouseY, x + 5, catY, 90, 22);
        
        if (isSelected) {
          int selectColor = ZCoreGuiTheme.applyAlpha(this.cachedAccentColor, 0.2F * animationProgress);
          RenderUtils.fillRoundRect(context, x + 5, catY, 90, 22, 6, selectColor);
          RenderUtils.fillRoundVertLine(context, x + 3, catY + 4, 14, 2, ZCoreGuiTheme.applyAlpha(this.cachedAccentColor, animationProgress));
        } else if (hovered) {
          int hoverColor = ZCoreGuiTheme.applyAlpha(16777215, 0.05F * animationProgress);
          RenderUtils.fillRoundRect(context, x + 5, catY, 90, 22, 6, hoverColor);
        } 
        
        int iconX = x + 12;
        int textX = iconX + (showIcons ? 18 : 3);
        
        if (showIcons) {
          class_2960 icon = CATEGORY_ICONS.get(cat);
          if (icon != null) {
            RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, animationProgress);
            context.method_25290(class_1921::method_62277, icon, iconX, catY + 4, 0.0F, 0.0F, 12, 12, 12, 12);
            RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
          } 
        } 
        
        int textColor = isSelected ? -1 : -5592406;
        context.method_51433(this.field_22793, cat.getName(), textX, catY + 7, ZCoreGuiTheme.applyAlpha(textColor, animationProgress), false);
        catY += 26;
      } 
    } 
    
    int searchY = y + 300 - 35;
    boolean searchHovered = isHovered(mouseX, mouseY, x + 10, searchY, 80, 20);
    int searchBg = (this.moduleSearchEditor.isActive() || searchHovered) ? 822083583 : 369098751;
    RenderUtils.fillRoundRect(context, x + 10, searchY, 80, 20, 5, ZCoreGuiTheme.applyAlpha(searchBg, animationProgress));
    
    String searchText = this.moduleSearchEditor.getText().isEmpty() ? "Search..." : this.moduleSearchEditor.getText();
    if (this.moduleSearchEditor.isActive()) {
      searchText = searchText + searchText;
    }
    context.method_51433(this.field_22793, searchText, x + 15, searchY + 6, ZCoreGuiTheme.applyAlpha(12303291, animationProgress), false);

    
    int contentX = x + 100 + 15;
    int contentY = y + 15;
    int contentWidth = 320;
    int contentHeight = 260;
    
    String title = this.moduleSearchEditor.getText().isEmpty() ? this.currentCategory.getName() : "Search Results";
    context.method_51433(this.field_22793, title, contentX, contentY, ZCoreGuiTheme.applyAlpha(-1, animationProgress), true);

    
    int scrollAreaY = contentY + 25;
    int scrollAreaHeight = 245;
    
    List<Module> modules = this.moduleSearchEditor.getText().isEmpty() ? getModules(this.currentCategory) : getSearchModules();
    int totalModulesHeight = modules.size() * 25;
    this.maxModuleScroll = Math.max(0, totalModulesHeight - scrollAreaHeight);
    
    context.method_44379(contentX, scrollAreaY, contentX + contentWidth, scrollAreaY + scrollAreaHeight);
    
    int moduleY = scrollAreaY - (int)this.moduleScrollOffset;
    for (Module m : modules) {
      if (moduleY + 20 > scrollAreaY && moduleY < scrollAreaY + scrollAreaHeight) {
        boolean hovered = (isHovered(mouseX, mouseY, contentX, moduleY, contentWidth, 20) && isHovered(mouseX, mouseY, contentX, scrollAreaY, contentWidth, scrollAreaHeight));
        int mBgColor = m.isEnabled() ? ZCoreGuiTheme.applyAlpha(this.cachedAccentColor, 0.25F * animationProgress) : ZCoreGuiTheme.applyAlpha(16777215, 0.05F * animationProgress);
        if (hovered) {
          mBgColor = ZCoreGuiTheme.blendColors(mBgColor, 1090519039, 0.3F);
          this.hoveredModule = m;
        } 
        
        RenderUtils.fillRoundRect(context, contentX, moduleY, contentWidth, 20, 6, mBgColor);
        
        int textColor = m.isEnabled() ? -1 : -4473925;
        context.method_51433(this.field_22793, m.getName(), contentX + 8, moduleY + 6, ZCoreGuiTheme.applyAlpha(textColor, animationProgress), false);
        
        if (m.getSettings().size() > 0) {
          context.method_51433(this.field_22793, "...", contentX + contentWidth - 15, moduleY + 6, ZCoreGuiTheme.applyAlpha(8947848, animationProgress), false);
        }
      } 
      moduleY += 25;
    } 
    
    context.method_44380();

    
    if (this.maxModuleScroll > 0.0F) {
      int scrollBarX = contentX + contentWidth + 5;
      int scrollBarY = scrollAreaY;
      int scrollBarWidth = 3;
      int scrollBarHeight = scrollAreaHeight;
      
      RenderUtils.fillRoundRect(context, scrollBarX, scrollBarY, scrollBarWidth, scrollBarHeight, 2, ZCoreGuiTheme.applyAlpha(0, 0.3F * animationProgress));
      
      float scrollProgress = this.moduleScrollOffset / this.maxModuleScroll;
      int handleHeight = Math.max(20, (int)(scrollAreaHeight / totalModulesHeight * scrollAreaHeight));
      int handleY = scrollBarY + (int)((scrollBarHeight - handleHeight) * scrollProgress);
      
      RenderUtils.fillRoundRect(context, scrollBarX, handleY, scrollBarWidth, handleHeight, 2, ZCoreGuiTheme.applyAlpha(this.cachedAccentColor, 0.8F * animationProgress));
    } 
  }
  
  private void cacheThemeValues() {
    ClickGUI clickGUI = (ClickGUI)ZCoreClient.moduleManager.getModule(ClickGUI.class);
    this.cachedCornerRadius = (clickGUI != null && clickGUI.isRounded()) ? 12 : 0;
    this.cachedAccentColor = ZCoreGuiTheme.getAccentColor();
    this.cachedHoverColor = ZCoreGuiTheme.getHoverColor();
    this.cachedTextColor = ZCoreGuiTheme.getTextColor();
    this.cachedPanelAlpha = ZCoreGuiTheme.getPanelAlpha();
  }

  
  public void method_25432() {
    if (ZCoreClient.configManager != null) {
      ZCoreClient.configManager.saveProfile();
    }
  }

  
  public void method_25410(class_310 client, int width, int height) {
    int scaledWidth = client.method_22683().method_4489() / 2;
    int scaledHeight = client.method_22683().method_4506() / 2;
    super.method_25410(client, scaledWidth, scaledHeight);
  }
  
  private void constrainPanelPositions() {
    if (this.selectedModule != null) {
      int contentTopPadding = 10;
      int totalSettingsHeight = (this.selectedModule.getSettings().size() + 1) * 20 + contentTopPadding;
      int visibleContentHeight = Math.min(totalSettingsHeight, 200);
      int panelHeight = 18 + visibleContentHeight + 10;
      
      this.panelX = Math.max(0, Math.min(this.field_22789 - 180, this.panelX));
      this.panelY = Math.max(0, Math.min(this.field_22790 - panelHeight, this.panelY));
      this.panelTargetX = this.panelX;
      this.panelTargetY = this.panelY;
    } else {
      this.panelX = Math.max(0, Math.min(this.field_22789 - 180, this.panelX));
      this.panelY = Math.max(0, Math.min(this.field_22790 - 18 - 10, this.panelY));
      this.panelTargetX = this.panelX;
      this.panelTargetY = this.panelY;
    } 
    
    this.itemPanelX = Math.max(0, Math.min(this.field_22789 - 150, this.itemPanelX));
    this.itemPanelY = Math.max(0, Math.min(this.field_22790 - 180, this.itemPanelY));
    this.itemPanelTargetX = this.itemPanelX;
    this.itemPanelTargetY = this.itemPanelY;
  }
  
  private float easeOutCubic(float t) {
    return 1.0F - (float)Math.pow((1.0F - t), 3.0D);
  }
  
  private int blendColors(int color1, int color2, float ratio) {
    int a1 = color1 >> 24 & 0xFF;
    int r1 = color1 >> 16 & 0xFF;
    int g1 = color1 >> 8 & 0xFF;
    int b1 = color1 & 0xFF;
    
    int a2 = color2 >> 24 & 0xFF;
    int r2 = color2 >> 16 & 0xFF;
    int g2 = color2 >> 8 & 0xFF;
    int b2 = color2 & 0xFF;
    
    int a = (int)(a1 + (a2 - a1) * ratio);
    int r = (int)(r1 + (r2 - r1) * ratio);
    int g = (int)(g1 + (g2 - g1) * ratio);
    int b = (int)(b1 + (b2 - b1) * ratio);
    
    return a << 24 | r << 16 | g << 8 | b;
  }


  
  private void renderModuleTooltip(class_332 context, Module module, int mouseX, int mouseY, float animationProgress) {
    String description = module.getDescription();
    if (description == null || description.trim().isEmpty()) {
      description = "No description available";
    }
    
    String moduleName = module.getName();
    int moduleNameWidth = this.field_22793.method_1727(moduleName);

    
    List<String> lines = wrapText(description, 250);
    Objects.requireNonNull(this.field_22793); int maxLineWidth = lines.stream().mapToInt(this.field_22793::method_1727).max().orElse(0);
    
    int contentWidth = Math.max(moduleNameWidth, maxLineWidth);
    int tooltipWidth = Math.max(120, contentWidth + 16);
    
    int tooltipHeight = 18 + lines.size() * 10 + 8;
    
    int tooltipX = mouseX + 10;
    int tooltipY = mouseY - tooltipHeight - 5;
    
    int screenWidth = this.client.method_22683().method_4489() / 2;
    int screenHeight = this.client.method_22683().method_4506() / 2;

    
    if (tooltipX + tooltipWidth > screenWidth) {
      tooltipX = mouseX - tooltipWidth - 10;
    }
    if (tooltipY < 0) {
      tooltipY = mouseY + 20;
    }
    if (tooltipX < 0) {
      tooltipX = 5;
    }

    
    int tooltipBgColor = ZCoreGuiTheme.applyAlpha(ZCoreGuiTheme.getSettingsPanelColor(), animationProgress * 0.9F);
    RenderUtils.fillRoundRect(context, tooltipX, tooltipY, tooltipWidth, tooltipHeight, 6, tooltipBgColor);
    
    int borderColor = ZCoreGuiTheme.applyAlpha(ZCoreGuiTheme.getBorderColor(), animationProgress * 0.8F);
    RenderUtils.drawRoundRect(context, tooltipX, tooltipY, tooltipWidth, tooltipHeight, 6, borderColor);

    
    int headerColor = ZCoreGuiTheme.applyAlpha(ZCoreGuiTheme.getAccentColor(), (int)(animationProgress * 255.0F)) | 0xFF000000;
    context.method_51433(this.field_22793, moduleName, tooltipX + 8, tooltipY + 4, headerColor, false);

    
    int separatorY = tooltipY + 16;
    int separatorColor = ZCoreGuiTheme.applyAlpha(ZCoreGuiTheme.getSeparatorColor(), animationProgress);
    context.method_25294(tooltipX + 8, separatorY, tooltipX + tooltipWidth - 8, separatorY + 1, separatorColor);

    
    int textColor = ZCoreGuiTheme.applyAlpha(-3355444, (int)(animationProgress * 255.0F)) | 0xFF000000;
    int textY = separatorY + 4;
    for (String line : lines) {
      context.method_51433(this.field_22793, line, tooltipX + 8, textY, textColor, false);
      textY += 10;
    } 
  }
  
  private List<String> wrapText(String text, int maxWidth) {
    List<String> lines = new ArrayList<>();
    if (text == null || text.isEmpty()) {
      lines.add("");
      return lines;
    } 
    
    String[] words = text.split(" ");
    StringBuilder currentLine = new StringBuilder();
    
    for (String word : words) {
      String testLine = (currentLine.length() > 0) ? (String.valueOf(currentLine) + " " + String.valueOf(currentLine)) : word;
      if (this.field_22793.method_1727(testLine) <= maxWidth) {
        currentLine = new StringBuilder(testLine);
      }
      else if (currentLine.length() > 0) {
        lines.add(currentLine.toString());
        currentLine = new StringBuilder(word);
      } else {
        lines.add(word);
      } 
    } 

    
    if (currentLine.length() > 0) {
      lines.add(currentLine.toString());
    }
    
    return lines;
  }
  
  private void renderTooltips(class_332 context, int mouseX, int mouseY, float animationProgress) {
    if (this.hoveredModule != null) {
      renderModuleTooltip(context, this.hoveredModule, mouseX, mouseY, animationProgress);
    }
  }
  
  private void renderSettingsPanel(class_332 context, int mouseX, int mouseY, float animationProgress) {
    if (this.selectedModule == null)
      return; 
    int cornerRadius = this.cachedCornerRadius;
    
    int contentTopPadding = 10;
    int totalSettingsHeight = (this.selectedModule.getSettings().size() + 1) * 20 + contentTopPadding;
    int visibleContentHeight = Math.min(totalSettingsHeight, 200);
    int panelHeight = 18 + visibleContentHeight + 10;
    
    this.maxScroll = Math.max(0, totalSettingsHeight - visibleContentHeight);
    this.settingsScrollOffset = Math.max(0.0F, Math.min(this.settingsScrollOffset, this.maxScroll));
    
    boolean isDragging = this.draggingPanel;
    boolean isHovered = isHovered(mouseX, mouseY, this.panelX, this.panelY, 180, panelHeight);

    
    int panelColor = ZCoreGuiTheme.applyAlpha(ZCoreGuiTheme.getSettingsPanelColor(), animationProgress * this.cachedPanelAlpha);
    if (isDragging) {
      panelColor = blendColors(panelColor, this.cachedAccentColor, 0.08F);
    } else if (isHovered) {
      panelColor = blendColors(panelColor, this.cachedAccentColor, 0.04F);
    } 
    
    RenderUtils.fillRoundRect(context, this.panelX, this.panelY, 180, panelHeight, cornerRadius, panelColor);
    
    int borderColor = ZCoreGuiTheme.applyAlpha(ZCoreGuiTheme.getBorderColor(), animationProgress * 0.6F);
    if (isDragging) {
      borderColor = ZCoreGuiTheme.applyAlpha(this.cachedAccentColor, animationProgress * 0.8F);
    } else if (isHovered) {
      borderColor = ZCoreGuiTheme.applyAlpha(this.cachedAccentColor, animationProgress * 0.6F);
    } 

    
    int headerColor = ZCoreGuiTheme.applyAlpha(ZCoreGuiTheme.getCategoryHeader(), animationProgress * this.cachedPanelAlpha);
    RenderUtils.fillRoundRect(context, this.panelX, this.panelY, 180, 18, cornerRadius, cornerRadius, 0, 0, headerColor);
    
    String headerText = this.selectedModule.getName() + " Settings";
    int headerTextColor = ZCoreGuiTheme.applyAlpha(-1, (int)(animationProgress * 255.0F)) | 0xFF000000;
    context.method_51433(this.field_22793, headerText, this.panelX + 8, this.panelY + 6, headerTextColor, false);
    
    context.method_51433(this.field_22793, "X", this.panelX + 180 - 15, this.panelY + 6, 
        ZCoreGuiTheme.applyAlpha(this.cachedAccentColor, (int)(animationProgress * 255.0F)) | 0xFF000000, false);
    
    int contentY = this.panelY + 18;
    context.method_44379(this.panelX, contentY, this.panelX + 180, contentY + visibleContentHeight);
    
    this.yOffset = contentTopPadding;
    renderKeybindSetting(context, (KeybindSetting)null, this.panelX + 10, contentY + this.yOffset - (int)this.settingsScrollOffset, mouseX, mouseY, animationProgress);
    this.yOffset += 20;
    
    for (Setting<?> setting : (Iterable<Setting<?>>)this.selectedModule.getSettings()) {
      renderSetting(context, setting, this.panelX + 10, contentY + this.yOffset - (int)this.settingsScrollOffset, mouseX, mouseY, animationProgress);
      this.yOffset += 20;
    } 
    
    context.method_44380();
    
    if (this.maxScroll > 0.0F) {
      int scrollBarX = this.panelX + 180 - 6;
      int scrollBarWidth = 4;

      
      RenderUtils.fillRoundRect(context, scrollBarX, contentY, scrollBarWidth, visibleContentHeight, 2, 1879048192);
      
      float scrollProgress = this.settingsScrollOffset / this.maxScroll;
      int totalDrawableHeight = (this.selectedModule.getSettings().size() + 1) * 20 + contentTopPadding;
      int handleHeight = (int)(visibleContentHeight / totalDrawableHeight * visibleContentHeight);
      int handleY = contentY + (int)((visibleContentHeight - handleHeight) * scrollProgress);
      
      int handleColor = this.cachedAccentColor;
      RenderUtils.fillRoundRect(context, scrollBarX, handleY, scrollBarWidth, handleHeight, 2, handleColor);
    } 
  }
  
  private void renderItemSelection(class_332 context, int mouseX, int mouseY, float animationProgress) {
    int cornerRadius = this.cachedCornerRadius;
    
    int bgColor = ZCoreGuiTheme.applyAlpha(ZCoreGuiTheme.getSettingsPanelColor(), animationProgress * ZCoreGuiTheme.getPanelAlpha());
    RenderUtils.fillRoundRect(context, this.itemPanelX, this.itemPanelY, 150, 180, cornerRadius, bgColor);
    
    int borderColor = ZCoreGuiTheme.applyAlpha(ZCoreGuiTheme.getAccentColor(), animationProgress * 0.4F);
    RenderUtils.drawRoundRect(context, this.itemPanelX, this.itemPanelY, 150, 180, cornerRadius, borderColor);
    
    int headerColor = ZCoreGuiTheme.applyAlpha(ZCoreGuiTheme.getCategoryHeader(), animationProgress * ZCoreGuiTheme.getPanelAlpha());
    RenderUtils.fillRoundTabTop(context, this.itemPanelX, this.itemPanelY, 150, 30, cornerRadius, headerColor);
    
    String title = "Select Item";
    int titleColor = ZCoreGuiTheme.applyAlpha(-1, (int)(animationProgress * 255.0F)) | 0xFF000000;
    context.method_51433(this.field_22793, title, this.itemPanelX + 10, this.itemPanelY + 10, titleColor, true);
    
    String closeText = "✕";
    boolean closeHovered = isHovered(mouseX, mouseY, this.itemPanelX + 150 - 20, this.itemPanelY + 8, 16, 16);
    int closeColor = closeHovered ? ZCoreGuiTheme.getAccentColor() : -3355444;
    context.method_51433(this.field_22793, closeText, this.itemPanelX + 150 - 18, this.itemPanelY + 10, 
        ZCoreGuiTheme.applyAlpha(closeColor, (int)(animationProgress * 255.0F)) | 0xFF000000, false);
    
    int searchBarX = this.itemPanelX + 10;
    int searchBarY = this.itemPanelY + 35;
    int searchBarWidth = 130;
    int searchBarHeight = 20;
    boolean searchHovered = isHovered(mouseX, mouseY, searchBarX, searchBarY, searchBarWidth, searchBarHeight);

    
    int searchBarColor = (this.itemSearchEditor.isActive() || searchHovered) ? ZCoreGuiTheme.applyAlpha(ZCoreGuiTheme.getHoverColor(), animationProgress * 0.5F) : ZCoreGuiTheme.applyAlpha(0, 0.0F);
    
    int subRadius = Math.max(2, cornerRadius / 2);
    RenderUtils.fillRoundRect(context, searchBarX, searchBarY, searchBarWidth, searchBarHeight, subRadius, searchBarColor);
    
    String searchText = this.itemSearchEditor.getText();
    if (this.itemSearchEditor.isActive()) {
      int cursorPos = this.itemSearchEditor.getCursorPosition();
      String beforeCursor = searchText.substring(0, cursorPos);
      String afterCursor = searchText.substring(cursorPos);
      searchText = beforeCursor + "_" + beforeCursor;
    } else if (searchText.isEmpty()) {
      searchText = "Search for an item...";
    } 
    context.method_51433(this.field_22793, searchText, searchBarX + 5, searchBarY + 6, titleColor, false);
    
    int itemsStartY = this.itemPanelY + 60;
    int itemsHeight = 110;

    
    int ITEM_SIZE = 20;
    int ITEM_PADDING = 3;
    int ITEMS_PER_ROW = 6;

    
    RenderUtils.fillRoundRect(context, this.itemPanelX + 5, itemsStartY, 140, itemsHeight, subRadius, 
        ZCoreGuiTheme.applyAlpha(0, 0.0F));
    
    context.method_44379(this.itemPanelX + 5, itemsStartY, this.itemPanelX + 150 - 5, itemsStartY + itemsHeight);


    
    List<class_1792> allItems = class_7923.field_41178.method_10220().filter(item -> (item != class_1802.field_8162 && item.method_63680().getString().toLowerCase().contains(this.itemSearchEditor.getText().toLowerCase()))).toList();
    
    int totalRows = (int)Math.ceil(allItems.size() / ITEMS_PER_ROW);
    int visibleRows = itemsHeight / (ITEM_SIZE + ITEM_PADDING);
    int maxRowScroll = Math.max(0, totalRows - visibleRows);
    int rowScrollOffset = Math.max(0, Math.min(this.itemScrollOffset / ITEMS_PER_ROW, maxRowScroll));
    
    int startIndex = rowScrollOffset * ITEMS_PER_ROW;
    int endIndex = Math.min(startIndex + visibleRows * ITEMS_PER_ROW, allItems.size());

    
    int gridWidth = ITEMS_PER_ROW * ITEM_SIZE + (ITEMS_PER_ROW - 1) * ITEM_PADDING;
    int gridStartX = this.itemPanelX + (150 - gridWidth) / 2;
    
    for (int i = startIndex; i < endIndex; i++) {
      int itemBgColor; class_1792 item = allItems.get(i);
      int row = (i - startIndex) / ITEMS_PER_ROW;
      int col = (i - startIndex) % ITEMS_PER_ROW;
      
      int itemX = gridStartX + col * (ITEM_SIZE + ITEM_PADDING);
      int itemY = itemsStartY + 5 + row * (ITEM_SIZE + ITEM_PADDING);
      
      boolean itemHovered = isHovered(mouseX, mouseY, itemX, itemY, ITEM_SIZE, ITEM_SIZE);
      boolean selected = (item == this.editingItem.getItem());

      
      if (selected) {
        itemBgColor = ZCoreGuiTheme.applyAlpha(ZCoreGuiTheme.getAccentColor(), animationProgress * 0.4F);
      } else if (itemHovered) {
        itemBgColor = ZCoreGuiTheme.applyAlpha(ZCoreGuiTheme.getHoverColor(), animationProgress * 0.3F);
      } else {
        itemBgColor = ZCoreGuiTheme.applyAlpha(0, 0.0F);
      } 
      
      if (itemBgColor != 0) {
        int itemRadius = 2;
        RenderUtils.fillRoundRect(context, itemX, itemY, ITEM_SIZE, ITEM_SIZE, itemRadius, itemBgColor);
      } 

      
      if (selected) {
        int itemBorderColor = ZCoreGuiTheme.applyAlpha(ZCoreGuiTheme.getAccentColor(), animationProgress * 0.9F);
        RenderUtils.drawRoundRect(context, itemX, itemY, ITEM_SIZE, ITEM_SIZE, 2, itemBorderColor);
      } 
      
      class_1799 itemStack = new class_1799((class_1935)item);
      context.method_51427(itemStack, itemX, itemY);
    } 
    
    context.method_44380();
    
    if (maxRowScroll > 0) {
      int scrollBarX = this.itemPanelX + 150 - 12;
      int scrollBarY = itemsStartY + 5;
      int scrollBarHeight = itemsHeight - 10;
      int scrollBarWidth = 4;
      
      int scrollBarBgColor = ZCoreGuiTheme.applyAlpha(1342177280, animationProgress);
      RenderUtils.fillRoundRect(context, scrollBarX, scrollBarY, scrollBarWidth, scrollBarHeight, 2, scrollBarBgColor);
      
      float scrollProgress = (maxRowScroll > 0) ? (rowScrollOffset / maxRowScroll) : 0.0F;
      int handleHeight = Math.max(20, (int)(visibleRows / totalRows * scrollBarHeight));
      int handleY = scrollBarY + (int)((scrollBarHeight - handleHeight) * scrollProgress);
      
      int handleColor = ZCoreGuiTheme.applyAlpha(ZCoreGuiTheme.getAccentColor(), animationProgress);
      RenderUtils.fillRoundRect(context, scrollBarX, handleY, scrollBarWidth, handleHeight, 2, handleColor);
    } 
  }
  private void renderKeybindSetting(class_332 context, KeybindSetting setting, int x, int y, int mouseX, int mouseY, float animationProgress) {
    String buttonText;
    int buttonColor, verticalCenter = y + 6;
    int textColor = ZCoreGuiTheme.applyAlpha(-1, (int)(animationProgress * 255.0F)) | 0xFF000000;
    
    boolean hovered = isHovered(mouseX, mouseY, x, y, 160, 20);
    if (hovered) {
      int bgColor = ZCoreGuiTheme.applyAlpha(this.cachedHoverColor, animationProgress * 0.75F);
      RenderUtils.fillRoundRect(context, x, y, 160, 20, 3, bgColor);
    } 

    
    String labelText = (setting != null) ? setting.getName() : "Keybind";
    context.method_51433(this.field_22793, labelText, x, verticalCenter, textColor, false);



    
    boolean isListening = false;
    
    if (setting != null) {
      isListening = (this.listeningForKeybind && this.listeningKeybindSetting == setting);
      if (isListening) {
        buttonText = "Press a key...";
        buttonColor = ZCoreGuiTheme.applyAlpha(this.cachedAccentColor, animationProgress);
      } else {
        buttonText = KeybindManager.getKeyName(((Integer)setting.getValue()).intValue());
        buttonColor = ZCoreGuiTheme.applyAlpha(-11184811, animationProgress * this.cachedPanelAlpha);
      } 
    } else {
      isListening = (this.listeningForKeybind && this.listeningKeybindSetting == null && this.keybindModule == this.selectedModule);
      if (isListening) {
        buttonText = "Press a key...";
        buttonColor = ZCoreGuiTheme.applyAlpha(this.cachedAccentColor, animationProgress);
      } else {
        buttonText = KeybindManager.getKeyName(this.selectedModule.getKeyBind());
        buttonColor = ZCoreGuiTheme.applyAlpha(-11184811, animationProgress * this.cachedPanelAlpha);
      } 
    } 

    
    int buttonHeight = 16;
    int buttonWidth = Math.max(60, this.field_22793.method_1727(buttonText) + 10);
    int buttonX = x + 180 - 30 - buttonWidth;
    int buttonY = y + 2;

    
    RenderUtils.fillRoundRect(context, buttonX, buttonY, buttonWidth, buttonHeight, 5, buttonColor);

    
    int buttonTextX = buttonX + (buttonWidth - this.field_22793.method_1727(buttonText)) / 2;
    int buttonTextY = buttonY + (buttonHeight - 8) / 2;
    context.method_51433(this.field_22793, buttonText, buttonTextX, buttonTextY, -1, false);
  }
  
  private void renderSetting(class_332 context, Object setting, int x, int y, int mouseX, int mouseY, float animationProgress) {
    int textColor = ZCoreGuiTheme.applyAlpha(-1, (int)(animationProgress * 255.0F)) | 0xFF000000;
    int verticalCenter = y + 6;
    
    if (setting instanceof BooleanSetting) { BooleanSetting b = (BooleanSetting)setting;
      if (b
        .getName().equals("Execute Action") || b
        .getName().equals("Set Pos 1") || b
        .getName().equals("Set Pos 2") || b
        .getName().equals("Start Mining") || b
        .getName().equals("Stop Mining")) {
        
        renderExecuteButton(context, b, x, y, mouseX, mouseY, animationProgress);
        this.yOffset += 4;
        return;
      } 
      int boxSize = 12;
      int boxY = y + (20 - boxSize) / 2;

      
      int boxColor = ((Boolean)b.getValue()).booleanValue() ? ZCoreGuiTheme.applyAlpha(this.cachedAccentColor, animationProgress) : ZCoreGuiTheme.applyAlpha(-11184811, animationProgress * this.cachedPanelAlpha);
      
      RenderUtils.fillRoundRect(context, x, boxY, boxSize, boxSize, 4, boxColor);
      
      context.method_51433(this.field_22793, b.getName(), x + boxSize + 8, verticalCenter, textColor, false); }
    
    else if (setting instanceof SliderSetting) { SliderSetting s = (SliderSetting)setting;
      renderSlider(context, s, x, y, mouseX, mouseY, animationProgress); }
    
    else if (setting instanceof NumberSetting) { NumberSetting n = (NumberSetting)setting;
      renderNumberSlider(context, n, x, y, mouseX, mouseY, animationProgress); }
    
    else if (setting instanceof StringSetting) { StringSetting s = (StringSetting)setting;
      renderStringSetting(context, s, x, y, mouseX, mouseY, animationProgress, textColor, verticalCenter); }
    
    else if (setting instanceof ItemSetting) { ItemSetting itemSetting = (ItemSetting)setting;
      renderItemSetting(context, itemSetting, x, y, mouseX, mouseY, animationProgress, textColor, verticalCenter); }
    
    else if (setting instanceof BlockSetting) { BlockSetting blockSetting = (BlockSetting)setting;
      renderBlockSetting(context, blockSetting, x, y, mouseX, mouseY, animationProgress, textColor, verticalCenter); }
    
    else if (setting instanceof ModeSetting) { ModeSetting<?> modeSetting = (ModeSetting)setting;
      renderModeSetting(context, modeSetting, x, y, mouseX, mouseY, animationProgress, textColor, verticalCenter); }
    
    else if (setting instanceof EnchantmentSetting) { EnchantmentSetting enchantSetting = (EnchantmentSetting)setting;
      renderEnchantmentSetting(context, enchantSetting, x, y, mouseX, mouseY, animationProgress, textColor, verticalCenter); }
    
    else if (setting instanceof KeybindSetting) { KeybindSetting keybindSetting = (KeybindSetting)setting;
      renderKeybindSetting(context, keybindSetting, x, y, mouseX, mouseY, animationProgress); }
    
    else if (setting instanceof DoubleSetting) { DoubleSetting d = (DoubleSetting)setting;
      renderDoubleSlider(context, d, x, y, mouseX, mouseY, animationProgress); }
    
    else if (setting instanceof ColorSetting) { ColorSetting colorSetting = (ColorSetting)setting;
      renderColorSetting(context, colorSetting, x, y, mouseX, mouseY, animationProgress, textColor, verticalCenter); }
    
    else if (setting instanceof StringListSetting) { StringListSetting stringListSetting = (StringListSetting)setting;
      renderStringListSetting(context, stringListSetting, x, y, mouseX, mouseY, animationProgress, textColor, verticalCenter); }
    
    else if (setting instanceof ProfileSetting) { ProfileSetting profileSetting = (ProfileSetting)setting;
      if (profileSetting.isExpanded()) {
        this.renderingDropdown = true;
      } else {
        renderProfileSetting(context, profileSetting, x, y, mouseX, mouseY, animationProgress);
      }  }
  
  }
  
  private void renderBlockSetting(class_332 context, BlockSetting blockSetting, int x, int y, int mouseX, int mouseY, float animationProgress, int textColor, int verticalCenter) {
    String text = blockSetting.getName() + ": ";
    context.method_51433(this.field_22793, text, x, verticalCenter, textColor, false);
    String valueText = blockSetting.getBlocks().isEmpty() ? "None selected" : ("" + blockSetting.getBlocks().size() + " block" + blockSetting.getBlocks().size() + " selected");
    int valueX = x + this.field_22793.method_1727(text);
    int boxHeight = 18;
    int boxWidth = 160 - this.field_22793.method_1727(text);
    boolean hovered = isHovered(mouseX, mouseY, valueX - 2, y + 1, boxWidth + 4, boxHeight);

    
    int boxColor = hovered ? ZCoreGuiTheme.applyAlpha(this.cachedHoverColor, animationProgress * 0.75F) : ZCoreGuiTheme.applyAlpha(-13421773, animationProgress * this.cachedPanelAlpha);
    drawRoundedRect(context, valueX - 2, y + 1, boxWidth + 4, boxHeight, 3, boxColor);
    context.method_51433(this.field_22793, valueText, valueX, verticalCenter, textColor, false);
  }
  
  private void renderStringSetting(class_332 context, StringSetting s, int x, int y, int mouseX, int mouseY, float animationProgress, int textColor, int verticalCenter) {
    String str1, text = s.getName() + ": ";
    context.method_51433(this.field_22793, text, x, verticalCenter, textColor, false);

    
    if (this.editingString == s && this.stringEditor.isActive()) {
      String editorText = this.stringEditor.getText();
      int cursorPos = this.stringEditor.getCursorPosition();
      String beforeCursor = editorText.substring(0, cursorPos);
      String afterCursor = editorText.substring(cursorPos);
      str1 = beforeCursor + "_" + beforeCursor;
    } else {
      str1 = (String)s.getValue();
    } 
    if (((String)s.getValue()).isEmpty() && this.editingString != s) {
      str1 = "Click to edit...";
    }
    
    int valueX = x + this.field_22793.method_1727(text);
    int boxHeight = 18;
    int boxWidth = 160 - this.field_22793.method_1727(text);
    
    boolean boxHovered = isHovered(mouseX, mouseY, valueX - 2, y + 1, boxWidth + 4, boxHeight);

    
    int boxColor = (this.editingString == s || boxHovered) ? ZCoreGuiTheme.applyAlpha(this.cachedHoverColor, animationProgress * 0.75F) : ZCoreGuiTheme.applyAlpha(-13421773, animationProgress * this.cachedPanelAlpha);
    
    drawRoundedRect(context, valueX - 2, y + 1, boxWidth + 4, boxHeight, 3, boxColor);
    
    context.method_51433(this.field_22793, str1, valueX, verticalCenter, textColor, false);
  }
  
  private void renderItemSetting(class_332 context, ItemSetting itemSetting, int x, int y, int mouseX, int mouseY, float animationProgress, int textColor, int verticalCenter) {
    String text = itemSetting.getName() + ": ";
    context.method_51433(this.field_22793, text, x, verticalCenter, textColor, false);
    
    String valueText = itemSetting.getItem().method_63680().getString();
    int valueX = x + this.field_22793.method_1727(text);
    int boxHeight = 18;
    int boxWidth = 160 - this.field_22793.method_1727(text);
    
    boolean hovered = isHovered(mouseX, mouseY, valueX - 2, y + 1, boxWidth + 4, boxHeight);

    
    int boxColor = hovered ? ZCoreGuiTheme.applyAlpha(this.cachedHoverColor, animationProgress * 0.75F) : ZCoreGuiTheme.applyAlpha(-13421773, animationProgress * this.cachedPanelAlpha);
    
    drawRoundedRect(context, valueX - 2, y + 1, boxWidth + 4, boxHeight, 3, boxColor);
    
    context.method_51433(this.field_22793, valueText, valueX, verticalCenter, textColor, false);
  }
  
  private void renderModeSetting(class_332 context, ModeSetting<?> modeSetting, int x, int y, int mouseX, int mouseY, float animationProgress, int textColor, int verticalCenter) {
    String text = modeSetting.getName() + ": ";
    context.method_51433(this.field_22793, text, x, verticalCenter, textColor, false);
    
    String valueText = ((Enum)modeSetting.getValue()).toString();
    int valueX = x + this.field_22793.method_1727(text);
    int boxHeight = 18;
    int boxWidth = 160 - this.field_22793.method_1727(text);
    
    boolean hovered = isHovered(mouseX, mouseY, valueX - 2, y + 1, boxWidth + 4, boxHeight);

    
    int boxColor = hovered ? ZCoreGuiTheme.applyAlpha(this.cachedHoverColor, animationProgress * 0.75F) : ZCoreGuiTheme.applyAlpha(-13421773, animationProgress * this.cachedPanelAlpha);
    
    drawRoundedRect(context, valueX - 2, y + 1, boxWidth + 4, boxHeight, 3, boxColor);
    
    context.method_51433(this.field_22793, valueText, valueX, verticalCenter, textColor, false);
  }
  
  private void renderEnchantmentSetting(class_332 context, EnchantmentSetting enchantSetting, int x, int y, int mouseX, int mouseY, float animationProgress, int textColor, int verticalCenter) {
    String text = enchantSetting.getName() + ": ";
    context.method_51433(this.field_22793, text, x, verticalCenter, textColor, false);

    
    int totalSelected = enchantSetting.getTotalCount();
    
    String valueText = (totalSelected == 0) ? "None" : ("" + totalSelected + " selected");
    int valueX = x + this.field_22793.method_1727(text);
    int boxHeight = 18;
    int boxWidth = 160 - this.field_22793.method_1727(text);
    
    boolean hovered = isHovered(mouseX, mouseY, valueX - 2, y + 1, boxWidth + 4, boxHeight);

    
    int boxColor = hovered ? ZCoreGuiTheme.applyAlpha(this.cachedHoverColor, animationProgress * 0.75F) : ZCoreGuiTheme.applyAlpha(-13421773, animationProgress * this.cachedPanelAlpha);
    
    drawRoundedRect(context, valueX - 2, y + 1, boxWidth + 4, boxHeight, 3, boxColor);
    
    context.method_51433(this.field_22793, valueText, valueX, verticalCenter, textColor, false);
  }
  
  private void renderColorSetting(class_332 context, ColorSetting colorSetting, int x, int y, int mouseX, int mouseY, float animationProgress, int textColor, int verticalCenter) {
    String text = colorSetting.getName() + ": ";
    context.method_51433(this.field_22793, text, x, verticalCenter, textColor, false);
    
    Color color = colorSetting.getValue();
    String valueText = String.format("#%02X%02X%02X", new Object[] { Integer.valueOf(color.getRed()), Integer.valueOf(color.getGreen()), Integer.valueOf(color.getBlue()) });
    
    int valueX = x + this.field_22793.method_1727(text);
    int boxHeight = 18;
    int boxWidth = 160 - this.field_22793.method_1727(text);
    int colorPreviewSize = boxHeight - 4;
    
    boolean hovered = isHovered(mouseX, mouseY, valueX - 2, y + 1, boxWidth + 4, boxHeight);

    
    int boxColor = hovered ? ZCoreGuiTheme.applyAlpha(this.cachedHoverColor, animationProgress * 0.75F) : ZCoreGuiTheme.applyAlpha(-13421773, animationProgress * this.cachedPanelAlpha);
    
    drawRoundedRect(context, valueX - 2, y + 1, boxWidth + 4, boxHeight, 3, boxColor);
    
    int colorInt = 0xFF000000 | color.getRed() << 16 | color.getGreen() << 8 | color.getBlue();
    drawRoundedRect(context, valueX + 2, y + 3, colorPreviewSize, colorPreviewSize, 2, 
        ZCoreGuiTheme.applyAlpha(colorInt, animationProgress));
    
    int textX = valueX + colorPreviewSize + 6;
    context.method_51433(this.field_22793, valueText, textX, verticalCenter, textColor, false);
  }
  
  private void renderStringListSetting(class_332 context, StringListSetting setting, int x, int y, int mouseX, int mouseY, float animationProgress, int textColor, int verticalCenter) {
    String text = setting.getName() + ": ";
    context.method_51433(this.field_22793, text, x, verticalCenter, textColor, false);
    
    String valueText = "" + setting.size() + " item" + setting.size();
    if (setting.isEmpty()) {
      valueText = "Click to edit...";
    }
    
    int valueX = x + this.field_22793.method_1727(text);
    int boxHeight = 18;
    int boxWidth = 160 - this.field_22793.method_1727(text);
    
    boolean hovered = isHovered(mouseX, mouseY, valueX - 2, y + 1, boxWidth + 4, boxHeight);

    
    int boxColor = hovered ? ZCoreGuiTheme.applyAlpha(this.cachedHoverColor, animationProgress * 0.75F) : ZCoreGuiTheme.applyAlpha(-13421773, animationProgress * this.cachedPanelAlpha);
    
    drawRoundedRect(context, valueX - 2, y + 1, boxWidth + 4, boxHeight, 3, boxColor);
    context.method_51433(this.field_22793, valueText, valueX, verticalCenter, textColor, false);
  }
  
  private void renderExecuteButton(class_332 context, BooleanSetting setting, int x, int y, int mouseX, int mouseY, float animationProgress) {
    boolean hovered = isHovered(mouseX, mouseY, x, y, 160, 20);
    
    int color = hovered ? this.cachedAccentColor : -11184811;
    drawRoundedRect(context, x, y, 160, 20, 5, ZCoreGuiTheme.applyAlpha(color, animationProgress));
    
    context.method_25300(this.field_22793, setting.getName(), x + 80, y + 6, -1);
  }
  
  private void renderProfileSetting(class_332 context, ProfileSetting setting, int x, int y, int mouseX, int mouseY, float animationProgress) {
    int textColor = ZCoreGuiTheme.applyAlpha(-1, (int)(animationProgress * 255.0F)) | 0xFF000000;
    int verticalCenter = y + 6;
    String text = setting.getName() + ": ";
    context.method_51433(this.field_22793, text, x, verticalCenter, textColor, false);
    
    String valueText = (String)setting.getValue();
    int textWidth = this.field_22793.method_1727(text);
    int valueX = x + textWidth;
    int boxHeight = 18;
    int boxWidth = 160 - textWidth;
    
    boolean hovered = isHovered(mouseX, mouseY, valueX - 2, y + 1, boxWidth + 4, boxHeight);

    
    int boxColor = (hovered || setting.isExpanded()) ? ZCoreGuiTheme.applyAlpha(this.cachedHoverColor, animationProgress * 0.75F) : ZCoreGuiTheme.applyAlpha(-13421773, animationProgress * this.cachedPanelAlpha);
    
    drawRoundedRect(context, valueX - 2, y + 1, boxWidth + 4, boxHeight, 3, boxColor);
    
    context.method_51433(this.field_22793, valueText, valueX, verticalCenter, textColor, false);
    
    if (setting.isExpanded()) {
      int dropdownY = y + boxHeight + 3;
      int dropdownHeight = setting.getProfiles().size() * 12 + 2;
      drawRoundedRect(context, valueX - 2, dropdownY, boxWidth + 4, dropdownHeight, 3, -14671840);
      
      int itemY = dropdownY + 2;
      for (String profile : setting.getProfiles()) {
        boolean itemHovered = isHovered(mouseX, mouseY, valueX - 2, itemY, boxWidth + 4, 12);
        if (itemHovered) {
          context.method_25294(valueX - 2, itemY, valueX - 2 + boxWidth + 4, itemY + 12, ZCoreGuiTheme.applyAlpha(this.cachedAccentColor, animationProgress));
        }
        context.method_51433(this.field_22793, profile, valueX, itemY + 2, textColor, false);
        itemY += 12;
      } 
    } 
  }
  
  private void renderSlider(class_332 context, SliderSetting setting, int x, int y, int mouseX, int mouseY, float animationProgress) {
    String nameText = setting.getName();
    
    String valueText = String.valueOf((long)((Double)setting.getValue()).doubleValue());
    int valueWidth = this.field_22793.method_1727(valueText);
    
    int textColor = ZCoreGuiTheme.applyAlpha(-1, (int)(animationProgress * 255.0F)) | 0xFF000000;
    
    context.method_51433(this.field_22793, nameText, x, y + 2, textColor, false);
    context.method_51433(this.field_22793, valueText, x + 150 - valueWidth, y + 2, textColor, false);
    
    int sliderY = y + 12;
    
    int bgColor = ZCoreGuiTheme.applyAlpha(-13421773, animationProgress * this.cachedPanelAlpha);
    drawRoundedRect(context, x, sliderY, 150, 6, 3, bgColor);
    
    double position = setting.getSliderPosition();
    int filledWidth = (int)(150.0D * position);
    
    if (filledWidth > 0) {
      int fillColor = ZCoreGuiTheme.applyAlpha(this.cachedAccentColor, animationProgress);
      drawRoundedRect(context, x, sliderY, filledWidth, 6, 3, fillColor);
    } 
    
    int handleX = x + filledWidth - 3;
    int handleColor = ZCoreGuiTheme.applyAlpha(-1, animationProgress);
    drawRoundedRect(context, handleX, sliderY - 2, 6, 10, 3, handleColor);
  }



  
  private void renderNumberSlider(class_332 context, NumberSetting setting, int x, int y, int mouseX, int mouseY, float animationProgress) {
    String nameText = setting.getName();
    
    String valueText = String.valueOf((long)((Double)setting.getValue()).doubleValue());
    int valueWidth = this.field_22793.method_1727(valueText);
    
    int textColor = ZCoreGuiTheme.applyAlpha(-1, (int)(animationProgress * 255.0F)) | 0xFF000000;
    
    context.method_51433(this.field_22793, nameText, x, y + 2, textColor, false);
    context.method_51433(this.field_22793, valueText, x + 150 - valueWidth, y + 2, textColor, false);
    
    int sliderY = y + 12;
    
    int bgColor = ZCoreGuiTheme.applyAlpha(-13421773, animationProgress * this.cachedPanelAlpha);
    drawRoundedRect(context, x, sliderY, 150, 6, 3, bgColor);
    
    double position = (((Double)setting.getValue()).doubleValue() - setting.getMin()) / (setting.getMax() - setting.getMin());
    int filledWidth = (int)(150.0D * position);
    
    if (filledWidth > 0) {
      int fillColor = ZCoreGuiTheme.applyAlpha(this.cachedAccentColor, animationProgress);
      drawRoundedRect(context, x, sliderY, filledWidth, 6, 3, fillColor);
    } 
    
    int handleX = x + filledWidth - 3;
    int handleColor = ZCoreGuiTheme.applyAlpha(-1, animationProgress);
    drawRoundedRect(context, handleX, sliderY - 2, 6, 10, 3, handleColor);
  }



  
  private void renderDoubleSlider(class_332 context, DoubleSetting setting, int x, int y, int mouseX, int mouseY, float animationProgress) {
    String nameText = setting.getName();

    
    String valueText = String.format("%.2f", new Object[] { setting.getValue() });
    int valueWidth = this.field_22793.method_1727(valueText);
    
    int textColor = ZCoreGuiTheme.applyAlpha(-1, (int)(animationProgress * 255.0F)) | 0xFF000000;
    
    context.method_51433(this.field_22793, nameText, x, y + 2, textColor, false);
    context.method_51433(this.field_22793, valueText, x + 150 - valueWidth, y + 2, textColor, false);
    
    int sliderY = y + 12;
    
    int bgColor = ZCoreGuiTheme.applyAlpha(-13421773, animationProgress * this.cachedPanelAlpha);
    drawRoundedRect(context, x, sliderY, 150, 6, 3, bgColor);
    
    double position = (((Double)setting.getValue()).doubleValue() - setting.getMin()) / (setting.getMax() - setting.getMin());
    int filledWidth = (int)(150.0D * position);
    
    if (filledWidth > 0) {
      int fillColor = ZCoreGuiTheme.applyAlpha(this.cachedAccentColor, animationProgress);
      drawRoundedRect(context, x, sliderY, filledWidth, 6, 3, fillColor);
    } 
    
    int handleX = x + filledWidth - 3;
    int handleColor = ZCoreGuiTheme.applyAlpha(-1, animationProgress);
    drawRoundedRect(context, handleX, sliderY - 2, 6, 10, 3, handleColor);
  }



  
  private void drawRoundedRect(class_332 context, int x, int y, int width, int height, int radius, int color) {
    if (radius <= 0) {
      context.method_25294(x, y, x + width, y + height, color);
      
      return;
    } 
    RenderUtils.fillRoundRect(context, x, y, width, height, radius, color);
  }
  
  private void drawRoundedRectTop(class_332 context, int x, int y, int width, int height, int radius, int color) {
    if (radius <= 0) {
      context.method_25294(x, y, x + width, y + height, color);
      
      return;
    } 
    RenderUtils.fillRoundTabTop(context, x, y, width, height, radius, color);
  }
  
  private void drawRoundedRectBottom(class_332 context, int x, int y, int radius, int color) {
    if (radius <= 0) {
      context.method_25294(x, y, x + 115, y + 15, color);
      
      return;
    } 
    RenderUtils.fillRoundTabBottom(context, x, y, 115, 15, radius, color);
  }
  
  private void drawRoundedRectOutline(class_332 context, int x, int y, int width, int height, int radius, int color) {
    if (radius <= 0) {
      context.method_25294(x, y, x + width, y + 1, color);
      context.method_25294(x, y + height - 1, x + width, y + height, color);
      context.method_25294(x, y, x + 1, y + height, color);
      context.method_25294(x + width - 1, y, x + width, y + height, color);
      
      return;
    } 
    
    RenderUtils.drawRoundRect(context, x, y, width, height, radius, color);
  }
  
  private List<Module> getModules(Module.Category cat) {
    if (ZCoreClient.moduleManager == null) return List.of();
    
    return ZCoreClient.moduleManager.getModules().stream()
      .filter(m -> (m.getCategory() == cat))
      .sorted((a, b) -> a.getName().compareToIgnoreCase(b.getName()))
      .toList();
  }
  
  private List<Module> getSearchModules() {
    if (ZCoreClient.moduleManager == null) return List.of(); 
    if (this.moduleSearchEditor.getText().isEmpty()) return List.of();
    
    String query = this.moduleSearchEditor.getText().toLowerCase();
    return ZCoreClient.moduleManager.getModules().stream()
      .filter(m -> {
          String name = m.getName().toLowerCase();
          String description = (m.getDescription() != null) ? m.getDescription().toLowerCase() : "";
          return (name.contains(query) || description.contains(query));
        
        }).sorted((a, b) -> a.getName().compareToIgnoreCase(b.getName()))
      .toList();
  }

  
  private void renderSearchCategory(class_332 context, Module.Category cat, int x, int y, int mouseX, int mouseY, float animationProgress) {}

  
  private boolean isHovered(int mx, int my, int x, int y, int w, int h) {
    return (mx >= x && mx <= x + w && my >= y && my <= y + h);
  }

  
  public boolean method_25402(double mx, double my, int button) {
    mx = scaleInput(mx);
    my = scaleInput(my);
    
    if (this.listeningForKeybind && this.keybindModule != null) {
      int mouseKeyCode = KeybindManager.getMouseButtonKeyCode(button);
      if (this.listeningKeybindSetting != null) {
        this.listeningKeybindSetting.setValue(Integer.valueOf(mouseKeyCode));
      } else {
        this.keybindModule.setKeyBind(mouseKeyCode);
      } 
      this.listeningForKeybind = false;
      this.listeningKeybindSetting = null;
      this.keybindModule = null;
      if (ZCoreClient.getConfigManager() != null) {
        ZCoreClient.getConfigManager().saveKeybinds();
      }
      return true;
    } 
    
    StringSetting clickedStringSetting = null;
    
    if (this.blockSelectionPanel.isOpen() && 
      this.blockSelectionPanel.handleClick(mx, my, button)) {
      return true;
    }

    
    if (this.enchantmentPanel.isOpen() && 
      this.enchantmentPanel.handleClick(mx, my, button)) {
      return true;
    }


    
    if (this.colorPickerPanel.isOpen() && 
      this.colorPickerPanel.handleClick(mx, my, button)) {
      return true;
    }


    
    if (this.stringListPanel.isOpen() && 
      this.stringListPanel.handleClick(mx, my, button)) {
      return true;
    }

    
    if (this.editingItem != null) {
      if (button == 0 && isHovered((int)mx, (int)my, this.itemPanelX, this.itemPanelY, 150, 30)) {
        int i = this.itemPanelX + 150 - 18;
        int j = this.itemPanelY + 10;
        if (!isHovered((int)mx, (int)my, i - 2, j, 14, 10)) {
          this.draggingItemPanel = true;
          this.itemPanelDragOffsetX = (int)mx - this.itemPanelX;
          this.itemPanelDragOffsetY = (int)my - this.itemPanelY;
          this.itemPanelIsDragging = true;
          this.itemPanelDragStartTime = System.currentTimeMillis();
          return true;
        } 
      } 
      
      int searchBarX = this.itemPanelX + 10;
      int searchBarY = this.itemPanelY + 40;
      int searchBarWidth = 130;
      int searchBarHeight = 20;
      if (isHovered((int)mx, (int)my, searchBarX, searchBarY, searchBarWidth, searchBarHeight)) {
        if (!this.itemSearchEditor.isActive()) {
          this.itemSearchEditor.startEditing(this.itemSearchEditor.getText());
        }
        return true;
      } 
      
      if (this.itemSearchEditor.isActive()) {
        this.itemSearchEditor.stopEditing();
      }
      
      int closeButtonX = this.itemPanelX + 150 - 18;
      int closeButtonY = this.itemPanelY + 10;
      if (isHovered((int)mx, (int)my, closeButtonX - 2, closeButtonY, 14, 10)) {
        this.editingItem = null;
        return true;
      } 
      
      int itemsStartY = this.itemPanelY + 70;
      int itemsHeight = 100;

      
      int ITEM_SIZE = 20;
      int ITEM_PADDING = 3;
      int ITEMS_PER_ROW = 6;
      
      if (isHovered((int)mx, (int)my, this.itemPanelX + 5, itemsStartY, 140, itemsHeight)) {

        
        List<class_1792> allItems = class_7923.field_41178.method_10220().filter(item -> (item != class_1802.field_8162 && item.method_63680().getString().toLowerCase().contains(this.itemSearchEditor.getText().toLowerCase()))).toList();
        
        int totalRows = (int)Math.ceil(allItems.size() / ITEMS_PER_ROW);
        int visibleRows = itemsHeight / (ITEM_SIZE + ITEM_PADDING);
        int maxRowScroll = Math.max(0, totalRows - visibleRows);
        int rowScrollOffset = Math.max(0, Math.min(this.itemScrollOffset / ITEMS_PER_ROW, maxRowScroll));
        int scrollBarX = this.itemPanelX + 150 - 12;
        int scrollBarY = itemsStartY + 5;
        int scrollBarHeight = itemsHeight - 10;
        int scrollBarWidth = 4;
        if (maxRowScroll > 0 && mx >= scrollBarX && mx < (scrollBarX + scrollBarWidth)) {
          float scrollProgress = (float)(my - scrollBarY) / scrollBarHeight;
          scrollProgress = Math.max(0.0F, Math.min(1.0F, scrollProgress));
          rowScrollOffset = (int)(scrollProgress * maxRowScroll);
          this.itemScrollOffset = rowScrollOffset * ITEMS_PER_ROW;
          return true;
        } 
        
        int gridWidth = ITEMS_PER_ROW * ITEM_SIZE + (ITEMS_PER_ROW - 1) * ITEM_PADDING;
        int gridStartX = this.itemPanelX + (150 - gridWidth) / 2;

        
        if (mx >= gridStartX && mx < (gridStartX + gridWidth) && mx < scrollBarX) {
          int clickedCol = (int)((mx - gridStartX) / (ITEM_SIZE + ITEM_PADDING));
          int clickedRow = (int)((my - (itemsStartY + 5)) / (ITEM_SIZE + ITEM_PADDING));

          
          int cellX = gridStartX + clickedCol * (ITEM_SIZE + ITEM_PADDING);
          int cellY = itemsStartY + 5 + clickedRow * (ITEM_SIZE + ITEM_PADDING);
          
          if (clickedCol >= 0 && clickedCol < ITEMS_PER_ROW && clickedRow >= 0 && clickedRow < visibleRows && mx >= cellX && mx < (cellX + ITEM_SIZE) && my >= cellY && my < (cellY + ITEM_SIZE)) {


            
            int clickedIndex = (rowScrollOffset + clickedRow) * ITEMS_PER_ROW + clickedCol;
            
            if (clickedIndex >= 0 && clickedIndex < allItems.size()) {
              class_1792 selectedItem = allItems.get(clickedIndex);
              this.editingItem.setValue(selectedItem);
              this.editingItem = null;
              return true;
            } 
          } 
        } 
      } 
      
      if (!isHovered((int)mx, (int)my, this.itemPanelX, this.itemPanelY, 150, 180)) {
        this.editingItem = null;
      }
      return true;
    } 
    
    if (this.selectedModule != null) {
      int contentTopPadding = 10;
      int totalSettingsHeight = (this.selectedModule.getSettings().size() + 1) * 20 + contentTopPadding;
      int visibleContentHeight = Math.min(totalSettingsHeight, 200);
      int i = this.panelY + 18;
      
      if (isHovered((int)mx, (int)my, this.panelX, i, 180, visibleContentHeight)) {
        int yOffset = i + contentTopPadding - (int)this.settingsScrollOffset;
        yOffset += 20;
        
        for (Setting<?> setting : (Iterable<Setting<?>>)this.selectedModule.getSettings()) {
          if (setting instanceof StringSetting) { StringSetting s = (StringSetting)setting;
            if (isHovered((int)mx, (int)my, this.panelX + 10, yOffset, 160, 20)) {
              clickedStringSetting = s;
              break;
            }  }
          
          yOffset += 20;
        } 
      } 
    } 
    
    if (this.editingString != null && this.editingString != clickedStringSetting) {
      this.editingString.setValue(this.stringEditor.getText());
      this.editingString = null;
      this.stringEditor.stopEditing();
    } 
int screenWidth = this.client.method_22683().method_4489() / 2;
    int screenHeight = this.client.method_22683().method_4506() / 2;
    int dashX = (screenWidth - 450) / 2;
    int dashY = (screenHeight - 300) / 2;
    if (this.selectedModule != null) {
      int visibleContentHeight = Math.min((this.selectedModule.getSettings().size() + 1) * 20 + 10, 200);
      int panelHeight = 18 + visibleContentHeight + 10;
      
      if (isHovered((int)mx, (int)my, this.panelX, this.panelY, 180, panelHeight)) {
        if (isHovered((int)mx, (int)my, this.panelX + 180 - 20, this.panelY, 20, 18)) {
          this.selectedModule = null;
          return true;
        } 

        
        if (isHovered((int)mx, (int)my, this.panelX, this.panelY, 180, 18) && 
          button == 0) {
          this.draggingPanel = true;
          this.panelDragOffsetX = (int)mx - this.panelX;
          this.panelDragOffsetY = (int)my - this.panelY;
          return true;
        } 

        
        int i = this.panelY + 18;
        if (isHovered((int)mx, (int)my, this.panelX, i, 180, visibleContentHeight)) {
          int contentTopPadding = 10;
          int yOffset = i + contentTopPadding - (int)this.settingsScrollOffset;

          
          if (isHovered((int)mx, (int)my, this.panelX + 10, yOffset, 160, 20)) {
            String buttonText = KeybindManager.getKeyName(this.selectedModule.getKeyBind());
            int buttonWidth = Math.max(60, this.field_22793.method_1727(buttonText) + 10);
            int buttonX = this.panelX + 180 - 30 - buttonWidth;
            if (isHovered((int)mx, (int)my, buttonX, yOffset + 2, buttonWidth, 16)) {
              this.listeningForKeybind = true;
              this.listeningKeybindSetting = null;
              this.keybindModule = this.selectedModule;
              return true;
            } 
          } 
          yOffset += 20;
          
          for (Setting<?> setting : (Iterable<Setting<?>>)this.selectedModule.getSettings()) {
            
            boolean isSettingVisible = (yOffset >= i && yOffset + 20 <= i + visibleContentHeight);
            
            if (isSettingVisible && isHovered((int)mx, (int)my, this.panelX + 10, yOffset, 160, 20) && 
              button == 0) {
              if (setting instanceof BooleanSetting) { BooleanSetting b = (BooleanSetting)setting;
                b.toggle();
                return true; }
               if (setting instanceof SliderSetting) { SliderSetting s = (SliderSetting)setting;
                this.draggingSlider = true;
                this.draggedSlider = s;
                double newPos = Math.max(0.0D, Math.min(1.0D, (mx - (this.panelX + 10)) / 150.0D));
                s.setValueFromSliderPosition(newPos);
                return true; }
               if (setting instanceof NumberSetting) { NumberSetting n = (NumberSetting)setting;
                this.draggingNumber = true;
                this.draggedNumber = n;
                double newPos = Math.max(0.0D, Math.min(1.0D, (mx - (this.panelX + 10)) / 150.0D));
                n.setValue(Double.valueOf(n.getMin() + (n.getMax() - n.getMin()) * newPos));
                return true; }
               if (setting instanceof DoubleSetting) { DoubleSetting d = (DoubleSetting)setting;
                this.draggingDouble = true;
                this.draggedDouble = d;
                double newPos = Math.max(0.0D, Math.min(1.0D, (mx - (this.panelX + 10)) / 150.0D));
                d.setValue(Double.valueOf(d.getMin() + (d.getMax() - d.getMin()) * newPos));
                return true; }
               if (setting instanceof ModeSetting) { ModeSetting<?> modeSetting = (ModeSetting)setting;
                modeSetting.cycleMode();
                return true; }
               if (setting instanceof ColorSetting) { ColorSetting colorSetting = (ColorSetting)setting;
                this.colorPickerPanel.openAt(colorSetting, this.panelX + 180 + 8, yOffset);
                return true; }
               if (setting instanceof StringSetting) { StringSetting s = (StringSetting)setting;
                this.editingString = s;
                this.stringEditor.startEditing((String)s.getValue());
                return true; }
               if (setting instanceof BlockSetting) { BlockSetting blockSetting = (BlockSetting)setting;
                this.blockSelectionPanel.setEditingBlock(blockSetting);
                return true; }
               if (setting instanceof ItemSetting) { ItemSetting itemSetting = (ItemSetting)setting;
                this.editingItem = itemSetting;
                this.itemSearchEditor.setText("");
                this.itemPanelX = (screenWidth - 150) / 2;
                this.itemPanelY = (screenHeight - 180) / 2;
                return true; }
               if (setting instanceof EnchantmentSetting) { EnchantmentSetting enchantmentSetting = (EnchantmentSetting)setting;
                this.enchantmentPanel.setEditingSetting(enchantmentSetting);
                
                return true; }
               if (setting instanceof StringListSetting) { StringListSetting stringListSetting = (StringListSetting)setting;
                this.stringListPanel.setEditingList(stringListSetting);
                return true; }
            
            } 
            
            yOffset += 20;
          } 
        } 
        
        return true;
      } 
      this.selectedModule = null;
    } 

    
    int catY = dashY + 45;
    for (Module.Category cat : Module.Category.values()) {
      if (cat != Module.Category.SEARCH) {
        if (isHovered((int)mx, (int)my, dashX + 5, catY, 90, 20)) {
          this.currentCategory = cat;
          this.moduleSearchEditor.setText("");
          this.selectedModule = null;
          this.moduleScrollOffset = 0.0F;
          return true;
        } 
        catY += 25;
      } 
    } 
    int searchY = dashY + 300 - 35;
    if (isHovered((int)mx, (int)my, dashX + 10, searchY, 80, 20)) {
      this.moduleSearchEditor.startEditing(this.moduleSearchEditor.getText());
      return true;
    } 
    this.moduleSearchEditor.stopEditing();

    
    int contentX = dashX + 100 + 15;
    int contentY = dashY + 15;
    int contentWidth = 320;
    int scrollAreaY = contentY + 25;
    int scrollAreaHeight = 245;
    int moduleY = scrollAreaY - (int)this.moduleScrollOffset;
    List<Module> modules = this.moduleSearchEditor.getText().isEmpty() ? getModules(this.currentCategory) : getSearchModules();
    
    for (Module m : modules) {
      if (isHovered((int)mx, (int)my, contentX, moduleY, contentWidth, 20) && isHovered((int)mx, (int)my, contentX, scrollAreaY, contentWidth, scrollAreaHeight)) {
        if (button == 0) {
          m.toggle();
        } else if (button == 1) {
          this.selectedModule = (this.selectedModule == m) ? null : m;
          if (this.selectedModule != null) {
            this.panelX = dashX + 450 + 10;
            this.panelY = dashY;
            this.panelTargetX = this.panelX;
            this.panelTargetY = this.panelY;
          } 
        } 
        return true;
      } 
      moduleY += 25;
    } 
    
    return super.method_25402(mx, my, button);
  }

  
  public boolean method_25403(double mx, double my, int button, double dx, double dy) {
    mx = scaleInput(mx);
    my = scaleInput(my);
    dx = scaleInput(dx);
    dy = scaleInput(dy);
    if (this.blockSelectionPanel.isOpen() && 
      this.blockSelectionPanel.handleDrag(mx, my, button, dx, dy)) {
      return true;
    }

    
    if (this.enchantmentPanel.isOpen() && 
      this.enchantmentPanel.handleDrag(mx, my, button, dx, dy)) {
      return true;
    }


    
    if (this.colorPickerPanel.isOpen() && 
      this.colorPickerPanel.handleDrag(mx, my, button, dx, dy)) {
      return true;
    }


    
    if (this.stringListPanel.isOpen() && 
      this.stringListPanel.handleDrag(mx, my, button, dx, dy)) {
      return true;
    }

    
    if (this.draggingItemPanel && button == 0) {
      int newX = (int)mx - this.itemPanelDragOffsetX;
      int newY = (int)my - this.itemPanelDragOffsetY;
      
      this.itemPanelX = Math.max(0, Math.min(this.field_22789 - 150, newX));
      this.itemPanelY = Math.max(0, Math.min(this.field_22790 - 180, newY));
      
      this.itemPanelTargetX = this.itemPanelX;
      this.itemPanelTargetY = this.itemPanelY;
      return true;
    } 
    
    if (this.draggingPanel && button == 0) {
      int newX = (int)mx - this.panelDragOffsetX;
      int newY = (int)my - this.panelDragOffsetY;
      
      this.panelX = Math.max(0, Math.min(this.field_22789 - 180, newX));
      this.panelY = Math.max(0, Math.min(this.field_22790 - 18 + Math.min((this.selectedModule.getSettings().size() + 1) * 20 + 10, 200) + 10, newY));
      
      this.panelTargetX = this.panelX;
      this.panelTargetY = this.panelY;
      return true;
    } 


    
    if (this.draggingScrollBar && button == 0 && this.selectedModule != null) {
      int contentTopPadding = 10;
      int totalSettingsHeight = (this.selectedModule.getSettings().size() + 1) * 20 + contentTopPadding;
      int visibleContentHeight = Math.min(totalSettingsHeight, 200);
      int contentY = this.panelY + 18;
      float scrollRatio = (float)(my - contentY) / visibleContentHeight;
      this.settingsScrollOffset = scrollRatio * this.maxScroll;
      this.settingsScrollOffset = Math.max(0.0F, Math.min(this.settingsScrollOffset, this.maxScroll));
      return true;
    } 
    
    if (this.draggingSlider && this.draggedSlider != null) {
      double newPosition = Math.max(0.0D, Math.min(1.0D, (mx - (this.panelX + 10)) / 150.0D));
      this.draggedSlider.setValueFromSliderPosition(newPosition);
      return true;
    } 
    
    if (this.draggingNumber && this.draggedNumber != null) {
      double newPosition = Math.max(0.0D, Math.min(1.0D, (mx - (this.panelX + 10)) / 150.0D));
      double newValue = this.draggedNumber.getMin() + (this.draggedNumber.getMax() - this.draggedNumber.getMin()) * newPosition;
      this.draggedNumber.setValue(Double.valueOf(newValue));
      return true;
    } 
    
    if (this.draggingDouble && this.draggedDouble != null) {
      double newPosition = Math.max(0.0D, Math.min(1.0D, (mx - (this.panelX + 10)) / 150.0D));
      double newValue = this.draggedDouble.getMin() + (this.draggedDouble.getMax() - this.draggedDouble.getMin()) * newPosition;
      newValue = Math.round(newValue * 100.0D) / 100.0D;
      this.draggedDouble.setValue(Double.valueOf(newValue));
      return true;
    } 

    
    return super.method_25403(mx, my, button, dx, dy);
  }

  
  public boolean method_25406(double mx, double my, int button) {
    mx = scaleInput(mx);
    my = scaleInput(my);

    
    if (this.enchantmentPanel.isOpen() && 
      this.enchantmentPanel.handleRelease(mx, my, button)) {
      return true;
    }


    
    if (this.colorPickerPanel.isOpen() && 
      this.colorPickerPanel.handleRelease(mx, my, button)) {
      return true;
    }


    
    if (this.stringListPanel.isOpen() && 
      this.stringListPanel.handleRelease(mx, my, button)) {
      return true;
    }

    
    if (button == 0) {
      if (this.draggingItemPanel) {
        this.itemPanelTargetX = this.itemPanelX;
        this.itemPanelTargetY = this.itemPanelY;
        this.itemPanelDragStartTime = System.currentTimeMillis();
      } 
      
      if (this.draggingPanel) {
        this.panelTargetX = this.panelX;
        this.panelTargetY = this.panelY;
        this.panelDragStartTime = System.currentTimeMillis();
      } 



      
      this.draggingItemPanel = false;
      this.draggingCategory = false;
      this.dragCategory = null;
      this.draggingPanel = false;
      this.draggingSlider = false;
      this.draggedSlider = null;
      this.draggingNumber = false;
      this.draggedNumber = null;
      this.draggingScrollBar = false;
    } 
    return super.method_25406(mx, my, button);
  }

  
  public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
    mouseX = scaleInput(mouseX);
    mouseY = scaleInput(mouseY);
    if (this.blockSelectionPanel.isOpen() && 
      this.blockSelectionPanel.handleScroll(mouseX, mouseY, horizontalAmount, verticalAmount)) {
      return true;
    }

    
    if (this.enchantmentPanel.isOpen() && 
      this.enchantmentPanel.handleScroll(mouseX, mouseY, horizontalAmount, verticalAmount)) {
      return true;
    }

    
    if (this.stringListPanel.isOpen() && 
      this.stringListPanel.handleScroll(mouseX, mouseY, horizontalAmount, verticalAmount)) {
      return true;
    }

    
    int screenWidth = this.client.method_22683().method_4489() / 2;
    int screenHeight = this.client.method_22683().method_4506() / 2;
    int dashX = (screenWidth - 450) / 2;
    int dashY = (screenHeight - 300) / 2;
    
    if (isHovered((int)mouseX, (int)mouseY, dashX + 100, dashY, 350, 300) && 
      this.maxModuleScroll > 0.0F) {
      this.moduleScrollOffset -= ((int)verticalAmount * 20);
      this.moduleScrollOffset = Math.max(0.0F, Math.min(this.moduleScrollOffset, this.maxModuleScroll));
      return true;
    } 

    
    if (!this.moduleSearchEditor.getText().isEmpty()) {
      List<Module> searchModules = getSearchModules();
      int maxVisibleModules = 10;
      int maxScroll = Math.max(0, searchModules.size() - maxVisibleModules);
      if (maxScroll > 0) {
        
        this.moduleScrollOffset -= ((int)verticalAmount * 20);
        this.moduleScrollOffset = Math.max(0.0F, Math.min(this.moduleScrollOffset, this.maxModuleScroll));
        return true;
      } 
    } 
    
    if (this.editingItem != null && 
      isHovered((int)mouseX, (int)mouseY, this.itemPanelX, this.itemPanelY, 150, 180)) {

      
      List<class_1792> allItems = class_7923.field_41178.method_10220().filter(item -> (item != class_1802.field_8162 && item.method_63680().getString().toLowerCase().contains(this.itemSearchEditor.getText().toLowerCase()))).toList();
      
      int itemsHeight = 100;
      int ITEM_SIZE = 20;
      int ITEM_PADDING = 3;
      int ITEMS_PER_ROW = 6;
      
      int totalRows = (int)Math.ceil(allItems.size() / ITEMS_PER_ROW);
      int visibleRows = itemsHeight / (ITEM_SIZE + ITEM_PADDING);
      int maxRowScroll = Math.max(0, totalRows - visibleRows);
      
      if (maxRowScroll > 0) {
        this.itemScrollOffset -= (int)verticalAmount * ITEMS_PER_ROW;
        this.itemScrollOffset = Math.max(0, Math.min(this.itemScrollOffset, maxRowScroll * ITEMS_PER_ROW));
        return true;
      } 
    } 

    
    if (this.selectedModule != null) {
      int contentTopPadding = 10;
      int totalSettingsHeight = (this.selectedModule.getSettings().size() + 1) * 20 + contentTopPadding;
      int visibleContentHeight = Math.min(totalSettingsHeight, 200);
      int contentY = this.panelY + 18;
      if (isHovered((int)mouseX, (int)mouseY, this.panelX, contentY, 180, visibleContentHeight) && 
        this.maxScroll > 0.0F) {
        this.settingsScrollOffset = (float)(this.settingsScrollOffset - verticalAmount * 10.0D);
        this.settingsScrollOffset = Math.max(0.0F, Math.min(this.settingsScrollOffset, this.maxScroll));
        return true;
      } 
    } 
    
    return super.method_25401(mouseX, mouseY, horizontalAmount, verticalAmount);
  }

  
  public boolean method_25404(int keyCode, int scanCode, int modifiers) {
    if (this.blockSelectionPanel.isOpen() && 
      this.blockSelectionPanel.handleKeyPress(keyCode, scanCode, modifiers)) {
      return true;
    }

    
    if (this.enchantmentPanel.isOpen() && 
      this.enchantmentPanel.handleKeyPress(keyCode, scanCode, modifiers)) {
      return true;
    }


    
    if (this.colorPickerPanel.isOpen() && 
      this.colorPickerPanel.handleKeyPress(keyCode, scanCode, modifiers)) {
      return true;
    }


    
    if (this.stringListPanel.isOpen() && 
      this.stringListPanel.handleKeyPress(keyCode, scanCode, modifiers)) {
      return true;
    }

    
    if (this.moduleSearchEditor.isActive() && 
      this.moduleSearchEditor.handleKeyPress(keyCode, scanCode, modifiers)) {
      if (this.moduleSearchEditor.getText().isEmpty()) {
        this.searchScrollOffset = 0;
      }
      return true;
    } 

    
    if (this.itemSearchEditor.isActive() && 
      this.itemSearchEditor.handleKeyPress(keyCode, scanCode, modifiers)) {
      return true;
    }

    
    if (this.editingString != null && this.stringEditor.isActive() && 
      this.stringEditor.handleKeyPress(keyCode, scanCode, modifiers)) {
      if (keyCode == 257) {
        this.editingString.setValue(this.stringEditor.getText());
        this.editingString = null;
        this.stringEditor.stopEditing();
      } else if (keyCode == 256) {
        this.editingString = null;
        this.stringEditor.cancelEditing();
      } 
      return true;
    } 

    
    if (this.listeningForKeybind && this.keybindModule != null) {
      if (keyCode == 256) {
        if (this.listeningKeybindSetting != null) {
          this.listeningKeybindSetting.setValue(Integer.valueOf(-1));
        } else {
          this.keybindModule.setKeyBind(-1);
        }
      
      } else if (this.listeningKeybindSetting != null) {
        this.listeningKeybindSetting.setValue(Integer.valueOf(keyCode));
      } else {
        this.keybindModule.setKeyBind(keyCode);
      } 
      
      this.listeningForKeybind = false;
      this.listeningKeybindSetting = null;
      this.keybindModule = null;
      if (ZCoreClient.getConfigManager() != null) {
        ZCoreClient.getConfigManager().saveKeybinds();
      }
      return true;
    } 
    return super.method_25404(keyCode, scanCode, modifiers);
  }


  
  public boolean method_25400(char chr, int modifiers) {
    if (this.blockSelectionPanel.isOpen() && 
      this.blockSelectionPanel.handleCharType(chr, modifiers)) {
      return true;
    }

    
    if (this.enchantmentPanel.isOpen() && 
      this.enchantmentPanel.handleCharType(chr, modifiers)) {
      return true;
    }


    
    if (this.colorPickerPanel.isOpen() && 
      this.colorPickerPanel.handleCharType(chr, modifiers)) {
      return true;
    }


    
    if (this.stringListPanel.isOpen() && 
      this.stringListPanel.handleCharType(chr, modifiers)) {
      return true;
    }

    
    if (this.moduleSearchEditor.isActive()) {
      if (this.moduleSearchEditor.handleCharType(chr, modifiers)) {
        this.searchScrollOffset = 0;
        return true;
      } 
      return false;
    } 
    
    if (this.itemSearchEditor.isActive()) {
      return this.itemSearchEditor.handleCharType(chr, modifiers);
    }
    
    if (this.editingString != null && this.stringEditor.isActive()) {
      return this.stringEditor.handleCharType(chr, modifiers);
    }
    return super.method_25400(chr, modifiers);
  }

  
  public boolean method_25421() {
    return false;
  }
}


