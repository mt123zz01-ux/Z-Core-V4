package com.zcore.client.gui.panels;

import com.zcore.client.gui.ZCoreGuiTheme;
import com.zcore.client.gui.settings.ColorSetting;
import com.zcore.client.gui.utils.TextEditor;
import com.zcore.client.utils.render.RenderUtils;
import java.awt.Color;
import net.minecraft.class_310;
import net.minecraft.class_332;


public class ColorPickerPanel
{
  private final class_310 client = class_310.method_1551();
  private final int panelWidth = 180;
  private final int panelHeight = 200;
  private final int headerHeight = 25;
  private final int padding = 10;
  private final int hueBarHeight = 100;
  private final int alphaBarHeight = 15;
  private final int hexInputHeight = 22;
  private final int previewSize = 30;
  private final TextEditor hexEditor = new TextEditor();
  private final int colorSquareSize = 100;
  private final int hueBarWidth = 15;
  private ColorSetting editingColor;
  private int panelX = 1000; private int panelY = 600;
  private float hue = 0.0F;
  private float saturation = 1.0F;
  private float brightness = 1.0F;
  private float alpha = 1.0F; private boolean dragging = false;
  private int dragOffsetX;
  private int dragOffsetY;
  private boolean draggingColorDot = false;
  private boolean draggingHueBar = false;
  private boolean draggingAlphaBar = false;
  private boolean editingHex = false;
  private long animationStartTime;
  private boolean isAnimating;
  
  public ColorPickerPanel() {
    this.animationStartTime = System.currentTimeMillis();
    this.isAnimating = true;
  }
  
  public void setEditingColor(ColorSetting color) {
    this.editingColor = color;
    if (color != null) {
      Color c = color.getValue();
      float[] hsb = Color.RGBtoHSB(c.getRed(), c.getGreen(), c.getBlue(), null);
      this.hue = hsb[0];
      this.saturation = hsb[1];
      this.brightness = hsb[2];
      this.alpha = c.getAlpha() / 255.0F;
      updateHexFromColor();
    } else {
      this.editingHex = false;
      this.hexEditor.setText("");
      this.hexEditor.stopEditing();
    } 
  }
  
  public void openAt(ColorSetting color, int x, int y) {
    setEditingColor(color);
    this.animationStartTime = System.currentTimeMillis();
    this.isAnimating = true;
    
    if (this.client != null && this.client.method_22683() != null) {
      int screenW = this.client.method_22683().method_4480();
      int screenH = this.client.method_22683().method_4507();
      
      x = Math.max(5, Math.min(screenW - 180 - 5, x));
      y = Math.max(5, Math.min(screenH - 200 - 5, y));
    } 
    
    this.panelX = x;
    this.panelY = y;
  }
  
  public void render(class_332 context, int mouseX, int mouseY, float progress) {
    if (this.editingColor == null)
      return; 
    float animationProgress = 1.0F;
    if (this.isAnimating) {
      long elapsed = System.currentTimeMillis() - this.animationStartTime;
      animationProgress = easeOutCubic(Math.min(1.0F, (float)elapsed / 300.0F));
      if (animationProgress >= 1.0F) this.isAnimating = false;
    
    } 
    int cornerRadius = getCachedCornerRadius();
    
    int bgColor = ZCoreGuiTheme.applyAlpha(ZCoreGuiTheme.getSettingsPanelColor(), animationProgress * ZCoreGuiTheme.getPanelAlpha());
    RenderUtils.fillRoundRect(context, this.panelX, this.panelY, 180, 200, cornerRadius, bgColor);
    
    int borderColor = ZCoreGuiTheme.applyAlpha(ZCoreGuiTheme.getAccentColor(), animationProgress * 0.5F);
    RenderUtils.drawRoundRect(context, this.panelX, this.panelY, 180, 200, cornerRadius, borderColor);
    
    int headerColor = ZCoreGuiTheme.applyAlpha(ZCoreGuiTheme.getCategoryHeader(), animationProgress * ZCoreGuiTheme.getPanelAlpha());
    RenderUtils.fillRoundTabTop(context, this.panelX, this.panelY, 180, 25, cornerRadius, headerColor);
    
    String title = "Color Picker";
    int titleColor = ZCoreGuiTheme.applyAlpha(-1, (int)(animationProgress * 255.0F)) | 0xFF000000;
    context.method_51433(this.client.field_1772, title, this.panelX + 10, this.panelY + 8, titleColor, true);
    
    String closeText = "✕";
    boolean closeHovered = isHovered(mouseX, mouseY, this.panelX + 180 - 20, this.panelY + 4, 16, 16);
    int closeColor = closeHovered ? ZCoreGuiTheme.getAccentColor() : -3355444;
    context.method_51433(this.client.field_1772, closeText, this.panelX + 180 - 18, this.panelY + 8, 
        ZCoreGuiTheme.applyAlpha(closeColor, (int)(animationProgress * 255.0F)) | 0xFF000000, false);
    
    int contentY = this.panelY + 25 + 10;
    
    int colorSquareX = this.panelX + 10;
    int colorSquareY = contentY;
    
    int hueBarX = colorSquareX + 100 + 10;
    int hueBarY = colorSquareY;
    
    renderColorSquare(context, colorSquareX, colorSquareY, animationProgress);
    renderHueBar(context, hueBarX, hueBarY, animationProgress);
    
    float dotX = colorSquareX + this.saturation * 100.0F;
    float dotY = colorSquareY + (1.0F - this.brightness) * 100.0F;
    renderColorDot(context, (int)dotX, (int)dotY, animationProgress);
    
    float hueY = hueBarY + this.hue * 100.0F;
    renderHueIndicator(context, hueBarX, (int)hueY, animationProgress);
    
    int alphaBarY = colorSquareY + 100 + 10;
    int alphaBarX = colorSquareX;
    int alphaBarWidth = 125;
    
    renderAlphaBar(context, alphaBarX, alphaBarY, alphaBarWidth, animationProgress);
    
    float alphaX = alphaBarX + this.alpha * alphaBarWidth;
    renderAlphaIndicator(context, (int)alphaX, alphaBarY, animationProgress);
    
    int hexY = alphaBarY + 15 + 10;
    int hexX = this.panelX + 10;
    int hexWidth = 125;
    
    renderHexInput(context, hexX, hexY, hexWidth, mouseX, mouseY, animationProgress);
    
    int previewX = hexX + hexWidth + 5;
    int previewY = hexY - 4;
    
    renderColorPreview(context, previewX, previewY, animationProgress);
  }
  
  private void renderColorSquare(class_332 context, int x, int y, float progress) {
    int step = 2; int py;
    for (py = 0; py < 100; py += step) {
      float brightnessValue = 1.0F - py / 100.0F; int px;
      for (px = 0; px < 100; px += step) {
        float saturationValue = px / 100.0F;
        int color = Color.HSBtoRGB(this.hue, saturationValue, brightnessValue);
        context.method_25294(x + px, y + py, x + px + step, y + py + step, 
            ZCoreGuiTheme.applyAlpha(color, progress));
      } 
    } 
    
    RenderUtils.drawRoundRect(context, x, y, 100, 100, 4, 
        ZCoreGuiTheme.applyAlpha(ZCoreGuiTheme.getBorderColor(), progress * 0.6F));
  }
  
  private void renderHueBar(class_332 context, int x, int y, float progress) {
    RenderUtils.fillRoundRect(context, x, y, 15, 100, 4, 
        ZCoreGuiTheme.applyAlpha(-14540254, progress * ZCoreGuiTheme.getPanelAlpha()));
    
    int step = 2; int i;
    for (i = 0; i < 100; i += step) {
      float hueValue = i / 100.0F;
      int color = Color.HSBtoRGB(hueValue, 1.0F, 1.0F);
      context.method_25294(x + 2, y + i, x + 15 - 2, y + i + step, 
          ZCoreGuiTheme.applyAlpha(color, progress));
    } 
    
    RenderUtils.drawRoundRect(context, x, y, 15, 100, 4, 
        ZCoreGuiTheme.applyAlpha(ZCoreGuiTheme.getBorderColor(), progress * 0.6F));
  }
  
  private void renderAlphaBar(class_332 context, int x, int y, int width, float progress) {
    RenderUtils.fillRoundRect(context, x, y, width, 15, 4, 
        ZCoreGuiTheme.applyAlpha(-13421773, progress * ZCoreGuiTheme.getPanelAlpha()));
    
    Color baseColor = new Color(Color.HSBtoRGB(this.hue, this.saturation, this.brightness));
    int step = 2; int i;
    for (i = 0; i < width; i += step) {
      float alphaValue = i / width;
      
      int color = (new Color(baseColor.getRed(), baseColor.getGreen(), baseColor.getBlue(), (int)(alphaValue * 255.0F))).getRGB();
      context.method_25294(x + i, y + 2, x + i + step, y + 15 - 2, color);
    } 
    
    RenderUtils.drawRoundRect(context, x, y, width, 15, 4, 
        ZCoreGuiTheme.applyAlpha(ZCoreGuiTheme.getBorderColor(), progress * 0.6F));
  }
  
  private void renderColorDot(class_332 context, int x, int y, float progress) {
    int colorSquareX = this.panelX + 10;
    int colorSquareY = this.panelY + 25 + 10;
    
    x = Math.max(colorSquareX, Math.min(colorSquareX + 100, x));
    y = Math.max(colorSquareY, Math.min(colorSquareY + 100, y));
    
    int dotSize = 8;
    
    RenderUtils.fillRoundRect(context, x - dotSize / 2 - 2, y - dotSize / 2 - 2, dotSize + 4, dotSize + 4, dotSize / 2 + 2, 
        ZCoreGuiTheme.applyAlpha(-16777216, progress * 0.8F));
    
    RenderUtils.fillRoundRect(context, x - dotSize / 2 - 1, y - dotSize / 2 - 1, dotSize + 2, dotSize + 2, dotSize / 2 + 1, 
        ZCoreGuiTheme.applyAlpha(-1, progress));
    
    int currentColor = getCurrentColorInt();
    RenderUtils.fillRoundRect(context, x - dotSize / 2, y - dotSize / 2, dotSize, dotSize, dotSize / 2, currentColor);
  }
  
  private void renderHueIndicator(class_332 context, int x, int y, float progress) {
    int lineWidth = 21;
    int lineHeight = 4;
    int lineX = x - 3;
    int lineY = y - 2;
    
    RenderUtils.fillRoundRect(context, lineX - 1, lineY - 1, lineWidth + 2, lineHeight + 2, 3, 
        ZCoreGuiTheme.applyAlpha(-16777216, progress * 0.8F));
    
    RenderUtils.fillRoundRect(context, lineX, lineY, lineWidth, lineHeight, 2, 
        ZCoreGuiTheme.applyAlpha(-1, progress));
    
    int hueColor = Color.HSBtoRGB(this.hue, 1.0F, 1.0F);
    RenderUtils.fillRoundRect(context, lineX + 1, lineY + 1, lineWidth - 2, lineHeight - 2, 2, 
        ZCoreGuiTheme.applyAlpha(hueColor, progress));
  }
  
  private void renderAlphaIndicator(class_332 context, int x, int y, float progress) {
    int lineWidth = 4;
    int lineHeight = 21;
    int lineX = x - 2;
    int lineY = y - 3;
    
    RenderUtils.fillRoundRect(context, lineX - 1, lineY - 1, lineWidth + 2, lineHeight + 2, 3, 
        ZCoreGuiTheme.applyAlpha(-16777216, progress * 0.8F));
    
    RenderUtils.fillRoundRect(context, lineX, lineY, lineWidth, lineHeight, 2, 
        ZCoreGuiTheme.applyAlpha(-1, progress));
    
    int currentColor = getCurrentColorInt();
    RenderUtils.fillRoundRect(context, lineX + 1, lineY + 1, lineWidth - 2, lineHeight - 2, 2, 
        ZCoreGuiTheme.applyAlpha(currentColor, progress));
  }
  private void renderHexInput(class_332 context, int x, int y, int width, int mouseX, int mouseY, float progress) {
    String displayText;
    boolean hovered = isHovered(mouseX, mouseY, x, y, width, 22);

    
    int bgColor = (this.editingHex || hovered) ? ZCoreGuiTheme.applyAlpha(ZCoreGuiTheme.getHoverColor(), progress * 0.5F) : ZCoreGuiTheme.applyAlpha(-13421773, progress * ZCoreGuiTheme.getPanelAlpha());
    
    RenderUtils.fillRoundRect(context, x, y, width, 22, 6, bgColor);
    
    String hexText = this.hexEditor.getText();
    
    if (this.editingHex && this.hexEditor.isActive()) {
      int cursorPos = this.hexEditor.getCursorPosition();
      String beforeCursor = hexText.substring(0, Math.min(cursorPos, hexText.length()));
      String afterCursor = hexText.substring(Math.min(cursorPos, hexText.length()));
      displayText = "#" + beforeCursor + "_" + afterCursor;
    } else if (hexText.isEmpty()) {
      displayText = "#" + getHexFromColor();
    } else {
      displayText = "#" + hexText;
    } 
    
    int textColor = ZCoreGuiTheme.applyAlpha(-1, (int)(progress * 255.0F)) | 0xFF000000;
    context.method_51433(this.client.field_1772, displayText, x + 6, y + 7, textColor, false);
    
    RenderUtils.drawRoundRect(context, x, y, width, 22, 6, 
        ZCoreGuiTheme.applyAlpha(ZCoreGuiTheme.getBorderColor(), progress * 0.6F));
  }
  
  private void renderColorPreview(class_332 context, int x, int y, float progress) {
    RenderUtils.fillRoundRect(context, x, y, 30, 30, 6, 
        ZCoreGuiTheme.applyAlpha(-13421773, progress * ZCoreGuiTheme.getPanelAlpha()));
    
    int currentColor = getCurrentColorInt();
    RenderUtils.fillRoundRect(context, x, y, 30, 30, 6, currentColor);
    
    RenderUtils.drawRoundRect(context, x, y, 30, 30, 6, 
        ZCoreGuiTheme.applyAlpha(ZCoreGuiTheme.getBorderColor(), progress * 0.6F));
  }
  
  private int getCurrentColorInt() {
    Color color = new Color(Color.HSBtoRGB(this.hue, this.saturation, this.brightness));
    int alphaInt = (int)(this.alpha * 255.0F);
    return alphaInt << 24 | color.getRed() << 16 | color.getGreen() << 8 | color.getBlue();
  }
  
  private String getHexFromColor() {
    Color color = new Color(Color.HSBtoRGB(this.hue, this.saturation, this.brightness));
    int alphaInt = (int)(this.alpha * 255.0F);
    return String.format("%02X%02X%02X%02X", new Object[] { Integer.valueOf(alphaInt), Integer.valueOf(color.getRed()), Integer.valueOf(color.getGreen()), Integer.valueOf(color.getBlue()) });
  }
  
  private void updateHexFromColor() {
    this.hexEditor.setText(getHexFromColor());
  }
  
  private void updateColorFromHex() {
    try {
      String hex = this.hexEditor.getText().replace("#", "").trim();
      
      if (hex.length() == 8) {
        int a = Integer.parseInt(hex.substring(0, 2), 16);
        int r = Integer.parseInt(hex.substring(2, 4), 16);
        int g = Integer.parseInt(hex.substring(4, 6), 16);
        int b = Integer.parseInt(hex.substring(6, 8), 16);
        
        float[] hsb = Color.RGBtoHSB(r, g, b, null);
        this.hue = hsb[0];
        this.saturation = hsb[1];
        this.brightness = hsb[2];
        this.alpha = a / 255.0F;
        
        if (this.editingColor != null) {
          this.editingColor.setValue(new Color(r, g, b, a));
        }
      } else if (hex.length() == 6) {
        int r = Integer.parseInt(hex.substring(0, 2), 16);
        int g = Integer.parseInt(hex.substring(2, 4), 16);
        int b = Integer.parseInt(hex.substring(4, 6), 16);
        
        float[] hsb = Color.RGBtoHSB(r, g, b, null);
        this.hue = hsb[0];
        this.saturation = hsb[1];
        this.brightness = hsb[2];
        this.alpha = 1.0F;
        
        if (this.editingColor != null) {
          this.editingColor.setValue(new Color(r, g, b, 255));
        }
      } 
    } catch (NumberFormatException numberFormatException) {}
  }

  
  public boolean handleClick(double mx, double my, int button) {
    if (this.editingColor == null) return false;
    
    if (isHovered(mx, my, this.panelX + 180 - 20, this.panelY + 4, 16, 16)) {
      this.editingColor = null;
      this.draggingColorDot = false;
      this.draggingHueBar = false;
      this.draggingAlphaBar = false;
      this.editingHex = false;
      return true;
    } 
    
    if (button == 0 && isHovered(mx, my, this.panelX, this.panelY, 180, 25) && 
      !isHovered(mx, my, this.panelX + 180 - 20, this.panelY + 4, 16, 16)) {
      this.dragging = true;
      this.dragOffsetX = (int)mx - this.panelX;
      this.dragOffsetY = (int)my - this.panelY;
      return true;
    } 

    
    int colorSquareX = this.panelX + 10;
    int colorSquareY = this.panelY + 25 + 10;
    
    if (button == 0 && isHovered(mx, my, colorSquareX, colorSquareY, 100, 100)) {
      this.draggingColorDot = true;
      updateColorFromPosition((int)mx, (int)my);
      return true;
    } 
    
    int hueBarX = colorSquareX + 100 + 10;
    int hueBarY = colorSquareY;
    
    if (button == 0 && isHovered(mx, my, hueBarX, hueBarY, 15, 100)) {
      this.draggingHueBar = true;
      updateHueFromPosition((int)my);
      return true;
    } 
    
    int alphaBarY = colorSquareY + 100 + 10;
    int alphaBarX = colorSquareX;
    int alphaBarWidth = 125;
    
    if (button == 0 && isHovered(mx, my, alphaBarX, alphaBarY, alphaBarWidth, 15)) {
      this.draggingAlphaBar = true;
      updateAlphaFromPosition((int)mx, alphaBarWidth);
      return true;
    } 
    
    int hexY = alphaBarY + 15 + 10;
    int hexX = this.panelX + 10;
    int hexWidth = 125;
    
    if (button == 0 && isHovered(mx, my, hexX, hexY, hexWidth, 22)) {
      this.editingHex = true;
      this.hexEditor.startEditing(getHexFromColor());
      return true;
    }  if (!isHovered(mx, my, hexX, hexY, hexWidth, 22)) {
      this.editingHex = false;
      this.hexEditor.stopEditing();
      updateColorFromHex();
    } 
    
    return isHovered(mx, my, this.panelX, this.panelY, 180, 200);
  }
  
  public boolean handleDrag(double mx, double my, int button, double dx, double dy) {
    if (this.editingColor == null) return false;
    
    if (this.dragging && button == 0) {
      this.panelX = (int)mx - this.dragOffsetX;
      this.panelY = (int)my - this.dragOffsetY;
      
      if (this.client != null && this.client.method_22683() != null) {
        this.panelX = Math.max(0, Math.min(this.client.method_22683().method_4480() - 180, this.panelX));
        this.panelY = Math.max(0, Math.min(this.client.method_22683().method_4507() - 200, this.panelY));
      } 
      return true;
    } 
    
    if (button == 0) {
      if (this.draggingColorDot) {
        updateColorFromPosition((int)mx, (int)my);
        return true;
      } 
      
      if (this.draggingHueBar) {
        updateHueFromPosition((int)my);
        return true;
      } 
      
      if (this.draggingAlphaBar) {
        int alphaBarWidth = 125;
        updateAlphaFromPosition((int)mx, alphaBarWidth);
        return true;
      } 
    } 
    
    return false;
  }
  
  public boolean handleRelease(double mx, double my, int button) {
    if (this.editingColor == null) return false;
    
    if (button == 0) {
      this.dragging = false;
      this.draggingColorDot = false;
      this.draggingHueBar = false;
      this.draggingAlphaBar = false;
    } 
    return false;
  }
  
  private void updateColorFromPosition(int mx, int my) {
    int colorSquareX = this.panelX + 10;
    int colorSquareY = this.panelY + 25 + 10;
    
    float newSaturation = Math.max(0.0F, Math.min(1.0F, (mx - colorSquareX) / 100.0F));
    float newBrightness = Math.max(0.0F, Math.min(1.0F, 1.0F - (my - colorSquareY) / 100.0F));
    
    this.saturation = newSaturation;
    this.brightness = newBrightness;
    
    updateColorValue();
    updateHexFromColor();
  }
  
  private void updateHueFromPosition(int my) {
    int hueBarY = this.panelY + 25 + 10;
    this.hue = Math.max(0.0F, Math.min(1.0F, (my - hueBarY) / 100.0F));
    updateColorValue();
    updateHexFromColor();
  }
  
  private void updateAlphaFromPosition(int mx, int alphaBarWidth) {
    int alphaBarX = this.panelX + 10;
    this.alpha = Math.max(0.0F, Math.min(1.0F, (mx - alphaBarX) / alphaBarWidth));
    updateColorValue();
    updateHexFromColor();
  }
  
  private void updateColorValue() {
    if (this.editingColor != null) {
      Color color = new Color(Color.HSBtoRGB(this.hue, this.saturation, this.brightness));
      int alphaInt = (int)(this.alpha * 255.0F);
      this.editingColor.setValue(new Color(color.getRed(), color.getGreen(), color.getBlue(), alphaInt));
    } 
  }
  
  public boolean handleKeyPress(int keyCode, int scanCode, int modifiers) {
    if (this.editingColor == null) return false;
    
    if (this.editingHex && this.hexEditor.isActive()) {
      if (keyCode == 256) {
        this.editingHex = false;
        this.hexEditor.cancelEditing();
        updateHexFromColor();
        return true;
      } 
      if (keyCode == 257) {
        this.editingHex = false;
        this.hexEditor.stopEditing();
        updateColorFromHex();
        return true;
      } 
      if (this.hexEditor.handleKeyPress(keyCode, scanCode, modifiers)) {
        updateColorFromHex();
        return true;
      } 
    } 
    
    return false;
  }
  
  public boolean handleCharType(char chr, int modifiers) {
    if (this.editingColor == null || !this.editingHex || !this.hexEditor.isActive()) return false;
    
    char upperChr = Character.toUpperCase(chr);
    if ((upperChr >= '0' && upperChr <= '9') || (upperChr >= 'A' && upperChr <= 'F')) {
      String currentText = this.hexEditor.getText();
      if (currentText.length() < 8 && 
        this.hexEditor.handleCharType(upperChr, modifiers)) {
        updateColorFromHex();
        return true;
      } 
    } 

    
    return false;
  }
  
  public boolean isOpen() {
    return (this.editingColor != null);
  }
  
  private boolean isHovered(double mx, double my, int x, int y, int w, int h) {
    return (mx >= x && mx <= (x + w) && my >= y && my <= (y + h));
  }
  
  private float easeOutCubic(float t) {
    return 1.0F - (float)Math.pow((1.0F - t), 3.0D);
  }
  
  private int getCachedCornerRadius() {
    return 12;
  }
  
  public boolean handleScroll(double mx, double my, double horizontalAmount, double verticalAmount) {
    if (this.editingColor == null) return false;
    
    int colorSquareX = this.panelX + 10;
    int colorSquareY = this.panelY + 25 + 10;
    int alphaBarY = colorSquareY + 100 + 10;
    int alphaBarX = colorSquareX;
    int alphaBarWidth = 125;
    
    if (isHovered(mx, my, this.panelX, this.panelY, 180, 200)) {
      if (isHovered(mx, my, alphaBarX, alphaBarY, alphaBarWidth, 15)) {
        this.alpha = (float)(this.alpha - verticalAmount * 0.05000000074505806D);
        this.alpha = Math.max(0.0F, Math.min(1.0F, this.alpha));
        updateColorValue();
        updateHexFromColor();
        return true;
      }  if (isHovered(mx, my, colorSquareX, colorSquareY, 100, 100)) {
        float newSaturation = Math.max(0.0F, Math.min(1.0F, this.saturation + (float)-verticalAmount * 0.05F));
        float newBrightness = Math.max(0.0F, Math.min(1.0F, this.brightness + (float)verticalAmount * 0.05F));
        this.saturation = newSaturation;
        this.brightness = newBrightness;
        updateColorValue();
        updateHexFromColor();
        return true;
      }  if (isHovered(mx, my, colorSquareX + 100 + 10, colorSquareY, 15, 100)) {
        this.hue = (float)(this.hue + verticalAmount * 0.019999999552965164D);
        this.hue = Math.max(0.0F, Math.min(1.0F, this.hue));
        updateColorValue();
        updateHexFromColor();
        return true;
      } 
    } 
    
    return false;
  }
}


