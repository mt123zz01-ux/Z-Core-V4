package com.zcore.client.gui;
import com.zcore.client.client.ZCoreClient;
import com.zcore.client.gui.settings.BooleanSetting;
import com.zcore.client.gui.settings.DoubleSetting;
import com.zcore.client.gui.settings.ModeSetting;
import com.zcore.client.gui.settings.NumberSetting;
import com.zcore.client.gui.settings.Setting;
import com.zcore.client.gui.settings.SliderSetting;
import com.zcore.client.modules.Module;
import com.zcore.client.modules.client.ClickGUI;
import com.zcore.client.utils.render.RenderUtils;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;

public class LegacyClickGuiScreen extends class_437 {
  private final class_310 client = class_310.method_1551();
  private final int categoryWidth = 110;
  private final int headerHeight = 18;
  private final int moduleHeight = 16;
  private final Map<Module.Category, Integer> categoryX = new HashMap<>();
  private final Map<Module.Category, Integer> categoryY = new HashMap<>();
  private final Map<Module.Category, Boolean> categoryExpanded = new HashMap<>();
  
  private Module.Category draggingCategory = null;
  private int dragOffsetX;
  private int dragOffsetY;
  private Module selectedModule = null; private int panelX;
  private int panelY;
  private boolean draggingPanel = false;
  private int panelDragOffsetX;
  private int panelDragOffsetY;
  private boolean draggingSlider = false;
  private SliderSetting draggedSlider = null;
  private boolean draggingNumber = false;
  private NumberSetting draggedNumber = null;
  private boolean draggingDouble = false;
  private DoubleSetting draggedDouble = null;
  
  public LegacyClickGuiScreen() {
    super((class_2561)class_2561.method_43470("Legacy ClickGUI"));
    int x = 20;
    for (Module.Category cat : Module.Category.values()) {
      if (cat != Module.Category.SEARCH) {
        this.categoryX.put(cat, Integer.valueOf(x));
        this.categoryY.put(cat, Integer.valueOf(20));
        this.categoryExpanded.put(cat, Boolean.valueOf(true));
        x += 120;
      } 
    } 
  }
  
  public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
    ClickGUI clickGUI = (ClickGUI)ZCoreClient.getModuleManager().getModule(ClickGUI.class);
    if (clickGUI != null && ((Boolean)clickGUI.blur.getValue()).booleanValue()) {
      BlurManager.render(1.0F);
    }
    method_25420(context, mouseX, mouseY, delta);
    
    for (Module.Category cat : Module.Category.values()) {
      if (cat != Module.Category.SEARCH) {
        renderCategory(context, cat, mouseX, mouseY);
      }
    } 
    if (this.selectedModule != null) {
      renderSettings(context, mouseX, mouseY);
    }
  }
  
  private void renderCategory(class_332 context, Module.Category cat, int mouseX, int mouseY) {
    int x = ((Integer)this.categoryX.get(cat)).intValue();
    int y = ((Integer)this.categoryY.get(cat)).intValue();
    boolean expanded = ((Boolean)this.categoryExpanded.get(cat)).booleanValue();
    
    List<Module> modules = getModules(cat);
    int height = 18 + (expanded ? (modules.size() * 16) : 0);
    
    int accentColor = ZCoreGuiTheme.getAccentColor();

    
    RenderUtils.fillRoundRect(context, x, y, 110, 18, 4, 4, 0, 0, ZCoreGuiTheme.getCategoryHeader());
    context.method_51433(this.field_22793, cat.getName(), x + (110 - this.field_22793.method_1727(cat.getName())) / 2, y + 5, -1, false);
    
    if (expanded) {
      int currentY = y + 18;
      for (int i = 0; i < modules.size(); i++) {
        Module m = modules.get(i);
        boolean isLast = (i == modules.size() - 1);
        boolean hovered = (mouseX >= x && mouseX <= x + 110 && mouseY >= currentY && mouseY <= currentY + 16);
        
        int bgColor = m.isEnabled() ? ZCoreGuiTheme.applyAlpha(accentColor, 0.4F) : -2013265920;
        if (hovered) bgColor = ZCoreGuiTheme.blendColors(bgColor, 16777215, 0.1F);
        
        if (isLast) {
          RenderUtils.fillRoundRect(context, x, currentY, 110, 16, 0, 0, 4, 4, bgColor);
        } else {
          context.method_25294(x, currentY, x + 110, currentY + 16, bgColor);
        } 
        
        context.method_51433(this.field_22793, m.getName(), x + 5, currentY + 4, -1, false);
        currentY += 16;
      } 
    } 
  }

  
  private void renderSettings(class_332 context, int mouseX, int mouseY) {
    int width = 150;
    int height = (this.selectedModule.getSettings().size() + 1) * 18 + 10;
    
    RenderUtils.fillRoundRect(context, this.panelX, this.panelY, width, height, 6, -586084079);
    RenderUtils.drawRoundRect(context, this.panelX, this.panelY, width, height, 6, ZCoreGuiTheme.getAccentColor());
    
    context.method_51433(this.field_22793, this.selectedModule.getName() + " Settings", this.panelX + 8, this.panelY + 6, -1, false);
    
    int currentY = this.panelY + 22;
    for (Setting<?> setting : (Iterable<Setting<?>>)this.selectedModule.getSettings()) {
      boolean hovered = (mouseX >= this.panelX + 5 && mouseX <= this.panelX + width - 5 && mouseY >= currentY && mouseY <= currentY + 16);
      int textColor = hovered ? -1 : -3355444;
      
      context.method_51433(this.field_22793, setting.getName(), this.panelX + 10, currentY + 4, textColor, false);
      
      if (setting instanceof BooleanSetting) { BooleanSetting b = (BooleanSetting)setting;
        int boxSize = 10;
        int boxX = this.panelX + width - 20;
        int boxY = currentY + 3;
        RenderUtils.fillRoundRect(context, boxX, boxY, boxSize, boxSize, 2, ((Boolean)b.getValue()).booleanValue() ? ZCoreGuiTheme.getAccentColor() : -13421773); }
      else if (setting instanceof SliderSetting) { SliderSetting s = (SliderSetting)setting;
        int barWidth = 60;
        int barX = this.panelX + width - 70;
        int barY = currentY + 7;
        context.method_25294(barX, barY, barX + barWidth, barY + 2, -13421773);
        int progressWidth = (int)(s.getSliderPosition() * barWidth);
        context.method_25294(barX, barY, barX + progressWidth, barY + 2, ZCoreGuiTheme.getAccentColor()); }
      else if (setting instanceof NumberSetting) { NumberSetting n = (NumberSetting)setting;
        int barWidth = 60;
        int barX = this.panelX + width - 70;
        int barY = currentY + 7;
        context.method_25294(barX, barY, barX + barWidth, barY + 2, -13421773);
        double ratio = (((Double)n.getValue()).doubleValue() - n.getMin()) / (n.getMax() - n.getMin());
        int progressWidth = (int)(ratio * barWidth);
        context.method_25294(barX, barY, barX + progressWidth, barY + 2, ZCoreGuiTheme.getAccentColor()); }
      else if (setting instanceof ModeSetting) { ModeSetting<?> mode = (ModeSetting)setting;
        String modeName = ((Enum)mode.getValue()).name();
        context.method_51433(this.field_22793, modeName, this.panelX + width - this.field_22793.method_1727(modeName) - 10, currentY + 4, ZCoreGuiTheme.getAccentColor(), false); }

      
      currentY += 18;
    } 
  }
  
  private List<Module> getModules(Module.Category cat) {
    return ZCoreClient.moduleManager.getModules().stream()
      .filter(m -> (m.getCategory() == cat))
      .toList();
  }

  
  public boolean method_25402(double mouseX, double mouseY, int button) {
    for (Module.Category cat : Module.Category.values()) {
      if (cat != Module.Category.SEARCH) {
        int x = ((Integer)this.categoryX.get(cat)).intValue();
        int y = ((Integer)this.categoryY.get(cat)).intValue();
        
        if (mouseX >= x && mouseX <= (x + 110) && mouseY >= y && mouseY <= (y + 18)) {
          if (button == 0) {
            this.draggingCategory = cat;
            this.dragOffsetX = (int)mouseX - x;
            this.dragOffsetY = (int)mouseY - y;
          } else if (button == 1) {
            this.categoryExpanded.put(cat, Boolean.valueOf(!((Boolean)this.categoryExpanded.get(cat)).booleanValue()));
          } 
          return true;
        } 
        
        if (((Boolean)this.categoryExpanded.get(cat)).booleanValue()) {
          int currentY = y + 18;
          for (Module m : getModules(cat)) {
            if (mouseX >= x && mouseX <= (x + 110) && mouseY >= currentY && mouseY <= (currentY + 16)) {
              if (button == 0) {
                m.toggle();
              } else if (button == 1) {
                this.selectedModule = (this.selectedModule == m) ? null : m;
                if (this.selectedModule != null) {
                  this.panelX = this.field_22789 - 160;
                  this.panelY = 20;
                } 
              } 
              return true;
            } 
            currentY += 16;
          } 
        } 
      } 
    } 
    if (this.selectedModule != null) {
      int pWidth = 150;
      int pHeight = (this.selectedModule.getSettings().size() + 1) * 18 + 10;
      if (mouseX >= this.panelX && mouseX <= (this.panelX + pWidth) && mouseY >= this.panelY && mouseY <= (this.panelY + pHeight)) {
        
        if (mouseY <= (this.panelY + 18) && 
          button == 0) {
          this.draggingPanel = true;
          this.panelDragOffsetX = (int)mouseX - this.panelX;
          this.panelDragOffsetY = (int)mouseY - this.panelY;
          return true;
        } 


        
        int sY = this.panelY + 22;
        for (Setting<?> setting : (Iterable<Setting<?>>)this.selectedModule.getSettings()) {
          if (mouseY >= sY && mouseY <= (sY + 16)) {
            if (setting instanceof BooleanSetting) { BooleanSetting b = (BooleanSetting)setting;
              b.toggle(); }
            else if (setting instanceof SliderSetting) { SliderSetting s = (SliderSetting)setting;
              this.draggingSlider = true;
              this.draggedSlider = s; }
            else if (setting instanceof NumberSetting) { NumberSetting n = (NumberSetting)setting;
              this.draggingNumber = true;
              this.draggedNumber = n; }
            else if (setting instanceof DoubleSetting) { DoubleSetting d = (DoubleSetting)setting;
              this.draggingDouble = true;
              this.draggedDouble = d; }
            else if (setting instanceof ModeSetting) { ModeSetting<?> mode = (ModeSetting)setting;
              mode.cycleMode(); }
            
            return true;
          } 
          sY += 18;
        } 
        return true;
      } 
    } 
    return super.method_25402(mouseX, mouseY, button);
  }

  
  public boolean method_25406(double mouseX, double mouseY, int button) {
    this.draggingCategory = null;
    this.draggingPanel = false;
    this.draggingSlider = false;
    this.draggingNumber = false;
    this.draggingDouble = false;
    return super.method_25406(mouseX, mouseY, button);
  }

  
  public boolean method_25403(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
    if (this.draggingCategory != null) {
      this.categoryX.put(this.draggingCategory, Integer.valueOf((int)mouseX - this.dragOffsetX));
      this.categoryY.put(this.draggingCategory, Integer.valueOf((int)mouseY - this.dragOffsetY));
      return true;
    } 
    if (this.draggingPanel) {
      this.panelX = (int)mouseX - this.panelDragOffsetX;
      this.panelY = (int)mouseY - this.panelDragOffsetY;
      return true;
    } 
    
    if (this.draggingSlider && this.draggedSlider != null) {
      int barWidth = 60;
      int barX = this.panelX + 150 - 70;
      double pos = Math.max(0.0D, Math.min(1.0D, (mouseX - barX) / barWidth));
      this.draggedSlider.setValueFromSliderPosition(pos);
      return true;
    } 
    
    if (this.draggingNumber && this.draggedNumber != null) {
      int barWidth = 60;
      int barX = this.panelX + 150 - 70;
      double pos = Math.max(0.0D, Math.min(1.0D, (mouseX - barX) / barWidth));
      double val = this.draggedNumber.getMin() + (this.draggedNumber.getMax() - this.draggedNumber.getMin()) * pos;
      this.draggedNumber.setValue(Double.valueOf(val));
      return true;
    } 
    
    if (this.draggingDouble && this.draggedDouble != null) {
      int barWidth = 60;
      int barX = this.panelX + 150 - 70;
      double pos = Math.max(0.0D, Math.min(1.0D, (mouseX - barX) / barWidth));
      double val = this.draggedDouble.getMin() + (this.draggedDouble.getMax() - this.draggedDouble.getMin()) * pos;
      this.draggedDouble.setValue(Double.valueOf(val));
      return true;
    } 
    return super.method_25403(mouseX, mouseY, button, deltaX, deltaY);
  }

  
  public boolean method_25421() {
    return false;
  }
}


