package com.zcore.client.gui.settings;

import com.zcore.client.client.KeybindManager;

public class KeybindSetting
  extends Setting<Integer>
{
  private boolean listening = false;
  
  public KeybindSetting(String name, int defaultKey) {
    super(name, Integer.valueOf(defaultKey));
  }
  
  public boolean isListening() {
    return this.listening;
  }
  
  public void setListening(boolean listening) {
    this.listening = listening;
  }
  
  public String getDisplayText() {
    if (this.listening) {
      return "Press a key...";
    }
    return KeybindManager.getKeyName(getValue().intValue());
  }
  
  public void setKey(int keyCode) {
    setValue(Integer.valueOf(keyCode));
    setListening(false);
  }
  
  public void clearKey() {
    setValue(Integer.valueOf(-1));
    setListening(false);
  }
}


