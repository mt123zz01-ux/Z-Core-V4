package com.zcore.client.gui;

import com.zcore.client.client.ZCoreClient;
import com.zcore.client.modules.client.ClickGUI;
import com.zcore.client.themes.Theme;
import com.zcore.client.themes.ThemeManager;


public class ZCoreGuiTheme
{
  public static final long ANIMATION_DURATION = 300L;
  public static final float HOVER_ALPHA = 0.75F;
  
  public static float getPanelAlpha() {
    ClickGUI clickGUI = (ZCoreClient.moduleManager != null) ? (ClickGUI)ZCoreClient.moduleManager.getModule(ClickGUI.class) : null;
    if (clickGUI != null && clickGUI.guiOpacity != null) {
      return ((Double)clickGUI.guiOpacity.getValue()).floatValue() / 100.0F;
    }
    return 0.35F;
  }
  
  private static Theme getCurrentTheme() {
    return ThemeManager.getClickGuiTheme();
  }
  
  public static int applyAlpha(int color, float alpha) {
    if (alpha > 1.0F) {
      alpha /= 255.0F;
    }
    int a = (int)(alpha * 255.0F);
    return a << 24 | color & 0xFFFFFF;
  }
  
  public static int blendColors(int color1, int color2, float ratio) {
    int r1 = color1 >> 16 & 0xFF;
    int g1 = color1 >> 8 & 0xFF;
    int b1 = color1 & 0xFF;
    
    int r2 = color2 >> 16 & 0xFF;
    int g2 = color2 >> 8 & 0xFF;
    int b2 = color2 & 0xFF;
    
    int r = (int)(r1 * (1.0F - ratio) + r2 * ratio);
    int g = (int)(g1 * (1.0F - ratio) + g2 * ratio);
    int b = (int)(b1 * (1.0F - ratio) + b2 * ratio);
    
    return 0xFF000000 | r << 16 | g << 8 | b;
  }
  
  public static int getBackground() {
    return getCurrentTheme().getGuiBackground();
  }
  
  public static int getCategoryBackground() {
    return getCurrentTheme().getGuiCategoryBackground();
  }
  
  public static int getCategoryHeader() {
    return getCurrentTheme().getGuiCategoryHeader();
  }
  
  public static int getModuleBackground() {
    return getCurrentTheme().getGuiModuleBackground();
  }
  
  public static int getSettingsBackground() {
    return getCurrentTheme().getGuiSettingsBackground();
  }
  
  public static int getHoverColor() {
    return getCurrentTheme().getGuiHoverColor();
  }
  
  public static int getBorderColor() {
    return getCurrentTheme().getGuiBorderColor();
  }
  
  public static int getSeparatorColor() {
    return getCurrentTheme().getGuiSeparatorColor();
  }
  
  public static int getAccentColor() {
    Theme theme = getCurrentTheme();
    int themeAccent = theme.getGuiAccentColor();
    
    if (themeAccent == -6596122) {
      if (ZCoreClient.moduleManager == null) return themeAccent; 
      ClickGUI colorsModule = (ClickGUI)ZCoreClient.moduleManager.getModule(ClickGUI.class);
      if (colorsModule != null) {
        return colorsModule.getHudColor(0.0D);
      }
    } 
    return themeAccent;
  }
  
  public static int getAccentColorDark() {
    return blendColors(getAccentColor(), -16777216, 0.2F);
  }
  
  public static int getAccentColorLight() {
    return blendColors(getAccentColor(), -1, 0.2F);
  }
  
  public static int getEnabledColor() {
    return getAccentColor();
  }
  
  public static int getTextColor() {
    return getCurrentTheme().getGuiTextColor();
  }
  
  public static int getEnabledTextColor() {
    return getCurrentTheme().getGuiEnabledTextColor();
  }
  
  public static int getDisabledTextColor() {
    return getCurrentTheme().getGuiDisabledTextColor();
  }
  
  public static int getAccentTextColor() {
    return getAccentColor();
  }
  
  public static int getHoverAccent() {
    return blendColors(getAccentColor(), getHoverColor(), 0.6F);
  }
  
  public static int getActiveModuleBackground() {
    return blendColors(getModuleBackground(), getAccentColor(), 0.1F);
  }
  
  public static int getFocusedBorder() {
    return getAccentColor();
  }
  
  public static int getTransitionColor(int from, int to, float progress) {
    return blendColors(from, to, progress);
  }
  
  public static int getDisabledModuleColor() {
    return getModuleBackground();
  }
  
  public static int getModuleTextColor(boolean enabled) {
    Theme theme = getCurrentTheme();
    return enabled ? theme.getGuiEnabledTextColor() : theme.getGuiDisabledTextColor();
  }
  
  public static int getSettingsPanelColor() {
    return getCurrentTheme().getGuiCategoryBackground();
  }
}


