package com.zcore.client.gui.settings;

public class StringSetting
  extends Setting<String> {
  public StringSetting(String name, String defaultValue) {
    super(name, defaultValue);
  }
}


