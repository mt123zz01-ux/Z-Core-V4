package com.zcore.client.gui.settings;

import java.awt.Color;

public class ColorSetting extends Setting<Color> {
    public ColorSetting(String name, Color defaultValue) { super(name, defaultValue); }
    public Color getColor() { return getValue(); }
    public int getRGB() { return getValue().getRGB(); }
}
