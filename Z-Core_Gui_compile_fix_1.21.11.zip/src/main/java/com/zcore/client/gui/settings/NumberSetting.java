package com.zcore.client.gui.settings;

public class NumberSetting extends Setting<Integer> {
    private final int min, max, increment;
    public NumberSetting(String name, Integer defaultValue) { this(name, defaultValue, 0, 100, 1); }
    public NumberSetting(String name, int defaultValue, int min, int max, int increment) {
        super(name, defaultValue);
        this.min = min; this.max = max; this.increment = increment;
    }
    public int getMin() { return min; }
    public int getMax() { return max; }
    public int getIncrement() { return increment; }
}
