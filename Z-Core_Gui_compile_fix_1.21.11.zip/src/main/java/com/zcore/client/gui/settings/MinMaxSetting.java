package com.zcore.client.gui.settings;

public class MinMaxSetting extends Setting<double[]> {
    public MinMaxSetting(String name, double minDefault, double maxDefault) { super(name, new double[]{minDefault, maxDefault}); }
    public double getMinValue() { return getValue()[0]; }
    public double getMaxValue() { return getValue()[1]; }
}
