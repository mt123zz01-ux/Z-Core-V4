package com.zcore.client.gui.utils;

import com.zcore.client.gui.settings.StringSetting;
import net.minecraft.class_310;
import net.minecraft.class_437;


public class StringEditor
{
  private final class_310 client = class_310.method_1551();
  private StringSetting editingString = null;
  private String currentString = "";
  private int cursorPosition = 0;
  private int selectionStart = -1;
  private int selectionEnd = -1;
  
  public void startEditing(StringSetting setting) {
    this.editingString = setting;
    this.currentString = (String)setting.getValue();
    this.cursorPosition = this.currentString.length();
    this.selectionStart = -1;
    this.selectionEnd = -1;
  }
  
  public void stopEditing() {
    if (this.editingString != null) {
      this.editingString.setValue(this.currentString);
      this.editingString = null;
      this.currentString = "";
      this.cursorPosition = 0;
      this.selectionStart = -1;
      this.selectionEnd = -1;
    } 
  }
  
  public void cancelEditing() {
    this.editingString = null;
    this.currentString = "";
    this.cursorPosition = 0;
    this.selectionStart = -1;
    this.selectionEnd = -1;
  }
  
  private boolean hasSelection() {
    return (this.selectionStart != -1 && this.selectionEnd != -1 && this.selectionStart != this.selectionEnd);
  }
  
  private int getSelectionStartPos() {
    if (!hasSelection()) return this.cursorPosition; 
    return Math.min(this.selectionStart, this.selectionEnd);
  }
  
  private int getSelectionEndPos() {
    if (!hasSelection()) return this.cursorPosition; 
    return Math.max(this.selectionStart, this.selectionEnd);
  }
  
  private String getSelectedText() {
    if (!hasSelection()) return ""; 
    int start = getSelectionStartPos();
    int end = getSelectionEndPos();
    return this.currentString.substring(start, end);
  }
  
  private void deleteSelection() {
    if (!hasSelection())
      return;  int start = getSelectionStartPos();
    int end = getSelectionEndPos();
    this.currentString = this.currentString.substring(0, start) + this.currentString.substring(0, start);
    this.cursorPosition = start;
    this.selectionStart = -1;
    this.selectionEnd = -1;
  }
  
  private void insertText(String text) {
    if (hasSelection()) {
      deleteSelection();
    }
    this.currentString = this.currentString.substring(0, this.cursorPosition) + this.currentString.substring(0, this.cursorPosition) + text;
    this.cursorPosition += text.length();
  }
  
  private void moveCursor(int direction, boolean extendSelection) {
    if (extendSelection) {
      if (this.selectionStart == -1) {
        this.selectionStart = this.cursorPosition;
      }
      this.selectionEnd = this.cursorPosition;
    } else {
      this.selectionStart = -1;
      this.selectionEnd = -1;
    } 
    this.cursorPosition = Math.max(0, Math.min(this.currentString.length(), this.cursorPosition + direction));
    if (extendSelection) {
      this.selectionEnd = this.cursorPosition;
    }
  }
  
  public boolean handleKeyPress(int keyCode, int scanCode, int modifiers) {
    if (this.editingString == null) {
      return false;
    }
    
    boolean ctrlPressed = ((modifiers & 0x2) != 0);
    boolean shiftPressed = ((modifiers & 0x1) != 0);

    
    if (ctrlPressed && keyCode == 65) {
      this.selectionStart = 0;
      this.selectionEnd = this.currentString.length();
      this.cursorPosition = this.currentString.length();
      return true;
    } 

    
    if (ctrlPressed && keyCode == 67) {
      if (hasSelection()) {
        String selected = getSelectedText();
        this.client.field_1774.method_1455(selected);
      } 
      return true;
    } 

    
    if (ctrlPressed && keyCode == 88) {
      if (hasSelection()) {
        String selected = getSelectedText();
        this.client.field_1774.method_1455(selected);
        deleteSelection();
      } 
      return true;
    } 

    
    if (class_437.method_25437(keyCode)) {
      String clipboardContent = this.client.field_1774.method_1460();
      if (clipboardContent != null) {
        insertText(clipboardContent);
      }
      return true;
    } 
    
    switch (keyCode) {
      case 256:
        cancelEditing();
        return true;
      case 257:
        stopEditing();
        return true;
      case 259:
        if (hasSelection()) {
          deleteSelection();
        } else if (this.cursorPosition > 0) {
          this.currentString = this.currentString.substring(0, this.cursorPosition - 1) + this.currentString.substring(0, this.cursorPosition - 1);
          this.cursorPosition--;
        } 
        return true;
      case 261:
        if (hasSelection()) {
          deleteSelection();
        } else if (this.cursorPosition < this.currentString.length()) {
          this.currentString = this.currentString.substring(0, this.cursorPosition) + this.currentString.substring(0, this.cursorPosition);
        } 
        return true;
      case 263:
        moveCursor(-1, shiftPressed);
        return true;
      case 262:
        moveCursor(1, shiftPressed);
        return true;
      case 268:
        if (shiftPressed) {
          if (this.selectionStart == -1) {
            this.selectionStart = this.cursorPosition;
          }
          this.selectionEnd = 0;
        } else {
          this.selectionStart = -1;
          this.selectionEnd = -1;
        } 
        this.cursorPosition = 0;
        return true;
      case 269:
        if (shiftPressed) {
          if (this.selectionStart == -1) {
            this.selectionStart = this.cursorPosition;
          }
          this.selectionEnd = this.currentString.length();
        } else {
          this.selectionStart = -1;
          this.selectionEnd = -1;
        } 
        this.cursorPosition = this.currentString.length();
        return true;
    } 
    
    return false;
  }
  
  public boolean handleCharType(char chr, int modifiers) {
    if (this.editingString == null) {
      return false;
    }

    
    if (chr >= ' ' && chr != '') {
      insertText(String.valueOf(chr));
      return true;
    } 
    
    return false;
  }
  
  public boolean isEditing() {
    return (this.editingString != null);
  }
  
  public boolean isEditing(StringSetting setting) {
    return (this.editingString == setting);
  }
  
  public String getCurrentText() {
    return this.currentString;
  }
  
  public StringSetting getEditingSetting() {
    return this.editingString;
  }
  
  public int getCursorPosition() {
    return this.cursorPosition;
  }
  
  public int getSelectionStart() {
    return this.selectionStart;
  }
  
  public int getSelectionEnd() {
    return this.selectionEnd;
  }
  
  public boolean hasSelectionPublic() {
    return hasSelection();
  }
}


