package com.zcore.client.gui.utils;

import com.zcore.client.gui.settings.NumberSetting;
import com.zcore.client.gui.settings.SliderSetting;

public class InteractionHandler
{
  private boolean draggingSlider = false;
  private SliderSetting draggedSlider = null;
  private boolean draggingNumber = false;
  private NumberSetting draggedNumber = null;

  
  public boolean handleSliderDrag(SliderSetting setting, double mouseX, double mouseY, int x, int y, int width, int height) {
    if (this.draggingSlider && this.draggedSlider == setting && 
      GuiUtils.isHovered(mouseX, mouseY, x, y, width, height)) {
      double newPosition = Math.max(0.0D, Math.min(1.0D, (mouseX - x) / width));
      setting.setValueFromSliderPosition(newPosition);
      return true;
    } 
    
    return false;
  }

  
  public boolean handleNumberDrag(NumberSetting setting, double mouseX, double mouseY, int x, int y, int width, int height) {
    if (this.draggingNumber && this.draggedNumber == setting && 
      GuiUtils.isHovered(mouseX, mouseY, x, y, width, height)) {
      double newPosition = Math.max(0.0D, Math.min(1.0D, (mouseX - x) / width));
      double newValue = setting.getMin() + (setting.getMax() - setting.getMin()) * newPosition;
      setting.setValue(Double.valueOf(newValue));
      return true;
    } 
    
    return false;
  }
  
  public void startSliderDrag(SliderSetting setting) {
    this.draggingSlider = true;
    this.draggedSlider = setting;
  }
  
  public void startNumberDrag(NumberSetting setting) {
    this.draggingNumber = true;
    this.draggedNumber = setting;
  }
  
  public void stopDragging() {
    this.draggingSlider = false;
    this.draggedSlider = null;
    this.draggingNumber = false;
    this.draggedNumber = null;
  }
  
  public boolean isDraggingSlider() {
    return this.draggingSlider;
  }
  
  public boolean isDraggingNumber() {
    return this.draggingNumber;
  }
  
  public boolean isDragging() {
    return (this.draggingSlider || this.draggingNumber);
  }
}


