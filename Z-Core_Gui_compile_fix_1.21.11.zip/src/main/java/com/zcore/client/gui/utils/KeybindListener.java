package com.zcore.client.gui.utils;

import com.zcore.client.client.ZCoreClient;
import com.zcore.client.modules.Module;


public class KeybindListener
{
  private boolean listeningForKeybind = false;
  private Module keybindModule = null;
  
  public void startListening(Module module) {
    this.listeningForKeybind = true;
    this.keybindModule = module;
  }
  
  public void stopListening() {
    this.listeningForKeybind = false;
    this.keybindModule = null;
  }
  
  public boolean handleKeyPress(int keyCode, int scanCode, int modifiers) {
    if (!this.listeningForKeybind || this.keybindModule == null) {
      return false;
    }
    
    if (keyCode == 256) {
      this.keybindModule.setKeyBind(-1);
    } else {
      this.keybindModule.setKeyBind(keyCode);
    } 
    
    stopListening();

    
    if (ZCoreClient.getConfigManager() != null) {
      ZCoreClient.getConfigManager().saveKeybinds();
    }
    
    return true;
  }
  
  public boolean isListening() {
    return this.listeningForKeybind;
  }
  
  public Module getListeningModule() {
    return this.keybindModule;
  }
  
  public boolean isListeningFor(Module module) {
    return (this.listeningForKeybind && this.keybindModule == module);
  }
}


