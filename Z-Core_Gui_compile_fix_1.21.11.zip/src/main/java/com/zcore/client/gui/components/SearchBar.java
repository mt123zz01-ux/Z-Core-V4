package com.zcore.client.gui.components;

import com.zcore.client.gui.ZCoreGuiTheme;
import com.zcore.client.gui.utils.GuiUtils;
import com.zcore.client.gui.utils.TextEditor;
import net.minecraft.class_310;
import net.minecraft.class_332;

public class SearchBar
{
  private final TextEditor editor = new TextEditor();
  private final class_310 client = class_310.method_1551();
  private int lastWidth = 180;
  
  public void render(class_332 context, int x, int y, int width, float animationProgress) {
    int height = 20;



    
    int bgColor = this.editor.isActive() ? ZCoreGuiTheme.applyAlpha(ZCoreGuiTheme.getHoverColor(), animationProgress * 0.75F) : ZCoreGuiTheme.applyAlpha(ZCoreGuiTheme.getModuleBackground(), animationProgress * 
        ZCoreGuiTheme.getPanelAlpha());
    
    GuiUtils.drawRoundedRect(context, x, y, width, height, 5, bgColor);
    
    String text = this.editor.getText();
    String displayText = text;
    if (this.editor.isActive()) {
      
      int cursorPos = this.editor.getCursorPosition();
      String beforeCursor = text.substring(0, cursorPos);
      String afterCursor = text.substring(cursorPos);
      displayText = beforeCursor + "_" + beforeCursor;
    } else if (text.isEmpty()) {
      displayText = "Search for an item...";
    } 
    
    int textColor = ZCoreGuiTheme.applyAlpha(ZCoreGuiTheme.getTextColor(), (int)(animationProgress * 255.0F)) | 0xFF000000;
    
    context.method_51433(this.client.field_1772, displayText, x + 5, y + 6, textColor, false);
  }
  
  public void setWidth(int width) {
    this.lastWidth = width;
  }
  
  public boolean handleClick(double mx, double my, int button, int x, int y) {
    if (button == 0 && GuiUtils.isHovered(mx, my, x, y, this.lastWidth, 20)) {
      if (!this.editor.isActive()) {
        this.editor.startEditing(this.editor.getText());
      }
      return true;
    } 
    
    if (this.editor.isActive() && !GuiUtils.isHovered(mx, my, x, y, this.lastWidth, 20)) {
      this.editor.stopEditing();
    }
    
    return false;
  }
  
  public boolean handleKeyPress(int keyCode, int scanCode, int modifiers) {
    return this.editor.handleKeyPress(keyCode, scanCode, modifiers);
  }
  
  public boolean handleCharType(char chr, int modifiers) {
    return this.editor.handleCharType(chr, modifiers);
  }
  
  public String getQuery() {
    return this.editor.getText();
  }
  
  public void clear() {
    this.editor.setText("");
    this.editor.stopEditing();
  }
  
  public boolean isEditing() {
    return this.editor.isActive();
  }
}


