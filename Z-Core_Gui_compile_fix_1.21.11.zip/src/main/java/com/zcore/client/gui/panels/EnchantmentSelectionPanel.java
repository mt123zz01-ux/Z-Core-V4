package com.zcore.client.gui.panels;
import com.zcore.client.gui.ZCoreGuiTheme;
import com.zcore.client.gui.settings.EnchantmentSetting;
import com.zcore.client.gui.utils.DragHandler;
import com.zcore.client.gui.utils.GuiUtils;
import com.zcore.client.utils.render.RenderUtils;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.class_1887;
import net.minecraft.class_2378;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_5321;
import net.minecraft.class_5455;

public class EnchantmentSelectionPanel {
  private static final int HEADER_HEIGHT = 18;
  private static final int SEARCH_HEIGHT = 25;
  private static final List<String> AMETHYST_ENCHANTS = Arrays.asList(new String[] { "Amethyst Pickaxe", "Amethyst Axe", "Amethyst Sell Axe", "Amethyst Shovel" });




  
  private static final List<String> ALL_ENCHANTS = Arrays.asList(new String[] { "Mending", "Unbreaking", "Curse of Vanishing", "Aqua Affinity", "Blast Protection", "Curse of Binding", "Depth Strider", "Feather Falling", "Fire Protection", "Frost Walker", "Projectile Protection", "Protection", "Respiration", "Soul Speed", "Thorns", "Swift Sneak", "Bane of Arthropods", "Breach", "Density", "Efficiency", "Fire Aspect", "Looting", "Lunge", "Impaling", "Knockback", "Sharpness", "Smite", "Sweeping Edge", "Wind Burst", "Channeling", "Flame", "Infinity", "Loyalty", "Riptide", "Multishot", "Piercing", "Power", "Punch", "Quick Charge", "Fortune", "Luck of the Sea", "Lure", "Silk Touch" });
















  
  private final SearchBar searchBar;















  
  private final DragHandler dragHandler;















  
  private final class_310 client = class_310.method_1551();
  private final int panelWidth = 200;
  private final int panelHeight = 250;
  private final int itemHeight = 16;
  private final Set<String> selectedAmethystEnchants = new HashSet<>();
  private final Set<String> selectedCustomEnchants = new HashSet<>();
  private EnchantmentSetting editingSetting;
  private int panelX = 100, panelY = 100;
  private int scrollOffset = 0;
  
  public EnchantmentSelectionPanel() {
    this.searchBar = new SearchBar();
    this.dragHandler = new DragHandler();
  }
  
  public EnchantmentSetting getEditingSetting() {
    return this.editingSetting;
  }
  
  public void setEditingSetting(EnchantmentSetting setting) {
    this.editingSetting = setting;
    if (setting != null) {
      this.searchBar.clear();
      this.scrollOffset = 0;
      this.selectedAmethystEnchants.clear();
      this.selectedAmethystEnchants.addAll(setting.getAmethystEnchants());

      
      int screenWidth = this.client.method_22683().method_4489() / 2;
      int screenHeight = this.client.method_22683().method_4506() / 2;
      setPosition((screenWidth - 200) / 2, (screenHeight - 250) / 2);
    } 
  }
  
  public void setPosition(int x, int y) {
    this.panelX = x;
    this.panelY = y;
    this.dragHandler.setPosition(x, y);
  }

  
  public boolean isOpen() {
    return (this.editingSetting != null);
  }
  
  public void render(class_332 context, int mouseX, int mouseY, float progress) {
    if (this.editingSetting == null)
      return; 
    int[] pos = this.dragHandler.getAnimatedPosition();
    this.panelX = pos[0];
    this.panelY = pos[1];
    boolean isDragging = this.dragHandler.isDragging();

    
    int cornerRadius = 12;

    
    int borderColor = ZCoreGuiTheme.applyAlpha(ZCoreGuiTheme.getBorderColor(), progress * 0.4F);
    if (isDragging) {
      borderColor = ZCoreGuiTheme.applyAlpha(ZCoreGuiTheme.getAccentColor(), progress * 0.6F);
    }
    RenderUtils.drawRoundRect(context, this.panelX, this.panelY, 200, 250, cornerRadius, borderColor);

    
    int headerColor = ZCoreGuiTheme.applyAlpha(ZCoreGuiTheme.getCategoryHeader(), progress * 0.3F);
    GuiUtils.drawRoundedRect(context, this.panelX, this.panelY, 200, 18, cornerRadius, headerColor);

    
    int titleColor = ZCoreGuiTheme.applyAlpha(ZCoreGuiTheme.getTextColor(), (int)(progress * 255.0F)) | 0xFF000000;
    context.method_51433(this.client.field_1772, "Select Enchantments", this.panelX + 8, this.panelY + 6, titleColor, false);

    
    int closeX = this.panelX + 200 - 15;
    int closeY = this.panelY + 6;
    boolean closeHovered = GuiUtils.isHovered(mouseX, mouseY, closeX - 2, closeY - 2, 12, 12);

    
    int closeColor = closeHovered ? (ZCoreGuiTheme.applyAlpha(ZCoreGuiTheme.getAccentColor(), (int)(progress * 255.0F)) | 0xFF000000) : (ZCoreGuiTheme.applyAlpha(-1, (int)(progress * 255.0F)) | 0xFF000000);
    context.method_51433(this.client.field_1772, "X", closeX, closeY, closeColor, false);

    
    int searchY = this.panelY + 18 + 5;
    int searchHeight = 20;
    int searchWidth = 180;
    int searchX = this.panelX + 10;

    
    boolean searchActive = this.searchBar.isEditing();

    
    int searchBgColor = searchActive ? ZCoreGuiTheme.applyAlpha(ZCoreGuiTheme.getHoverColor(), progress * 0.15F) : ZCoreGuiTheme.applyAlpha(0, 0.0F);
    GuiUtils.drawRoundedRect(context, searchX, searchY, searchWidth, searchHeight, 5, searchBgColor);

    
    if (searchActive) {
      int searchBorderColor = ZCoreGuiTheme.applyAlpha(ZCoreGuiTheme.getAccentColor(), progress * 0.4F);
      RenderUtils.drawRoundRect(context, searchX, searchY, searchWidth, searchHeight, 5, searchBorderColor);
    } 

    
    String searchText = this.searchBar.getQuery();
    String displayText = searchText;
    if (searchActive) {
      
      displayText = searchText.isEmpty() ? "Search enchantments..." : searchText;
    } else {
      displayText = searchText.isEmpty() ? "Search enchantments..." : searchText;
    } 
    int textColor = ZCoreGuiTheme.applyAlpha(-1, (int)(progress * 255.0F)) | 0xFF000000;
    context.method_51433(this.client.field_1772, displayText, searchX + 5, searchY + 6, textColor, false);

    
    int listStartY = this.panelY + 18 + 25 + 8;
    int listHeight = 194;
    
    context.method_44379(this.panelX + 5, listStartY, this.panelX + 200 - 5, listStartY + listHeight);
    
    List<EnchantmentEntry> entries = getFilteredEntries();
    int visible = listHeight / 16;
    int maxScroll = Math.max(0, entries.size() - visible);
    this.scrollOffset = Math.max(0, Math.min(this.scrollOffset, maxScroll));
    
    for (int i = 0; i < visible && i + this.scrollOffset < entries.size(); i++) {
      EnchantmentEntry entry = entries.get(i + this.scrollOffset);
      int itemY = listStartY + 2 + i * 16;
      renderEnchantmentEntry(context, entry, this.panelX + 8, itemY, 175, 16, mouseX, mouseY, progress);
    } 
    
    context.method_44380();

    
    if (maxScroll > 0) {
      renderScrollbar(context, listStartY, listHeight, this.scrollOffset, maxScroll, visible, entries.size(), mouseX, mouseY, progress);
    }
  }


  
  private void renderEnchantmentEntry(class_332 context, EnchantmentEntry entry, int x, int y, int width, int height, int mouseX, int mouseY, float progress) {
    boolean hovered = GuiUtils.isHovered(mouseX, mouseY, x, y, width, height);
    boolean selected = isSelected(entry);

    
    if (selected || hovered) {

      
      int bgColor = selected ? ZCoreGuiTheme.applyAlpha(ZCoreGuiTheme.getAccentColor(), progress * 0.4F) : ZCoreGuiTheme.applyAlpha(ZCoreGuiTheme.getHoverColor(), progress * 0.3F);
      GuiUtils.drawRoundedRect(context, x - 2, y - 2, width + 4, height + 4, 4, bgColor);
    } 

    
    if (selected) {
      int itemBorderColor = ZCoreGuiTheme.applyAlpha(ZCoreGuiTheme.getAccentColor(), progress * 0.9F);
      RenderUtils.drawRoundRect(context, x - 2, y - 2, width + 4, height + 4, 4, itemBorderColor);
    } 

    
    int textColor = -1;
    String name = entry.isAmethyst ? ("§d" + entry.name) : entry.name;
    
    if (this.client.field_1772.method_1727(name) > width - 10) {
      name = this.client.field_1772.method_27523(name, width - 15) + "...";
    }
    
    context.method_51433(this.client.field_1772, name, x + 3, y + 4, textColor, true);
  }


  
  private void renderScrollbar(class_332 context, int listStartY, int listHeight, int scrollOffset, int maxScroll, int visible, int total, int mouseX, int mouseY, float progress) {
    int scrollBarX = this.panelX + 200 - 12;
    int scrollBarY = listStartY + 5;
    int scrollBarHeight = listHeight - 10;
    int scrollBarWidth = 5;
    
    float scrollProgress = (maxScroll > 0) ? (scrollOffset / maxScroll) : 0.0F;
    int handleHeight = Math.max(20, (int)(visible / total * scrollBarHeight));
    int handleY = scrollBarY + (int)((scrollBarHeight - handleHeight) * scrollProgress);
    
    boolean scrollHovered = GuiUtils.isHovered(mouseX, mouseY, scrollBarX, handleY, scrollBarWidth, handleHeight);

    
    int handleColor = scrollHovered ? ZCoreGuiTheme.applyAlpha(ZCoreGuiTheme.getAccentColor(), progress * 0.8F) : ZCoreGuiTheme.applyAlpha(ZCoreGuiTheme.getAccentColor(), progress * 0.5F);
    
    GuiUtils.drawRoundedRect(context, scrollBarX, handleY, scrollBarWidth, handleHeight, 3, handleColor);
  }
  
  public boolean handleClick(double mx, double my, int button) {
    if (this.editingSetting == null) return false;

    
    int closeX = this.panelX + 200 - 15;
    int closeY = this.panelY + 6;
    int closeSize = 12;
    if (GuiUtils.isHovered(mx, my, closeX, closeY, closeSize, closeSize)) {
      this.editingSetting = null;
      return true;
    } 

    
    if (button == 0 && GuiUtils.isHovered(mx, my, this.panelX, this.panelY, 200, 18) && 
      !GuiUtils.isHovered(mx, my, closeX, closeY, closeSize, closeSize)) {
      this.dragHandler.startDrag(mx, my, this.panelX, this.panelY);
      return true;
    } 


    
    int searchY = this.panelY + 18 + 5;
    if (this.searchBar.handleClick(mx, my, button, this.panelX + 10, searchY)) {
      return true;
    }

    
    int listStartY = this.panelY + 18 + 25 + 8;
    int listHeight = 194;
    
    if (GuiUtils.isHovered(mx, my, this.panelX + 5, listStartY, 190, listHeight)) {
      int clickedIndex = ((int)my - listStartY + 2) / 16;
      List<EnchantmentEntry> entries = getFilteredEntries();
      if (clickedIndex >= 0 && clickedIndex + this.scrollOffset < entries.size()) {
        toggleSelection(entries.get(clickedIndex + this.scrollOffset));
        return true;
      } 
    } 
    
    return GuiUtils.isHovered(mx, my, this.panelX, this.panelY, 200, 250);
  }
  
  public boolean handleDrag(double mx, double my, int button, double dx, double dy) {
    if (this.editingSetting == null) return false; 
    if (this.dragHandler.isDragging()) {
      this.dragHandler.updatePosition(mx, my);
      return true;
    } 
    return false;
  }
  
  public boolean handleRelease(double mx, double my, int button) {
    if (this.editingSetting == null) return false; 
    if (button == 0) this.dragHandler.stopDrag(); 
    return false;
  }
  
  public boolean handleScroll(double mx, double my, double h, double v) {
    if (this.editingSetting == null) return false; 
    int listStartY = this.panelY + 18 + 25 + 8;
    int listHeight = 194;
    if (GuiUtils.isHovered(mx, my, this.panelX + 5, listStartY, 190, listHeight)) {
      this.scrollOffset -= (int)v * 2;
      this.scrollOffset = Math.max(0, Math.min(this.scrollOffset, Math.max(0, getFilteredEntries().size() - listHeight / 16)));
      return true;
    } 
    return false;
  }
  
  public boolean handleKeyPress(int keyCode, int scanCode, int modifiers) {
    if (this.editingSetting == null) return false; 
    return this.searchBar.handleKeyPress(keyCode, scanCode, modifiers);
  }
  
  public boolean handleCharType(char chr, int modifiers) {
    if (this.editingSetting == null) return false; 
    return this.searchBar.handleCharType(chr, modifiers);
  }
  
  private boolean isSelected(EnchantmentEntry entry) {
    if (entry.isAmethyst) return this.selectedAmethystEnchants.contains(entry.name); 
    if (entry.enchantmentKey == null) return this.selectedCustomEnchants.contains(entry.name); 
    return this.editingSetting.getEnchantments().contains(entry.enchantmentKey);
  }
  
  private void toggleSelection(EnchantmentEntry entry) {
    if (entry.isAmethyst) {
      if (this.selectedAmethystEnchants.contains(entry.name)) {
        this.editingSetting.removeAmethystEnchant(entry.name);
        this.selectedAmethystEnchants.remove(entry.name);
      } else {
        this.editingSetting.addAmethystEnchant(entry.name);
        this.selectedAmethystEnchants.add(entry.name);
      } 
    } else if (entry.enchantmentKey == null) {
      
      if (this.selectedCustomEnchants.contains(entry.name)) {
        this.selectedCustomEnchants.remove(entry.name);
      } else {
        this.selectedCustomEnchants.add(entry.name);
      } 
      
      this.editingSetting.setMetadata("selectedCustomEnchants", new ArrayList<>(this.selectedCustomEnchants));
    
    }
    else if (this.editingSetting.getEnchantments().contains(entry.enchantmentKey)) {
      this.editingSetting.removeEnchantment(entry.enchantmentKey);
    } else {
      this.editingSetting.addEnchantment(entry.enchantmentKey);
    } 
  }
  
  private List<EnchantmentEntry> getFilteredEntries() {
    List<EnchantmentEntry> entries = new ArrayList<>();
    String query = this.searchBar.getQuery().toLowerCase();
    
    class_2378<class_1887> reg = null;

    
    if (this.client.field_1687 != null) {
      try {
        class_5455 drm = this.client.field_1687.method_30349();
        reg = drm.method_30530(class_7924.field_41265);
      } catch (Exception exception) {}
    }



    
    if (reg == null) {
      for (String enchant : ALL_ENCHANTS) {
        if (enchant.toLowerCase().contains(query))
          entries.add(new EnchantmentEntry(enchant, null, false)); 
      } 
      for (String a : AMETHYST_ENCHANTS) {
        if (a.toLowerCase().contains(query))
          entries.add(new EnchantmentEntry(a, null, true)); 
      }  entries.sort(Comparator.comparing(entry -> entry.name));
      return entries;
    } 

    
    Set<String> registryEnchantNames = new HashSet<>();
    for (class_5321<class_1887> key : (Iterable<class_5321<class_1887>>)reg.method_42021()) {
      String name = getEnchantmentName(key);
      registryEnchantNames.add(name.toLowerCase());
      if (name.toLowerCase().contains(query)) {
        entries.add(new EnchantmentEntry(name, key, false));
      }
    } 
    
    for (String enchant : ALL_ENCHANTS) {
      if (!registryEnchantNames.contains(enchant.toLowerCase()) && enchant.toLowerCase().contains(query)) {
        entries.add(new EnchantmentEntry(enchant, null, false));
      }
    } 

    
    for (String a : AMETHYST_ENCHANTS) {
      if (a.toLowerCase().contains(query))
        entries.add(new EnchantmentEntry(a, null, true)); 
    } 
    entries.sort(Comparator.comparing(entry -> entry.name));
    return entries;
  }
  
  private String getEnchantmentName(class_5321<class_1887> key) {
    String id = key.method_29177().method_12832();
    return Arrays.<String>stream(id.split("_"))
      .map(s -> "" + Character.toUpperCase(s.charAt(0)) + Character.toUpperCase(s.charAt(0)))
      .collect(Collectors.joining(" "));
  }
  private record EnchantmentEntry(String name, class_5321<class_1887> enchantmentKey, boolean isAmethyst) {}
}
