package com.zcore.client.gui.utils;





























































class Animation
{
  private final float from;
  private final float to;
  private final long duration;
  private final long startTime;
  private boolean finished = false;
  
  public Animation(float from, float to, long duration, long startTime) {
    this.from = from;
    this.to = to;
    this.duration = duration;
    this.startTime = startTime;
  }
  
  public void update(long currentTime) {
    long elapsed = currentTime - this.startTime;
    if (elapsed >= this.duration) {
      this.finished = true;
    }
  }
  
  public float getValue() {
    if (this.finished) return this.to;
    
    long elapsed = System.currentTimeMillis() - this.startTime;
    float progress = Math.min(1.0F, (float)elapsed / (float)this.duration);
    progress = easeOutCubic(progress);
    
    return this.from + (this.to - this.from) * progress;
  }
  
  public boolean isFinished() {
    return this.finished;
  }
  
  private float easeOutCubic(float t) {
    return 1.0F - (float)Math.pow((1.0F - t), 3.0D);
  }
}


