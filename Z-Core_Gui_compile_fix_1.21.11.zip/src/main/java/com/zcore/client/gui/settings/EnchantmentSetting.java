package com.zcore.client.gui.settings;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.class_1887;
import net.minecraft.class_5321;

public class EnchantmentSetting extends Setting<List<class_5321<class_1887>>> {
  private final Set<String> amethystEnchants = new HashSet<>();

  
  private final Map<String, Object> metadata = new HashMap<>();
  
  public EnchantmentSetting(String name) {
    super(name, new ArrayList<>());
  }
  
  public List<class_5321<class_1887>> getEnchantments() {
    return getValue();
  }
  
  public boolean isEmpty() {
    return (getValue().isEmpty() && this.amethystEnchants.isEmpty());
  }
  
  public void addEnchantment(class_5321<class_1887> enchantment) {
    if (!getValue().contains(enchantment)) getValue().add(enchantment); 
  }
  
  public void removeEnchantment(class_5321<class_1887> enchantment) {
    getValue().remove(enchantment);
  }
  
  public void clear() {
    getValue().clear();
    this.amethystEnchants.clear();
  }

  
  public void addAmethystEnchant(String enchantName) {
    this.amethystEnchants.add(enchantName);
    saveAmethystMetadata();
  }
  
  public void removeAmethystEnchant(String enchantName) {
    this.amethystEnchants.remove(enchantName);
    saveAmethystMetadata();
  }
  
  public boolean hasAmethystEnchant(String enchantName) {
    return this.amethystEnchants.contains(enchantName);
  }
  
  public Set<String> getAmethystEnchants() {
    return new HashSet<>(this.amethystEnchants);
  }

  
  public boolean hasAmethystPickaxe() {
    return this.amethystEnchants.contains("Amethyst Pickaxe");
  }
  
  public boolean hasAmethystAxe() {
    return this.amethystEnchants.contains("Amethyst Axe");
  }
  
  public boolean hasAmethystSellAxe() {
    return this.amethystEnchants.contains("Amethyst Sell Axe");
  }
  
  public boolean hasAmethystShovel() {
    return this.amethystEnchants.contains("Amethyst Shovel");
  }

  
  public int getTotalCount() {
    return getValue().size() + this.amethystEnchants.size();
  }

  
  public void setMetadata(String key, Object value) {
    this.metadata.put(key, value);
  }


  
  public <T> T getMetadata(String key) {
    return (T)this.metadata.get(key);
  }


  
  public List<String> getMetadataList(String key) {
    Object obj = this.metadata.get(key);
    if (obj instanceof List) { List<?> list = (List)obj;
      List<String> result = new ArrayList<>();
      for (Object o : list) {
        if (o instanceof String) result.add((String)o); 
      } 
      return result; }
    
    return new ArrayList<>();
  }

  
  public void loadAmethystFromMetadata() {
    List<String> saved = getMetadataList("selectedAmethystEnchants");
    this.amethystEnchants.clear();
    this.amethystEnchants.addAll(saved);
  }

  
  private void saveAmethystMetadata() {
    setMetadata("selectedAmethystEnchants", new ArrayList<>(this.amethystEnchants));
  }
}


