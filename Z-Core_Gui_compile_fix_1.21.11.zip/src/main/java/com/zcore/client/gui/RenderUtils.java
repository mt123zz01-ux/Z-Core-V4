package com.zcore.client.gui;
import com.mojang.blaze3d.systems.RenderSystem;
import com.zcore.client.client.ZCoreClient;
import java.awt.Color;
import net.minecraft.class_10142;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import org.joml.Matrix4f;

public final class RenderUtils {
  public static class_4184 getCamera() {
    return (ZCoreClient.mc.method_31975()).field_4344;
  }
  
  public static class_243 getCameraPos() {
    return (class_310.method_1551()).field_1773.method_19418().method_19326();
  }
  
  public static void renderLine(class_4587 matrixStack, Color color, class_243 start, class_243 end) {
    Matrix4f m = matrixStack.method_23760().method_23761();
    float r = color.getRed() / 255.0F;
    float g = color.getGreen() / 255.0F;
    float b = color.getBlue() / 255.0F;
    float a = color.getAlpha() / 255.0F;
    RenderSystem.enableBlend();
    RenderSystem.defaultBlendFunc();
    RenderSystem.disableDepthTest();
    RenderSystem.depthMask(false);
    class_287 buf = class_289.method_1348().method_60827(class_293.class_5596.field_29344, class_290.field_1576);
    buf.method_22918(m, (float)start.field_1352, (float)start.field_1351, (float)start.field_1350).method_22915(r, g, b, a);
    buf.method_22918(m, (float)end.field_1352, (float)end.field_1351, (float)end.field_1350).method_22915(r, g, b, a);
    RenderSystem.setShader(class_10142.field_53876);
    class_286.method_43433(buf.method_60800());
    RenderSystem.depthMask(true);
    RenderSystem.enableDepthTest();
    RenderSystem.disableBlend();
  }

  
  public static void renderRoundedQuad(class_4587 matrices, Color color, int x1, int y1, int x2, int y2, int z, int radius) {
    RenderSystem.setShader(class_10142.field_53876);
    RenderSystem.setShaderColor(color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F, color.getAlpha() / 255.0F);
    
    RenderSystem.enableBlend();
    RenderSystem.defaultBlendFunc();

    
    matrices.method_22903();
    matrices.method_46416(0.0F, 0.0F, z);
    matrices.method_23760().method_23761().mul((Matrix4fc)matrices.method_23760().method_23761());
    
    class_287 bufferBuilder = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1576);
    
    Matrix4f matrix = matrices.method_23760().method_23761();
    float r = color.getRed() / 255.0F;
    float g = color.getGreen() / 255.0F;
    float b = color.getBlue() / 255.0F;
    float a = color.getAlpha() / 255.0F;
    
    bufferBuilder.method_22918(matrix, x1, y1, 0.0F).method_22915(r, g, b, a);
    bufferBuilder.method_22918(matrix, x1, y2, 0.0F).method_22915(r, g, b, a);
    bufferBuilder.method_22918(matrix, x2, y2, 0.0F).method_22915(r, g, b, a);
    bufferBuilder.method_22918(matrix, x2, y1, 0.0F).method_22915(r, g, b, a);
    
    class_286.method_43433(bufferBuilder.method_60800());
    
    RenderSystem.disableBlend();
    matrices.method_22909();
  }
  
  public static void renderFilledBox(class_4587 matrixStack, double x1, double y1, double z1, double x2, double y2, double z2, Color color) {
    Matrix4f m = matrixStack.method_23760().method_23761();
    float r = color.getRed() / 255.0F;
    float g = color.getGreen() / 255.0F;
    float b = color.getBlue() / 255.0F;
    float a = color.getAlpha() / 255.0F;
    
    RenderSystem.enableBlend();
    RenderSystem.defaultBlendFunc();
    RenderSystem.disableCull();
    RenderSystem.disableDepthTest();
    RenderSystem.depthMask(false);
    
    class_287 buf = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1576);
    
    v(buf, m, x1, y1, z1, r, g, b, a);
    v(buf, m, x2, y1, z1, r, g, b, a);
    v(buf, m, x2, y1, z2, r, g, b, a);
    v(buf, m, x1, y1, z2, r, g, b, a);
    
    v(buf, m, x1, y2, z1, r, g, b, a);
    v(buf, m, x1, y2, z2, r, g, b, a);
    v(buf, m, x2, y2, z2, r, g, b, a);
    v(buf, m, x2, y2, z1, r, g, b, a);
    
    v(buf, m, x1, y1, z1, r, g, b, a);
    v(buf, m, x1, y2, z1, r, g, b, a);
    v(buf, m, x2, y2, z1, r, g, b, a);
    v(buf, m, x2, y1, z1, r, g, b, a);
    
    v(buf, m, x1, y1, z2, r, g, b, a);
    v(buf, m, x2, y1, z2, r, g, b, a);
    v(buf, m, x2, y2, z2, r, g, b, a);
    v(buf, m, x1, y2, z2, r, g, b, a);
    
    v(buf, m, x1, y1, z1, r, g, b, a);
    v(buf, m, x1, y1, z2, r, g, b, a);
    v(buf, m, x1, y2, z2, r, g, b, a);
    v(buf, m, x1, y2, z1, r, g, b, a);
    
    v(buf, m, x2, y1, z1, r, g, b, a);
    v(buf, m, x2, y2, z1, r, g, b, a);
    v(buf, m, x2, y2, z2, r, g, b, a);
    v(buf, m, x2, y1, z2, r, g, b, a);
    
    RenderSystem.setShader(class_10142.field_53876);
    class_286.method_43433(buf.method_60800());
    
    RenderSystem.enableCull();
    RenderSystem.depthMask(true);
    RenderSystem.enableDepthTest();
    RenderSystem.disableBlend();
  }
  
  public static void drawBox(class_4587 matrices, class_238 box, int argb, boolean outline) {
    float a = (argb >>> 24 & 0xFF) / 255.0F;
    float r = (argb >>> 16 & 0xFF) / 255.0F;
    float g = (argb >>> 8 & 0xFF) / 255.0F;
    float b = (argb & 0xFF) / 255.0F;
    
    RenderSystem.enableBlend();
    RenderSystem.defaultBlendFunc();
    RenderSystem.disableCull();
    RenderSystem.disableDepthTest();
    RenderSystem.depthMask(false);
    
    Matrix4f matrix = matrices.method_23760().method_23761();
    
    if (!outline) {
      class_287 buf = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1576);
      
      v(buf, matrix, box.field_1323, box.field_1322, box.field_1321, r, g, b, a);
      v(buf, matrix, box.field_1320, box.field_1322, box.field_1321, r, g, b, a);
      v(buf, matrix, box.field_1320, box.field_1322, box.field_1324, r, g, b, a);
      v(buf, matrix, box.field_1323, box.field_1322, box.field_1324, r, g, b, a);
      
      v(buf, matrix, box.field_1323, box.field_1325, box.field_1321, r, g, b, a);
      v(buf, matrix, box.field_1323, box.field_1325, box.field_1324, r, g, b, a);
      v(buf, matrix, box.field_1320, box.field_1325, box.field_1324, r, g, b, a);
      v(buf, matrix, box.field_1320, box.field_1325, box.field_1321, r, g, b, a);
      
      v(buf, matrix, box.field_1323, box.field_1322, box.field_1321, r, g, b, a);
      v(buf, matrix, box.field_1323, box.field_1325, box.field_1321, r, g, b, a);
      v(buf, matrix, box.field_1320, box.field_1325, box.field_1321, r, g, b, a);
      v(buf, matrix, box.field_1320, box.field_1322, box.field_1321, r, g, b, a);
      
      v(buf, matrix, box.field_1323, box.field_1322, box.field_1324, r, g, b, a);
      v(buf, matrix, box.field_1320, box.field_1322, box.field_1324, r, g, b, a);
      v(buf, matrix, box.field_1320, box.field_1325, box.field_1324, r, g, b, a);
      v(buf, matrix, box.field_1323, box.field_1325, box.field_1324, r, g, b, a);
      
      v(buf, matrix, box.field_1323, box.field_1322, box.field_1321, r, g, b, a);
      v(buf, matrix, box.field_1323, box.field_1322, box.field_1324, r, g, b, a);
      v(buf, matrix, box.field_1323, box.field_1325, box.field_1324, r, g, b, a);
      v(buf, matrix, box.field_1323, box.field_1325, box.field_1321, r, g, b, a);
      
      v(buf, matrix, box.field_1320, box.field_1322, box.field_1321, r, g, b, a);
      v(buf, matrix, box.field_1320, box.field_1325, box.field_1321, r, g, b, a);
      v(buf, matrix, box.field_1320, box.field_1325, box.field_1324, r, g, b, a);
      v(buf, matrix, box.field_1320, box.field_1322, box.field_1324, r, g, b, a);
      RenderSystem.setShader(class_10142.field_53876);
      class_286.method_43433(buf.method_60800());
    } else {
      class_287 buf = class_289.method_1348().method_60827(class_293.class_5596.field_29344, class_290.field_1576);
      RenderSystem.lineWidth(2.0F);
      
      lineLoop(buf, matrix, box.field_1323, box.field_1322, box.field_1321, box.field_1320, box.field_1322, box.field_1324, r, g, b, a);
      
      lineLoop(buf, matrix, box.field_1323, box.field_1325, box.field_1321, box.field_1320, box.field_1325, box.field_1324, r, g, b, a);
      
      v(buf, matrix, box.field_1323, box.field_1322, box.field_1321, r, g, b, a);
      v(buf, matrix, box.field_1323, box.field_1325, box.field_1321, r, g, b, a);
      v(buf, matrix, box.field_1320, box.field_1322, box.field_1321, r, g, b, a);
      v(buf, matrix, box.field_1320, box.field_1325, box.field_1321, r, g, b, a);
      v(buf, matrix, box.field_1323, box.field_1322, box.field_1324, r, g, b, a);
      v(buf, matrix, box.field_1323, box.field_1325, box.field_1324, r, g, b, a);
      v(buf, matrix, box.field_1320, box.field_1322, box.field_1324, r, g, b, a);
      v(buf, matrix, box.field_1320, box.field_1325, box.field_1324, r, g, b, a);
      RenderSystem.setShader(class_10142.field_53876);
      class_286.method_43433(buf.method_60800());
    } 
    
    RenderSystem.enableCull();
    RenderSystem.depthMask(true);
    RenderSystem.enableDepthTest();
    RenderSystem.disableBlend();
  }



  
  public static void drawBox(class_4587 matrices, double x1, double y1, double z1, double x2, double y2, double z2, int argb, boolean outline) {
    float a = (argb >>> 24 & 0xFF) / 255.0F;
    float r = (argb >>> 16 & 0xFF) / 255.0F;
    float g = (argb >>> 8 & 0xFF) / 255.0F;
    float b = (argb & 0xFF) / 255.0F;
    
    RenderSystem.enableBlend();
    RenderSystem.defaultBlendFunc();
    RenderSystem.disableCull();
    RenderSystem.disableDepthTest();
    RenderSystem.depthMask(false);
    
    Matrix4f matrix = matrices.method_23760().method_23761();
    
    if (!outline) {
      class_287 buf = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1576);

      
      v(buf, matrix, x1, y1, z1, r, g, b, a);
      v(buf, matrix, x2, y1, z1, r, g, b, a);
      v(buf, matrix, x2, y1, z2, r, g, b, a);
      v(buf, matrix, x1, y1, z2, r, g, b, a);

      
      v(buf, matrix, x1, y2, z1, r, g, b, a);
      v(buf, matrix, x1, y2, z2, r, g, b, a);
      v(buf, matrix, x2, y2, z2, r, g, b, a);
      v(buf, matrix, x2, y2, z1, r, g, b, a);

      
      v(buf, matrix, x1, y1, z1, r, g, b, a);
      v(buf, matrix, x1, y2, z1, r, g, b, a);
      v(buf, matrix, x2, y2, z1, r, g, b, a);
      v(buf, matrix, x2, y1, z1, r, g, b, a);

      
      v(buf, matrix, x1, y1, z2, r, g, b, a);
      v(buf, matrix, x2, y1, z2, r, g, b, a);
      v(buf, matrix, x2, y2, z2, r, g, b, a);
      v(buf, matrix, x1, y2, z2, r, g, b, a);

      
      v(buf, matrix, x1, y1, z1, r, g, b, a);
      v(buf, matrix, x1, y1, z2, r, g, b, a);
      v(buf, matrix, x1, y2, z2, r, g, b, a);
      v(buf, matrix, x1, y2, z1, r, g, b, a);

      
      v(buf, matrix, x2, y1, z1, r, g, b, a);
      v(buf, matrix, x2, y2, z1, r, g, b, a);
      v(buf, matrix, x2, y2, z2, r, g, b, a);
      v(buf, matrix, x2, y1, z2, r, g, b, a);
      
      RenderSystem.setShader(class_10142.field_53876);
      class_286.method_43433(buf.method_60800());
    } else {
      
      class_287 buf = class_289.method_1348().method_60827(class_293.class_5596.field_29344, class_290.field_1576);
      RenderSystem.lineWidth(2.0F);

      
      lineLoop(buf, matrix, x1, y1, z1, x2, y1, z2, r, g, b, a);
      
      lineLoop(buf, matrix, x1, y2, z1, x2, y2, z2, r, g, b, a);
      
      v(buf, matrix, x1, y1, z1, r, g, b, a);
      v(buf, matrix, x1, y2, z1, r, g, b, a);
      v(buf, matrix, x2, y1, z1, r, g, b, a);
      v(buf, matrix, x2, y2, z1, r, g, b, a);
      v(buf, matrix, x1, y1, z2, r, g, b, a);
      v(buf, matrix, x1, y2, z2, r, g, b, a);
      v(buf, matrix, x2, y1, z2, r, g, b, a);
      v(buf, matrix, x2, y2, z2, r, g, b, a);
      
      RenderSystem.setShader(class_10142.field_53876);
      class_286.method_43433(buf.method_60800());
    } 
    
    RenderSystem.enableCull();
    RenderSystem.depthMask(true);
    RenderSystem.enableDepthTest();
    RenderSystem.disableBlend();
  }


  
  private static void lineLoop(class_287 buf, Matrix4f m, double x1, double y, double z1, double x2, double y2, double z2, float r, float g, float b, float a) {
    v(buf, m, x1, y, z1, r, g, b, a);
    v(buf, m, x2, y, z1, r, g, b, a);
    v(buf, m, x2, y, z1, r, g, b, a);
    v(buf, m, x2, y, z2, r, g, b, a);
    v(buf, m, x2, y, z2, r, g, b, a);
    v(buf, m, x1, y, z2, r, g, b, a);
    v(buf, m, x1, y, z2, r, g, b, a);
    v(buf, m, x1, y, z1, r, g, b, a);
  }
  
  private static void v(class_287 b, Matrix4f m, double x, double y, double z, float r, float g, float bl, float a) {
    b.method_22918(m, (float)x, (float)y, (float)z).method_22915(r, g, bl, a);
  }
  
  public static int withAlpha(int rgb, int alpha255) {
    return (alpha255 & 0xFF) << 24 | rgb & 0xFFFFFF;
  }
  
  public static int rainbow(int offsetMs, float alpha) {
    float hue = (float)((System.currentTimeMillis() + offsetMs) % 3000L) / 3000.0F;
    int rgb = Color.HSBtoRGB(hue, 1.0F, 1.0F) & 0xFFFFFF;
    return withAlpha(rgb, (int)(alpha * 255.0F));
  }
}


