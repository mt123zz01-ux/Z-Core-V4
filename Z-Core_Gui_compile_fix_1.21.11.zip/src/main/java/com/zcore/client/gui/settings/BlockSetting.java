package com.zcore.client.gui.settings;

import java.util.HashSet;
import java.util.Set;
import net.minecraft.class_2248;

public class BlockSetting
  extends Setting<Set<class_2248>> {
  public BlockSetting(String name, Set<class_2248> defaultValue) {
    super(name, (defaultValue != null) ? defaultValue : new HashSet<>());
  }
  
  public Set<class_2248> getBlocks() {
    return getValue();
  }
  
  public void addBlock(class_2248 block) {
    getValue().add(block);
  }
  
  public void removeBlock(class_2248 block) {
    getValue().remove(block);
  }
  
  public boolean containsBlock(class_2248 block) {
    return getValue().contains(block);
  }
}


