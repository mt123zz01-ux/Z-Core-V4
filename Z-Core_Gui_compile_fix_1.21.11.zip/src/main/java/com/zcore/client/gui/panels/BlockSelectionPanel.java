package com.zcore.client.gui.panels;

import com.zcore.client.gui.ZCoreGuiTheme;
import com.zcore.client.gui.components.SearchBar;
import com.zcore.client.gui.settings.BlockSetting;
import com.zcore.client.gui.utils.DragHandler;
import com.zcore.client.gui.utils.GuiUtils;
import com.zcore.client.utils.render.RenderUtils;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1935;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_7923;

public class BlockSelectionPanel {
  private static final int HEADER_HEIGHT = 30;
  private final SearchBar searchBar;
  private final DragHandler dragHandler;
  private final class_310 client = class_310.method_1551();
  private final int panelWidth = 150;
  private final int panelHeight = 180;
  private BlockSetting editingSetting;
  private int panelX = 100, panelY = 100;
  private int scrollOffset = 0;
  
  public BlockSelectionPanel() {
    this.searchBar = new SearchBar();
    this.dragHandler = new DragHandler();
  }
  
  public BlockSetting getEditingSetting() {
    return this.editingSetting;
  }
  
  public void setEditingBlock(BlockSetting setting) {
    this.editingSetting = setting;
    if (setting != null) {
      this.searchBar.clear();
      this.scrollOffset = 0;

      
      int screenWidth = this.client.method_22683().method_4489() / 2;
      int screenHeight = this.client.method_22683().method_4506() / 2;
      setPosition((screenWidth - 150) / 2, (screenHeight - 180) / 2);
    } 
  }
  
  public void setPosition(int x, int y) {
    this.panelX = x;
    this.panelY = y;
    this.dragHandler.setPosition(x, y);
  }

  
  public boolean isOpen() {
    return (this.editingSetting != null);
  }
  
  public void render(class_332 context, int mouseX, int mouseY, float progress) {
    if (this.editingSetting == null)
      return; 
    int[] pos = this.dragHandler.getAnimatedPosition();
    this.panelX = pos[0];
    this.panelY = pos[1];
    
    int cornerRadius = 12;
    
    int bgColor = ZCoreGuiTheme.applyAlpha(ZCoreGuiTheme.getSettingsPanelColor(), progress * ZCoreGuiTheme.getPanelAlpha());
    RenderUtils.fillRoundRect(context, this.panelX, this.panelY, 150, 180, cornerRadius, bgColor);
    
    int borderColor = ZCoreGuiTheme.applyAlpha(ZCoreGuiTheme.getAccentColor(), progress * 0.4F);
    RenderUtils.drawRoundRect(context, this.panelX, this.panelY, 150, 180, cornerRadius, borderColor);
    
    int headerColor = ZCoreGuiTheme.applyAlpha(ZCoreGuiTheme.getCategoryHeader(), progress * ZCoreGuiTheme.getPanelAlpha());
    RenderUtils.fillRoundTabTop(context, this.panelX, this.panelY, 150, 30, cornerRadius, headerColor);
    
    int titleColor = ZCoreGuiTheme.applyAlpha(-1, (int)(progress * 255.0F)) | 0xFF000000;
    context.method_51433(this.client.field_1772, "Select Blocks", this.panelX + 10, this.panelY + 10, titleColor, true);
    
    int closeX = this.panelX + 150 - 20;
    int closeY = this.panelY + 8;
    boolean closeHovered = GuiUtils.isHovered(mouseX, mouseY, closeX, closeY, 16, 16);
    int closeColor = closeHovered ? ZCoreGuiTheme.getAccentColor() : -3355444;
    context.method_51433(this.client.field_1772, "✕", closeX + 2, this.panelY + 10, 
        ZCoreGuiTheme.applyAlpha(closeColor, (int)(progress * 255.0F)) | 0xFF000000, false);
    
    int searchBarX = this.panelX + 10;
    int searchBarY = this.panelY + 35;
    int searchBarWidth = 130;
    int searchBarHeight = 20;
    this.searchBar.setWidth(searchBarWidth);
    boolean searchHovered = GuiUtils.isHovered(mouseX, mouseY, searchBarX, searchBarY, searchBarWidth, searchBarHeight);

    
    int searchBarColor = (this.searchBar.isEditing() || searchHovered) ? ZCoreGuiTheme.applyAlpha(ZCoreGuiTheme.getHoverColor(), progress * 0.5F) : ZCoreGuiTheme.applyAlpha(0, 0.0F);
    
    int subRadius = Math.max(2, cornerRadius / 2);
    RenderUtils.fillRoundRect(context, searchBarX, searchBarY, searchBarWidth, searchBarHeight, subRadius, searchBarColor);
    
    String searchText = this.searchBar.getQuery();
    if (this.searchBar.isEditing() && searchText.isEmpty()) {
      searchText = "Search for a block...";
    } else if (!this.searchBar.isEditing() && searchText.isEmpty()) {
      searchText = "Search for a block...";
    } 
    context.method_51433(this.client.field_1772, searchText, searchBarX + 5, searchBarY + 6, titleColor, false);
    
    int itemsStartY = this.panelY + 60;
    int itemsHeight = 110;
    
    int BLOCK_SIZE = 20;
    int BLOCK_PADDING = 3;
    int BLOCKS_PER_ROW = 6;
    
    RenderUtils.fillRoundRect(context, this.panelX + 5, itemsStartY, 140, itemsHeight, subRadius, 
        ZCoreGuiTheme.applyAlpha(0, 0.0F));
    
    context.method_44379(this.panelX + 5, itemsStartY, this.panelX + 150 - 5, itemsStartY + itemsHeight);
    
    List<class_2248> allBlocks = getFilteredBlocks();
    
    int totalRows = (int)Math.ceil(allBlocks.size() / BLOCKS_PER_ROW);
    int visibleRows = itemsHeight / (BLOCK_SIZE + BLOCK_PADDING);
    int maxRowScroll = Math.max(0, totalRows - visibleRows);
    int rowScrollOffset = Math.max(0, Math.min(this.scrollOffset / BLOCKS_PER_ROW, maxRowScroll));
    
    int startIndex = rowScrollOffset * BLOCKS_PER_ROW;
    int endIndex = Math.min(startIndex + visibleRows * BLOCKS_PER_ROW, allBlocks.size());
    
    int gridWidth = BLOCKS_PER_ROW * BLOCK_SIZE + (BLOCKS_PER_ROW - 1) * BLOCK_PADDING;
    int gridStartX = this.panelX + (150 - gridWidth) / 2;
    
    for (int i = startIndex; i < endIndex; i++) {
      int blockBgColor; class_2248 block = allBlocks.get(i);
      int row = (i - startIndex) / BLOCKS_PER_ROW;
      int col = (i - startIndex) % BLOCKS_PER_ROW;
      
      int blockX = gridStartX + col * (BLOCK_SIZE + BLOCK_PADDING);
      int blockY = itemsStartY + 5 + row * (BLOCK_SIZE + BLOCK_PADDING);
      
      boolean blockHovered = GuiUtils.isHovered(mouseX, mouseY, blockX, blockY, BLOCK_SIZE, BLOCK_SIZE);
      boolean selected = this.editingSetting.containsBlock(block);

      
      if (selected) {
        blockBgColor = ZCoreGuiTheme.applyAlpha(ZCoreGuiTheme.getAccentColor(), progress * 0.4F);
      } else if (blockHovered) {
        blockBgColor = ZCoreGuiTheme.applyAlpha(ZCoreGuiTheme.getHoverColor(), progress * 0.3F);
      } else {
        blockBgColor = ZCoreGuiTheme.applyAlpha(0, 0.0F);
      } 
      
      if (blockBgColor != 0) {
        int blockRadius = 2;
        RenderUtils.fillRoundRect(context, blockX, blockY, BLOCK_SIZE, BLOCK_SIZE, blockRadius, blockBgColor);
      } 
      
      if (selected) {
        int blockBorderColor = ZCoreGuiTheme.applyAlpha(ZCoreGuiTheme.getAccentColor(), progress * 0.9F);
        RenderUtils.drawRoundRect(context, blockX, blockY, BLOCK_SIZE, BLOCK_SIZE, 2, blockBorderColor);
      } 
      
      class_1799 blockStack = new class_1799((class_1935)block.method_8389());
      if (!blockStack.method_7960() && blockStack.method_7909() != class_1802.field_8162) {
        context.method_51427(blockStack, blockX, blockY);
      } else {
        context.method_51433(this.client.field_1772, "?", blockX + 6, blockY + 6, -1, true);
      } 
    } 

    
    context.method_44380();
    
    if (maxRowScroll > 0) {
      int scrollBarX = this.panelX + 150 - 12;
      int scrollBarY = itemsStartY + 5;
      int scrollBarHeight = itemsHeight - 10;
      int scrollBarWidth = 4;
      
      int scrollBarBgColor = ZCoreGuiTheme.applyAlpha(1342177280, progress);
      RenderUtils.fillRoundRect(context, scrollBarX, scrollBarY, scrollBarWidth, scrollBarHeight, 2, scrollBarBgColor);
      
      float scrollProgress = (maxRowScroll > 0) ? (rowScrollOffset / maxRowScroll) : 0.0F;
      int handleHeight = Math.max(20, (int)(visibleRows / totalRows * scrollBarHeight));
      int handleY = scrollBarY + (int)((scrollBarHeight - handleHeight) * scrollProgress);
      
      int handleColor = ZCoreGuiTheme.applyAlpha(ZCoreGuiTheme.getAccentColor(), progress);
      RenderUtils.fillRoundRect(context, scrollBarX, handleY, scrollBarWidth, handleHeight, 2, handleColor);
    } 
  }
  
  public boolean handleClick(double mx, double my, int button) {
    if (this.editingSetting == null) return false;
    
    int closeX = this.panelX + 150 - 20;
    int closeY = this.panelY + 8;
    int closeSize = 16;
    if (GuiUtils.isHovered(mx, my, closeX, closeY, closeSize, closeSize)) {
      this.editingSetting = null;
      return true;
    } 
    
    if (button == 0 && GuiUtils.isHovered(mx, my, this.panelX, this.panelY, 150, 30) && 
      !GuiUtils.isHovered(mx, my, closeX, closeY, closeSize, closeSize)) {
      this.dragHandler.startDrag(mx, my, this.panelX, this.panelY);
      return true;
    } 

    
    int searchBarX = this.panelX + 10;
    int searchBarY = this.panelY + 35;
    if (this.searchBar.handleClick(mx, my, button, searchBarX, searchBarY)) {
      return true;
    }
    
    int itemsStartY = this.panelY + 60;
    int itemsHeight = 110;
    int BLOCK_SIZE = 20;
    int BLOCK_PADDING = 3;
    int BLOCKS_PER_ROW = 6;
    
    if (GuiUtils.isHovered(mx, my, this.panelX + 5, itemsStartY, 140, itemsHeight)) {
      List<class_2248> allBlocks = getFilteredBlocks();
      int totalRows = (int)Math.ceil(allBlocks.size() / BLOCKS_PER_ROW);
      int visibleRows = itemsHeight / (BLOCK_SIZE + BLOCK_PADDING);
      int maxRowScroll = Math.max(0, totalRows - visibleRows);
      int rowScrollOffset = Math.max(0, Math.min(this.scrollOffset / BLOCKS_PER_ROW, maxRowScroll));
      int startIndex = rowScrollOffset * BLOCKS_PER_ROW;
      
      int gridWidth = BLOCKS_PER_ROW * BLOCK_SIZE + (BLOCKS_PER_ROW - 1) * BLOCK_PADDING;
      int gridStartX = this.panelX + (150 - gridWidth) / 2;
      
      int clickedX = (int)mx - gridStartX;
      int clickedY = (int)my - itemsStartY - 5;
      int col = clickedX / (BLOCK_SIZE + BLOCK_PADDING);
      int row = clickedY / (BLOCK_SIZE + BLOCK_PADDING);
      
      if (col >= 0 && col < BLOCKS_PER_ROW && row >= 0) {
        int clickedIndex = startIndex + row * BLOCKS_PER_ROW + col;
        if (clickedIndex >= 0 && clickedIndex < allBlocks.size()) {
          class_2248 clickedBlock = allBlocks.get(clickedIndex);
          if (button == 0) {
            toggleSelection(clickedBlock);
          }
          return true;
        } 
      } 
    } 
    
    return GuiUtils.isHovered(mx, my, this.panelX, this.panelY, 150, 180);
  }
  
  public boolean handleDrag(double mx, double my, int button, double dx, double dy) {
    if (this.editingSetting == null) return false; 
    if (this.dragHandler.isDragging()) {
      this.dragHandler.updatePosition(mx, my);
      return true;
    } 
    return false;
  }
  
  public boolean handleRelease(double mx, double my, int button) {
    if (this.editingSetting == null) return false; 
    if (button == 0) this.dragHandler.stopDrag(); 
    return false;
  }
  
  public boolean handleScroll(double mx, double my, double h, double v) {
    if (this.editingSetting == null) return false; 
    int itemsStartY = this.panelY + 60;
    int itemsHeight = 110;
    if (GuiUtils.isHovered(mx, my, this.panelX + 5, itemsStartY, 140, itemsHeight)) {
      List<class_2248> allBlocks = getFilteredBlocks();
      int BLOCKS_PER_ROW = 6;
      int BLOCK_SIZE = 20;
      int BLOCK_PADDING = 3;
      int totalRows = (int)Math.ceil(allBlocks.size() / BLOCKS_PER_ROW);
      int visibleRows = itemsHeight / (BLOCK_SIZE + BLOCK_PADDING);
      int maxRowScroll = Math.max(0, totalRows - visibleRows);
      
      if (maxRowScroll > 0) {
        this.scrollOffset -= (int)v * BLOCKS_PER_ROW;
        this.scrollOffset = Math.max(0, Math.min(this.scrollOffset, maxRowScroll * BLOCKS_PER_ROW));
        return true;
      } 
    } 
    return false;
  }
  
  public boolean handleKeyPress(int keyCode, int scanCode, int modifiers) {
    if (this.editingSetting == null) return false; 
    return this.searchBar.handleKeyPress(keyCode, scanCode, modifiers);
  }
  
  public boolean handleCharType(char chr, int modifiers) {
    if (this.editingSetting == null) return false; 
    return this.searchBar.handleCharType(chr, modifiers);
  }
  
  private void toggleSelection(class_2248 block) {
    if (this.editingSetting.containsBlock(block)) {
      this.editingSetting.removeBlock(block);
    } else {
      this.editingSetting.addBlock(block);
    } 
  }

  
  private List<class_2248> getFilteredBlocks() {
    List<class_2248> allBlocks = new ArrayList<>();
    String query = this.searchBar.getQuery().toLowerCase();
    Set<class_2248> selectedBlocks = this.editingSetting.getBlocks();
    
    for (class_2248 block : class_7923.field_41175) {
      class_2960 id = class_7923.field_41175.method_10221(block);
      if (id == null)
        continue; 
      class_1799 blockItem = new class_1799((class_1935)block.method_8389());
      if (blockItem.method_7960() || blockItem.method_7909() == class_1802.field_8162) {
        continue;
      }
      
      String blockName = formatBlockName(id.method_12832());
      if (blockName.toLowerCase().contains(query)) {
        allBlocks.add(block);
      }
    } 
    
    allBlocks.sort((b1, b2) -> {
          boolean b1Selected = selectedBlocks.contains(b1);
          boolean b2Selected = selectedBlocks.contains(b2);
          return (b1Selected && !b2Selected) ? -1 : (
            (!b1Selected && b2Selected) ? 1 : formatBlockName(class_7923.field_41175.method_10221(b1).method_12832()).compareToIgnoreCase(formatBlockName(class_7923.field_41175.method_10221(b2).method_12832())));
        });


    
    return allBlocks;
  }
  
  private String formatBlockName(String path) {
    return Arrays.<String>stream(path.split("_"))
      .map(s -> "" + Character.toUpperCase(s.charAt(0)) + Character.toUpperCase(s.charAt(0)))
      .collect(Collectors.joining(" "));
  }
}


