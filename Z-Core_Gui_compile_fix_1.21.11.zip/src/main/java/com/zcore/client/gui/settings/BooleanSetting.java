package com.zcore.client.gui.settings;

public class BooleanSetting
  extends Setting<Boolean> {
  public BooleanSetting(String name, Boolean defaultValue) {
    super(name, defaultValue);
  }
  
  public void toggle() {
    setValue(Boolean.valueOf(!getValue().booleanValue()));
  }
}


