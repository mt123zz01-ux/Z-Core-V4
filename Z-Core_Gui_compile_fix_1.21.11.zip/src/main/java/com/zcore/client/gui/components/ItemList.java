package com.zcore.client.gui.components;

import com.zcore.client.gui.ZCoreGuiTheme;
import com.zcore.client.gui.settings.ItemSetting;
import com.zcore.client.gui.utils.GuiUtils;
import java.util.List;
import java.util.stream.Collectors;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1935;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_7923;

public class ItemList
{
  private final class_310 client = class_310.method_1551();
  private final int itemHeight = 24;
  private int scrollOffset = 0;


  
  public void render(class_332 context, int x, int y, int width, int height, String searchQuery, float animationProgress) {
    GuiUtils.drawRoundedRect(context, x, y, width, height, 5, 
        ZCoreGuiTheme.applyAlpha(ZCoreGuiTheme.getSettingsBackground(), animationProgress * 
          ZCoreGuiTheme.getPanelAlpha()));

    
    context.method_44379(x, y, x + width, y + height);

    
    List<class_1792> items = getFilteredItems(searchQuery);
    int visibleItems = height / 24;
    int maxScroll = Math.max(0, items.size() - visibleItems);
    this.scrollOffset = Math.max(0, Math.min(this.scrollOffset, maxScroll));

    
    for (int i = 0; i < visibleItems && i + this.scrollOffset < items.size(); i++) {
      class_1792 item = items.get(i + this.scrollOffset);
      int itemY = y + 5 + i * 24;
      
      renderItem(context, item, x + 5, itemY, width - 20, 24, animationProgress);
    } 
    
    context.method_44380();

    
    if (maxScroll > 0) {
      renderScrollbar(context, x, y, width, height, items.size(), visibleItems, animationProgress);
    }
  }


  
  private void renderItem(class_332 context, class_1792 item, int x, int y, int width, int height, float animationProgress) {
    int bgColor = ZCoreGuiTheme.applyAlpha(0, 0.0F);
    GuiUtils.drawRoundedRect(context, x, y, width, height, 3, bgColor);

    
    class_1799 itemStack = new class_1799((class_1935)item);
    context.method_51427(itemStack, x + 4, y + 4);

    
    String itemName = item.method_63680().getString();
    int textColor = ZCoreGuiTheme.applyAlpha(ZCoreGuiTheme.getTextColor(), (int)(animationProgress * 255.0F)) | 0xFF000000;
    
    context.method_51433(this.client.field_1772, itemName, x + 28, y + 8, textColor, false);
  }

  
  private void renderScrollbar(class_332 context, int x, int y, int width, int height, int totalItems, int visibleItems, float animationProgress) {
    int scrollBarX = x + width - 15;
    int scrollBarY = y + 5;
    int scrollBarHeight = height - 10;
    int scrollBarWidth = 8;

    
    GuiUtils.drawRoundedRect(context, scrollBarX, scrollBarY, scrollBarWidth, scrollBarHeight, 4, 
        ZCoreGuiTheme.applyAlpha(1342177280, animationProgress));

    
    float scrollProgress = this.scrollOffset / (totalItems - visibleItems);
    int handleHeight = Math.max(20, (int)(visibleItems / totalItems * scrollBarHeight));
    int handleY = scrollBarY + (int)((scrollBarHeight - handleHeight) * scrollProgress);
    
    GuiUtils.drawRoundedRect(context, scrollBarX, handleY, scrollBarWidth, handleHeight, 4, 
        ZCoreGuiTheme.applyAlpha(ZCoreGuiTheme.getAccentColor(), animationProgress));
  }
  
  public boolean handleClick(double mx, double my, int button, int x, int y, ItemSetting itemSetting) {
    if (button != 0) return false;
    
    int height = 180;
    String searchQuery = "";
    
    List<class_1792> items = getFilteredItems(searchQuery);
    int visibleItems = height / 24;
    
    if (GuiUtils.isHovered(mx, my, x, y, 190, height)) {
      int clickedIndex = ((int)my - y + 5) / 24;
      
      if (clickedIndex >= 0 && clickedIndex < visibleItems && clickedIndex + this.scrollOffset < items
        .size()) {
        class_1792 selectedItem = items.get(clickedIndex + this.scrollOffset);
        itemSetting.setValue(selectedItem);
        return true;
      } 
    } 
    
    return false;
  }

  
  public boolean handleScroll(double mx, double my, double hAmount, double vAmount, int x, int y) {
    if (GuiUtils.isHovered(mx, my, x, y, 200, 180)) {
      this.scrollOffset -= (int)vAmount * 3;
      return true;
    } 
    return false;
  }
  
  private List<class_1792> getFilteredItems(String query) {
    return (List<class_1792>)class_7923.field_41178.method_10220()
      .filter(item -> (item != class_1802.field_8162 && item.method_63680().getString().toLowerCase().contains(query.toLowerCase())))
      
      .collect(Collectors.toList());
  }
  
  public void reset() {
    this.scrollOffset = 0;
  }
}


