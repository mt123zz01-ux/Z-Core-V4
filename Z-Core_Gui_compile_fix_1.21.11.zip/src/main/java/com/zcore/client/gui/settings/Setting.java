package com.zcore.client.gui.settings;

import java.util.function.BiConsumer;

public abstract class Setting<T>
{
  protected String name;
  protected T value;
  protected T defaultValue;
  protected BiConsumer<T, T> callback;
  
  public Setting(String name, T defaultValue) {
    this.name = name;
    this.value = defaultValue;
    this.defaultValue = defaultValue;
  }
  
  public String getName() {
    return this.name;
  }
  
  public T getValue() {
    return this.value;
  }
  
  public void setValue(T value) {
    T old = this.value;
    this.value = value;
    if (this.callback != null) {
      this.callback.accept(old, value);
    }
  }
  
  public void setCallback(BiConsumer<T, T> callback) {
    this.callback = callback;
  }
  
  public T getDefaultValue() {
    return this.defaultValue;
  }
  
  public void reset() {
    setValue(this.defaultValue);
  }
}


