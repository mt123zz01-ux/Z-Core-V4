package com.zcore.client.gui.settings;

public class RandomBetweenIntSetting extends Setting<int[]> {
    public RandomBetweenIntSetting(String name, int minDefault, int maxDefault) { super(name, new int[]{minDefault, maxDefault}); }
    public int getMinValue() { return getValue()[0]; }
    public int getMaxValue() { return getValue()[1]; }
}
