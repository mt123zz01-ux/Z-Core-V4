package com.zcore.client.utils;

public class TimerUtil
{
  private long lastMS = System.currentTimeMillis();
  
  public void reset() {
    this.lastMS = System.currentTimeMillis();
  }
  
  public boolean hasTimeElapsed(long time, boolean reset) {
    if (System.currentTimeMillis() - this.lastMS >= time) {
      if (reset) reset(); 
      return true;
    } 
    return false;
  }
  
  public boolean delay(float milliseconds) {
    return (System.currentTimeMillis() - this.lastMS >= (long)milliseconds);
  }
  
  public long getTime() {
    return System.currentTimeMillis() - this.lastMS;
  }
}


