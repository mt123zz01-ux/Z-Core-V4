package com.zcore.client.utils;

import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.concurrent.atomic.AtomicLong;
import net.minecraft.class_310;
import net.minecraft.class_642;



public class PingUtils
{
  private static final AtomicLong cachedPing = new AtomicLong(-1L);
  private static long lastPingTime = 0L;
  
  public static long getCachedPing() {
    return cachedPing.get();
  }
  
  public static void updatePingAsync() {
    long now = System.currentTimeMillis();
    
    if (now - lastPingTime < 1000L)
      return;  lastPingTime = now;
    
    (new Thread(() -> {
          class_310 mc = class_310.method_1551(); if (mc == null || mc.method_1558() == null) {
            cachedPing.set(-1L); return;
          }  class_642 server = mc.method_1558(); String address = server.field_3761; String[] parts = address.split(":"); String host = parts[0];
          int port = (parts.length > 1) ? Integer.parseInt(parts[1]) : 25565;
          try {
            Socket socket = new Socket();
            
            try { long start = System.nanoTime();
              socket.connect(new InetSocketAddress(host, port), 1000);
              long end = System.nanoTime();
              cachedPing.set((end - start) / 1000000L);
              socket.close(); }
            catch (Throwable throwable) { try { socket.close(); } catch (Throwable throwable1)
              { throwable.addSuppressed(throwable1); }
              
              throw throwable; }
          
          } catch (Exception e) {
            cachedPing.set(-1L);
          } 
        })).start();
  }
}


