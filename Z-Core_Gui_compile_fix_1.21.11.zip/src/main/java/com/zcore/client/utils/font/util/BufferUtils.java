package com.zcore.client.utils.font.util;

import com.google.common.base.Preconditions;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_291;
import net.minecraft.class_8555;
import net.minecraft.class_9801;




public class BufferUtils
{
  public static void draw(class_287 builder) {
    class_286.method_43433(builder.method_60800());
  }







  
  public static class_291 createVbo(class_9801 builder) {
    class_291 buffer = new class_291(class_8555.field_54340);
    buffer.method_1353();
    buffer.method_1352(builder);
    class_291.method_1354();
    return buffer;
  }






  
  public static void uploadToVbo(class_9801 builder, class_291 buffer) {
    Preconditions.checkArgument(!buffer.method_43444(), "VBO is closed");
    buffer.method_1353();
    buffer.method_1352(builder);
    class_291.method_1354();
  }
}


