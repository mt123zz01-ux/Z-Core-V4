package com.zcore.client.utils;
import com.zcore.client.client.ZCoreClient;
import com.zcore.client.gui.ZCoreGuiTheme;
import com.zcore.client.modules.client.HUD;
import com.zcore.client.themes.Theme;
import com.zcore.client.themes.ThemeManager;
import com.zcore.client.utils.render.RenderUtils;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.class_310;
import net.minecraft.class_332;

public class ToastNotificationManager {
  private static final ToastNotificationManager INSTANCE = new ToastNotificationManager();
  private static final int TOAST_WIDTH = 150;
  private static final int TOAST_HEIGHT = 35;
  private static final int TOAST_PADDING = 6;
  private static final int TOAST_SPACING = 6;
  private static final int TOAST_MARGIN = 12;
  private static final int TOAST_RADIUS = 5;
  private static final long ANIMATION_DURATION = 200L;
  private final List<ToastNotification> activeToasts = new ArrayList<>();
  private final class_310 mc = class_310.method_1551();



  
  public static ToastNotificationManager getInstance() {
    return INSTANCE;
  }
  
  public void show(ToastNotification toast) {
    if (ZCoreClient.mc == null)
      return; 
    removeExpired();
    
    this.activeToasts.add(0, toast);
    
    while (this.activeToasts.size() > 5) {
      this.activeToasts.remove(this.activeToasts.size() - 1);
    }
    
    playSoundForType(toast.getType());
  }
  
  public void show(String title, String message, ToastNotification.ToastType type) {
    show(new ToastNotification(title, message, type));
  }
  
  public void render(class_332 context, float delta) {
    if (ZCoreClient.mc == null)
      return; 
    int screenWidth = this.mc.method_22683().method_4486();
    int screenHeight = this.mc.method_22683().method_4502();
    
    int startX = screenWidth - 150 - 12;
    int currentY = screenHeight - 12;
    
    removeExpired();
    
    long currentTime = System.currentTimeMillis();
    Iterator<ToastNotification> iterator = this.activeToasts.iterator();
    while (iterator.hasNext()) {
      ToastNotification toast = iterator.next();
      
      long elapsed = currentTime - toast.getCreatedAt();
      if (elapsed < 200L) {
        float progress = (float)elapsed / 200.0F;
        toast.setAnimationProgress(easeOutCubic(progress));
      } else if (toast.isExpired()) {
        float progress = (float)(elapsed - toast.getDuration()) / 200.0F;
        if (progress >= 1.0F) {
          iterator.remove();
          continue;
        } 
        toast.setAnimationProgress(1.0F - easeInCubic(progress));
      } else {
        toast.setAnimationProgress(1.0F);
      } 
      
      renderToast(context, toast, startX, currentY - 35, delta);
      
      currentY -= 41;
    } 
  }

  
  private void renderToast(class_332 context, ToastNotification toast, int x, int y, float delta) {
    float animProgress = toast.getAnimationProgress();
    
    int animX = (int)(x + 150.0F * (1.0F - animProgress));

    
    Theme theme = ThemeManager.getHudTheme();
    HUD hud = (HUD)ZCoreClient.getModuleManager().getModule(HUD.class);
    int alphaValue = (hud != null) ? ((Double)hud.alpha.getValue()).intValue() : 80;
    
    int backgroundColor = theme.getBackgroundColor(alphaValue);
    int shadowColor = theme.getShadowColor();
    int borderColor = theme.getBorderColor();
    int textColor = theme.getTextColor(hud);

    
    int statusColor = toast.getColor();
    int titleColor = ZCoreGuiTheme.applyAlpha(statusColor, 1.0F);
    
    int radius = theme.getRadius(6);
    boolean useShadows = theme.useShadows();
    boolean useBorders = theme.useBorders();
    
    if (useShadows) {
      RenderUtils.fillRoundRect(context, animX + 1, y + 1, 150, 35, radius, radius, radius, radius, shadowColor);
    }

    
    RenderUtils.fillRoundRect(context, animX, y, 150, 35, radius, radius, radius, radius, -536215022);
    
    if (useBorders) {
      RenderUtils.drawRoundRect(context, animX, y, 150, 35, radius, borderColor);
    }
    
    boolean useCustomFont = false;
    int textX = animX + 6;
    int titleY = y + 6;
    int messageY = y + 6 + 13;
    
    context.method_51448().method_22903();
    
    context.method_51433(this.mc.field_1772, toast.getTitle(), textX, titleY, titleColor, true);
    if (toast.getMessage() != null && !toast.getMessage().isEmpty()) {
      context.method_51433(this.mc.field_1772, toast.getMessage(), textX, messageY, textColor, true);
    }
    context.method_51448().method_22909();
    
    float remaining = toast.getRemainingProgress();
    if (remaining < 1.0F && remaining > 0.0F) {
      int maxBarWidth = 150 - radius * 2;
      int progressWidth = (int)(maxBarWidth * remaining);
      int progressY = y + 35 - 3;
      int progressX = animX + radius;
      
      RenderUtils.fillRoundRect(context, progressX, progressY, progressWidth, 2, 1, ZCoreGuiTheme.applyAlpha(statusColor, 0.6F));
    } 
  }
  
  private void removeExpired() {
    long currentTime = System.currentTimeMillis();
    this.activeToasts.removeIf(toast -> {
          long elapsed = currentTime - toast.getCreatedAt();
          return (elapsed >= toast.getDuration() + 200L);
        });
  }

  
  private void playSoundForType(ToastNotification.ToastType type) {}

  
  private float easeOutCubic(float t) {
    return 1.0F - (float)Math.pow((1.0F - t), 3.0D);
  }
  
  private float easeInCubic(float t) {
    return t * t * t;
  }
  
  public void clear() {
    this.activeToasts.clear();
  }
}


