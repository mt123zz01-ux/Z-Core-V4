package com.zcore.client.utils;

import com.zcore.client.client.KeybindManager;
import com.zcore.client.client.ZCoreClient;
import org.lwjgl.glfw.GLFW;

public final class KeyUtils
{
  public static boolean isKeyPressed(int keyCode) {
    if (ZCoreClient.mc.method_22683() == null) return false;

    
    if (KeybindManager.isMouseButton(keyCode)) {
      int mouseButton = KeybindManager.getMouseButtonFromKeyCode(keyCode);
      if (mouseButton >= 0) {
        return (GLFW.glfwGetMouseButton(ZCoreClient.mc.method_22683().method_4490(), mouseButton) == 1);
      }
    } 

    
    if (keyCode <= 8) {
      return (GLFW.glfwGetMouseButton(ZCoreClient.mc.method_22683().method_4490(), keyCode) == 1);
    }
    
    return (GLFW.glfwGetKey(ZCoreClient.mc.method_22683().method_4490(), keyCode) == 1);
  }
}


