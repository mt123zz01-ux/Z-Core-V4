package com.zcore.client.utils;
import com.zcore.client.client.ZCoreClient;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.function.Predicate;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1707;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;

public final class InventoryUtil {
  public static void swap(int selectedSlot) {
    if (selectedSlot < 0 || selectedSlot > 8) {
      return;
    }
    (ZCoreClient.mc.field_1724.method_31548()).field_7545 = selectedSlot;
  }
  
  public static boolean swapStack(Predicate<class_1799> predicate) {
    class_1661 getInventory = ZCoreClient.mc.field_1724.method_31548();
    for (int i = 0; i < 9; i++) {
      if (predicate.test(getInventory.method_5438(i))) {
        getInventory.field_7545 = i;
        return true;
      } 
    } 
    return false;
  }
  
  public static boolean swapItem(Predicate<class_1792> predicate) {
    class_1661 getInventory = ZCoreClient.mc.field_1724.method_31548();
    for (int i = 0; i < 9; i++) {
      if (predicate.test(getInventory.method_5438(i).method_7909())) {
        getInventory.field_7545 = i;
        return true;
      } 
    } 
    return false;
  }
  
  public static boolean swap(class_1792 item) {
    return swapItem(item2 -> (item2 == item));
  }
  
  public static int getSlot(class_1792 obj) {
    class_1703 currentScreenHandler = ZCoreClient.mc.field_1724.field_7512;
    if (ZCoreClient.mc.field_1724.field_7512 instanceof class_1707) {
      int n = 0;
      for (int i = 0; i < ((class_1707)ZCoreClient.mc.field_1724.field_7512).method_17388() * 9; i++) {
        if (currentScreenHandler.method_7611(i).method_7677().method_7909().equals(obj)) {
          n++;
        }
      } 
      return n;
    } 
    return 0;
  }
  
  public static int findTotemSlot() {
    class_1661 inv = ZCoreClient.mc.field_1724.method_31548();
    for (int i = 9; i < 36; i++) {
      if (inv.method_5438(i).method_7909() == class_1802.field_8288) {
        return i;
      }
    } 
    return -1;
  }
  
  public static int findRandomTotemSlot() {
    class_1661 inv = ZCoreClient.mc.field_1724.method_31548();
    List<Integer> slots = new ArrayList<>();
    for (int i = 9; i < 36; i++) {
      if (inv.method_5438(i).method_7909() == class_1802.field_8288) {
        slots.add(Integer.valueOf(i));
      }
    } 
    if (slots.isEmpty()) return -1; 
    return ((Integer)slots.get((new Random()).nextInt(slots.size()))).intValue();
  }
  
  public static int countItemExceptHotbar(class_1792 item) {
    class_1661 inv = ZCoreClient.mc.field_1724.method_31548();
    int count = 0;
    for (int i = 9; i < 36; i++) {
      class_1799 stack = inv.method_5438(i);
      if (stack.method_7909() == item) {
        count += stack.method_7947();
      }
    } 
    return count;
  }
  
  public static boolean isTool(class_1799 stack) {
    class_1792 item = stack.method_7909();
    return (item instanceof net.minecraft.class_1766 || item instanceof net.minecraft.class_1829 || item instanceof net.minecraft.class_1738);
  }
}


