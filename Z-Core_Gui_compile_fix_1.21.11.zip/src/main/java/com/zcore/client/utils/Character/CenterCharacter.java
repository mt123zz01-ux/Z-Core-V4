package com.zcore.client.utils.Character;

import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_310;

public class CenterCharacter
{
  private static final double TOLERANCE = 0.15D;
  private final class_310 mc;
  private boolean isActive = false;
  private class_2338 targetBlock = null;
  private int tickCount = 0;
  
  public CenterCharacter(class_310 mc) {
    this.mc = mc;
  }
  
  public boolean initiate() {
    if (this.mc.field_1724 == null) {
      return false;
    }
    class_2338 playerBlock = this.mc.field_1724.method_24515();
    class_243 playerPos = this.mc.field_1724.method_19538();
    
    double offsetX = playerPos.field_1352 - playerBlock.method_10263() + 0.5D;
    double offsetZ = playerPos.field_1350 - playerBlock.method_10260() + 0.5D;
    
    if (Math.abs(offsetX) < 0.15D && Math.abs(offsetZ) < 0.15D) {
      return false;
    }
    
    this.targetBlock = playerBlock;
    this.isActive = true;
    this.tickCount = 0;
    return true;
  }
  
  public boolean update() {
    if (!this.isActive || this.mc.field_1724 == null || this.targetBlock == null) {
      return false;
    }
    
    this.tickCount++;
    
    class_243 playerPos = this.mc.field_1724.method_19538();
    double targetX = this.targetBlock.method_10263() + 0.5D;
    double targetZ = this.targetBlock.method_10260() + 0.5D;
    
    double worldOffsetX = playerPos.field_1352 - targetX;
    double worldOffsetZ = playerPos.field_1350 - targetZ;
    
    if (Math.abs(worldOffsetX) < 0.15D && Math.abs(worldOffsetZ) < 0.15D) {
      haltCentering();
      return false;
    } 
    
    stopMovement();
    
    boolean shouldTap = (this.tickCount % 2 == 0);
    if (!shouldTap) {
      return true;
    }
    
    float yaw = this.mc.field_1724.method_36454();
    double yawRad = Math.toRadians(yaw);
    
    double moveX = -worldOffsetX;
    double moveZ = -worldOffsetZ;
    
    double relativeForward = moveX * -Math.sin(yawRad) + moveZ * Math.cos(yawRad);
    double relativeStrafe = moveX * -Math.cos(yawRad) + moveZ * -Math.sin(yawRad);
    
    if (Math.abs(relativeForward) > 0.075D) {
      if (relativeForward > 0.0D) {
        this.mc.field_1690.field_1894.method_23481(true);
      } else {
        this.mc.field_1690.field_1881.method_23481(true);
      } 
    }
    
    if (Math.abs(relativeStrafe) > 0.075D) {
      if (relativeStrafe > 0.0D) {
        this.mc.field_1690.field_1849.method_23481(true);
      } else {
        this.mc.field_1690.field_1913.method_23481(true);
      } 
    }
    
    if (this.tickCount > 100) {
      haltCentering();
      return false;
    } 
    
    return true;
  }
  
  public void haltCentering() {
    this.isActive = false;
    this.targetBlock = null;
    stopMovement();
    this.tickCount = 0;
  }
  
  private void stopMovement() {
    this.mc.field_1690.field_1894.method_23481(false);
    this.mc.field_1690.field_1881.method_23481(false);
    this.mc.field_1690.field_1913.method_23481(false);
    this.mc.field_1690.field_1849.method_23481(false);
    this.mc.field_1690.field_1832.method_23481(false);
  }
  
  public boolean isCentering() {
    return this.isActive;
  }
}


