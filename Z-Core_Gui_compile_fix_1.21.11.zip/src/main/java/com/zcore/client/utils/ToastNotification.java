package com.zcore.client.utils;

public class ToastNotification {
    public enum ToastType {
        INFO(0xFF4DA3FF),
        SUCCESS(0xFF4CAF50),
        WARNING(0xFFFFC107),
        ERROR(0xFFFF5252),
        CONFIG_LOAD(0xFF4DA3FF),
        CONFIG_SAVE(0xFF4CAF50);

        private final int color;

        ToastType(int color) {
            this.color = color;
        }

        public int getColor() {
            return color;
        }
    }

    private final String title;
    private final String message;
    private final ToastType type;
    private final long createdAt;
    private final long duration;
    private float animationProgress;

    public ToastNotification(String title, String message, ToastType type) {
        this(title, message, type, 3000L);
    }

    public ToastNotification(String title, String message, ToastType type, long duration) {
        this.title = title;
        this.message = message;
        this.type = type == null ? ToastType.INFO : type;
        this.duration = duration;
        this.createdAt = System.currentTimeMillis();
        this.animationProgress = 0.0F;
    }

    public String getTitle() {
        return title;
    }

    public String getMessage() {
        return message;
    }

    public ToastType getType() {
        return type;
    }

    public int getColor() {
        return type.getColor();
    }

    public long getCreatedAt() {
        return createdAt;
    }

    public long getDuration() {
        return duration;
    }

    public boolean isExpired() {
        return System.currentTimeMillis() - createdAt >= duration;
    }

    public float getAnimationProgress() {
        return animationProgress;
    }

    public void setAnimationProgress(float animationProgress) {
        this.animationProgress = Math.max(0.0F, Math.min(1.0F, animationProgress));
    }

    public float getRemainingProgress() {
        long elapsed = System.currentTimeMillis() - createdAt;
        if (elapsed <= 0L) return 1.0F;
        if (elapsed >= duration) return 0.0F;
        return 1.0F - ((float) elapsed / (float) duration);
    }
}
