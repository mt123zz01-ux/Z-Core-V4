package com.zcore.client.utils.render;

public class BlurManager {
  public static void render(float intensity) {}
}


