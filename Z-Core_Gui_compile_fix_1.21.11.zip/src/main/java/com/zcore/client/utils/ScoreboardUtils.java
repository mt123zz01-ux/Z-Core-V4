package com.zcore.client.utils;
import java.util.Collection;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.class_2561;
import net.minecraft.class_266;
import net.minecraft.class_268;
import net.minecraft.class_269;
import net.minecraft.class_310;
import net.minecraft.class_8646;
import net.minecraft.class_9011;

public class ScoreboardUtils {
  public static String getRawScoreboard() {
    try {
      class_310 mc = class_310.method_1551();
      if (mc == null || mc.field_1724 == null || mc.field_1687 == null || mc.field_1687.method_8428() == null) {
        return "";
      }
      
      class_269 scoreboard = mc.field_1687.method_8428();
      if (scoreboard == null) return "";
      
      class_266 objective = scoreboard.method_1189(class_8646.field_45157);
      if (objective == null) return "";
      
      StringBuilder result = new StringBuilder();
      Collection<class_9011> entries = scoreboard.method_1184(objective);
      if (entries == null) return "";
      
      for (class_9011 entry : entries) {
        if (entry == null)
          continue; 
        String name = entry.comp_2127();
        if (name == null)
          continue; 
        try {
          class_268 team = scoreboard.method_1164(name);
          if (team != null) {
            class_2561 prefix = team.method_1144();
            class_2561 suffix = team.method_1136();
            if (prefix != null && suffix != null) {
              result.append(prefix.getString()).append(name).append(suffix.getString()).append("\n"); continue;
            } 
            result.append(name).append("\n");
            continue;
          } 
          result.append(name).append("\n");
        }
        catch (Exception e) {
          
          result.append(name).append("\n");
        } 
      } 
      
      return result.toString();
    } catch (Exception e) {
      
      return "";
    } 
  }
  
  public static String getPing() {
    String scoreboard = getRawScoreboard();
    Pattern pattern = Pattern.compile("\\((\\d+)ms\\)");
    Matcher matcher = pattern.matcher(scoreboard);
    
    if (matcher.find()) {
      return matcher.group(1);
    }
    
    return String.valueOf(PingUtils.getCachedPing());
  }
  
  public static String getMoney() {
    String scoreboard = getRawScoreboard();
    if (scoreboard.isEmpty()) return "0";
    
    Pattern pattern = Pattern.compile("(?:\\$|Money|Balance)\\s*:?\\s*\\$?\\s*([0-9]{1,3}(?:,[0-9]{3})*(?:\\.\\d+)?[KMB]?)", 2);



    
    Matcher matcher = pattern.matcher(scoreboard);
    
    if (matcher.find()) {
      return matcher.group(1).replace(",", "");
    }
    
    return "0";
  }

  
  public static String getKeyallTimer() {
    String scoreboard = getRawScoreboard();
    Pattern pattern = Pattern.compile("Keyall\\s+([0-9]+[msh]\\s*)+", 2);
    Matcher matcher = pattern.matcher(scoreboard);
    
    if (matcher.find()) {
      String fullMatch = matcher.group(0);
      return fullMatch.replaceFirst("(?i)Keyall\\s+", "").trim();
    } 
    
    return "";
  }
  
  public static String getRegion(boolean replace) {
    String scoreboard = getRawScoreboard();
    
    scoreboard = scoreboard.replaceAll("§.", "");
    
    Pattern pattern = Pattern.compile("([A-Za-z][A-Za-z\\s]+)\\s*\\(");
    Matcher matcher = pattern.matcher(scoreboard);
    
    if (matcher.find()) {
      String region = matcher.group(1).trim();
      if (!region.isEmpty()) {
        return replace ? "Z-Core+" : region;
      }
    } 
    
    return "Z-Core+";
  }
}


