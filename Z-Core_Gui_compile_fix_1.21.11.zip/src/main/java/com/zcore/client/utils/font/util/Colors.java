package com.zcore.client.utils.font.util;

import com.google.common.base.Preconditions;














public class Colors
{
  public static int ARGBToInt(int r, int g, int b, int a) {
    Preconditions.checkArgument(validateColorRange(r), "Expected r to be 0-255, received " + r);
    Preconditions.checkArgument(validateColorRange(g), "Expected g to be 0-255, received " + g);
    Preconditions.checkArgument(validateColorRange(b), "Expected b to be 0-255, received " + b);
    Preconditions.checkArgument(validateColorRange(a), "Expected a to be 0-255, received " + a);
    return a << 24 | r << 16 | g << 8 | b;
  }










  
  public static int RGBAToInt(int r, int g, int b, int a) {
    Preconditions.checkArgument(validateColorRange(r), "Expected r to be 0-255, received " + r);
    Preconditions.checkArgument(validateColorRange(g), "Expected g to be 0-255, received " + g);
    Preconditions.checkArgument(validateColorRange(b), "Expected b to be 0-255, received " + b);
    Preconditions.checkArgument(validateColorRange(a), "Expected a to be 0-255, received " + a);
    return r << 24 | g << 16 | b << 8 | a;
  }






  
  public static int[] RGBAIntToRGBA(int in) {
    int red = in >> 24 & 0xFF;
    int green = in >> 16 & 0xFF;
    int blue = in >> 8 & 0xFF;
    int alpha = in & 0xFF;
    return new int[] { red, green, blue, alpha };
  }






  
  public static int[] ARGBIntToRGBA(int in) {
    int alpha = in >> 24 & 0xFF;
    int red = in >> 16 & 0xFF;
    int green = in >> 8 & 0xFF;
    int blue = in & 0xFF;
    return new int[] { red, green, blue, alpha };
  }






  
  public static int[] RGBIntToRGB(int in) {
    int red = in >> 16 & 0xFF;
    int green = in >> 8 & 0xFF;
    int blue = in & 0xFF;
    return new int[] { red, green, blue };
  }





  
  public static float[] intArrayToFloatArray(int[] in) {
    Preconditions.checkArgument((in.length == 4), "Expected int[] of size 4, got " + in.length);
    for (int i = 0; i < in.length; i++) {
      Preconditions.checkArgument(validateColorRange(in[i]), "Expected in[" + i + "] to be 0-255, got " + in[i]);
    }
    return new float[] { in[0] / 255.0F, in[1] / 255.0F, in[2] / 255.0F, in[3] / 255.0F };
  }
  
  private static boolean validateColorRange(int in) {
    return (in >= 0 && in <= 255);
  }
}


