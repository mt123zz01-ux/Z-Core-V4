package com.zcore.client.utils.misc;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;
import net.minecraft.class_2499;
import net.minecraft.class_2520;


public class NbtUtils
{
  public static <T extends ISerializable<T>> class_2499 listToTag(List<T> list) {
    class_2499 nbtList = new class_2499();
    for (ISerializable iSerializable : list) {
      nbtList.add(iSerializable.toTag());
    }
    return nbtList;
  }
  
  public static <T> List<T> listFromTag(class_2499 list, Function<class_2520, T> mapper) {
    List<T> result = new ArrayList<>();
    for (class_2520 element : list) {
      T item = mapper.apply(element);
      if (item != null) {
        result.add(item);
      }
    } 
    return result;
  }
}


