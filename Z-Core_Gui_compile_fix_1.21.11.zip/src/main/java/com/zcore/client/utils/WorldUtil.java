package com.zcore.client.utils;

import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_742;

public final class WorldUtil {
  private static final class_310 mc = class_310.method_1551();
  
  public static boolean isDeadBodyNearby() {
    if (mc.field_1687 == null || mc.field_1724 == null) return false; 
    return mc.field_1687.method_18456().parallelStream()
      .filter(e -> (e != mc.field_1724))
      .filter(e -> (e.method_5858((class_1297)mc.field_1724) <= 36.0D))
      .anyMatch(class_1309::method_29504);
  }
  
  public static boolean isValuableLootNearby() {
    if (mc.field_1724 == null || mc.field_1687 == null) return false;
    
    class_238 area = new class_238(mc.field_1724.method_23317() - 10.0D, mc.field_1724.method_23318() - 5.0D, mc.field_1724.method_23321() - 10.0D, mc.field_1724.method_23317() + 10.0D, mc.field_1724.method_23318() + 5.0D, mc.field_1724.method_23321() + 10.0D);
    
    int valuableArmorCount = 0;
    List<class_1297> entities = mc.field_1687.method_8335(null, area);
    
    for (class_1297 entity : entities) {
      if (entity instanceof class_1542) { class_1542 itemEntity = (class_1542)entity;
        class_1799 stack = itemEntity.method_6983();
        if (stack.method_7960())
          continue; 
        if (stack.method_7909() instanceof net.minecraft.class_1738) {
          if (stack.method_7909() == class_1802.field_22027 || stack.method_7909() == class_1802.field_22028 || stack
            .method_7909() == class_1802.field_22029 || stack.method_7909() == class_1802.field_22030 || stack
            .method_7909() == class_1802.field_8805 || stack.method_7909() == class_1802.field_8058 || stack
            .method_7909() == class_1802.field_8348 || stack.method_7909() == class_1802.field_8285)
            valuableArmorCount++;  continue;
        } 
        if (stack.method_7947() > 32 && (
          stack.method_7909() == class_1802.field_8301 || stack.method_7909() == class_1802.field_8281 || stack
          .method_7909() == class_1802.field_8367 || stack.method_7909() == class_1802.field_8287)) {
          return true;
        } }
    
    } 
    
    return (valuableArmorCount >= 2);
  }
  
  public static void placeBlock(class_3965 blockHit, boolean swingHand) {
    if (mc.field_1761 == null || mc.field_1724 == null)
      return;  if (mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808, blockHit).method_23665() && swingHand) {
      mc.field_1724.method_6104(class_1268.field_5808);
    }
  }
  
  public static void hitEntity(class_1297 entity, boolean swingHand) {
    if (mc.field_1761 == null || mc.field_1724 == null)
      return;  mc.field_1761.method_2918((class_1657)mc.field_1724, entity);
    if (swingHand) {
      mc.field_1724.method_6104(class_1268.field_5808);
    }
  }
  
  public static double distance(class_243 from, class_243 to) {
    return from.method_1022(to);
  }
  
  public static boolean isTool(class_1799 itemStack) {
    class_1792 item = itemStack.method_7909();
    return (item == class_1802.field_8377 || item == class_1802.field_8556 || item == class_1802.field_8250 || item == class_1802.field_8527 || item == class_1802.field_8802 || item == class_1802.field_22024 || item == class_1802.field_22025 || item == class_1802.field_22023 || item == class_1802.field_22026 || item == class_1802.field_22022);
  }

  
  public static class_1657 findNearestPlayer(class_1657 sender, float radius, boolean seeOnly, boolean ignoreSelf) {
    if (mc.field_1687 == null) return null; 
    class_1657 target = null;
    double minDistance = radius;
    
    for (class_1657 player : mc.field_1687.method_18456()) {
      if ((ignoreSelf && player == sender) || 
        player.method_29504() || (
        seeOnly && !sender.method_6057((class_1297)player)))
        continue; 
      double distance = sender.method_5739((class_1297)player);
      if (distance < minDistance) {
        minDistance = distance;
        target = player;
      } 
    } 
    return target;
  }
  
  public static class_239 getHitResult(double distance) {
    if (mc.field_1724 == null) return null; 
    return mc.field_1724.method_5745(distance, 0.0F, false);
  }
}


