package com.zcore.client.utils.font.fonts;

import com.zcore.client.utils.font.util.RendererUtils;
import it.unimi.dsi.fastutil.chars.Char2ObjectArrayMap;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.font.FontRenderContext;
import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2960;
import net.minecraft.class_310;

class GlyphMap {
  final char fromIncl;
  final char toExcl;
  private final Char2ObjectArrayMap<Glyph> glyphs = new Char2ObjectArrayMap(); final Font[] font; final class_2960 bindToTexture; final int pixelPadding;
  int width;
  int height;
  boolean generated = false;
  
  public GlyphMap(char fromIncl, char toExcl, Font[] font, class_2960 bindToTexture, int pixelPadding) {
    this.fromIncl = fromIncl;
    this.toExcl = toExcl;
    this.font = font;
    this.bindToTexture = bindToTexture;
    this.pixelPadding = pixelPadding;
  }
  
  public Glyph getGlyph(char c) {
    if (!this.generated) {
      generate();
    }
    return (Glyph)this.glyphs.get(c);
  }
  
  public void destroy() {
    class_310.method_1551().method_1531().method_4615(this.bindToTexture);
    this.glyphs.clear();
    this.width = -1;
    this.height = -1;
    this.generated = false;
  }
  
  public boolean contains(char c) {
    return (c >= this.fromIncl && c < this.toExcl);
  }
  
  private Font getFontForGlyph(char c) {
    for (Font font1 : this.font) {
      if (font1.canDisplay(c)) {
        return font1;
      }
    } 
    return this.font[0];
  }
  
  public void generate() {
    if (this.generated) {
      return;
    }
    int range = this.toExcl - this.fromIncl - 1;
    int charsVert = (int)(Math.ceil(Math.sqrt(range)) * 1.5D);
    this.glyphs.clear();
    int generatedChars = 0;
    int charNX = 0;
    int maxX = 0, maxY = 0;
    int currentX = 0, currentY = 0;
    int currentRowMaxY = 0;
    List<Glyph> glyphs1 = new ArrayList<>();
    AffineTransform af = new AffineTransform();
    FontRenderContext frc = new FontRenderContext(af, true, false);
    while (generatedChars <= range) {
      char currentChar = (char)(this.fromIncl + generatedChars);
      Font font = getFontForGlyph(currentChar);
      Rectangle2D stringBounds = font.getStringBounds(String.valueOf(currentChar), frc);
      
      int width = (int)Math.ceil(stringBounds.getWidth());
      int height = (int)Math.ceil(stringBounds.getHeight());
      generatedChars++;
      maxX = Math.max(maxX, currentX + width);
      maxY = Math.max(maxY, currentY + height);
      if (charNX >= charsVert) {
        currentX = 0;
        currentY += currentRowMaxY + this.pixelPadding;
        charNX = 0;
        currentRowMaxY = 0;
      } 
      currentRowMaxY = Math.max(currentRowMaxY, height);
      glyphs1.add(new Glyph(currentX, currentY, width, height, currentChar, this));
      currentX += width + this.pixelPadding;
      charNX++;
    } 
    BufferedImage bi = new BufferedImage(Math.max(maxX + this.pixelPadding, 1), Math.max(maxY + this.pixelPadding, 1), 2);
    
    this.width = bi.getWidth();
    this.height = bi.getHeight();
    Graphics2D g2d = bi.createGraphics();
    g2d.setColor(new Color(255, 255, 255, 0));
    g2d.fillRect(0, 0, this.width, this.height);
    g2d.setColor(Color.WHITE);
    
    g2d.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS, RenderingHints.VALUE_FRACTIONALMETRICS_OFF);
    g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
    g2d.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
    
    for (Glyph glyph : glyphs1) {
      g2d.setFont(getFontForGlyph(glyph.value()));
      FontMetrics fontMetrics = g2d.getFontMetrics();
      g2d.drawString(String.valueOf(glyph.value()), glyph.u(), glyph.v() + fontMetrics.getAscent());
      this.glyphs.put(glyph.value(), glyph);
    } 
    
    RendererUtils.registerBufferedImageTexture(this.bindToTexture, bi);
    this.generated = true;
  }
}


