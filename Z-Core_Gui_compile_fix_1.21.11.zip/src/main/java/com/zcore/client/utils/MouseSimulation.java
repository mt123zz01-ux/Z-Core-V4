package com.zcore.client.utils;

import com.zcore.client.client.ZCoreClient;
import com.zcore.client.mixins.MinecraftClientAccessor;
import com.zcore.client.mixins.MouseAccessor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


public final class MouseSimulation
{
  private static final ExecutorService clickExecutor = Executors.newFixedThreadPool(2);
  
  public static void mouseClick(int button) {
    mouseClick(button, 35);
  }
  
  public static void mouseClick(int button, int millis) {
    clickExecutor.submit(() -> {
          try {
            mousePress(button);
            Thread.sleep(millis);
            mouseRelease(button);
          } catch (InterruptedException interruptedException) {}
        });
  }

  
  public static void mousePress(int button) {
    MouseAccessor mouse = (MouseAccessor)((MinecraftClientAccessor)ZCoreClient.mc).getMouse();
    mouse.invokeOnMouseButton(ZCoreClient.mc.method_22683().method_4490(), button, 1, 0);
  }
  
  public static void mouseRelease(int button) {
    MouseAccessor mouse = (MouseAccessor)((MinecraftClientAccessor)ZCoreClient.mc).getMouse();
    mouse.invokeOnMouseButton(ZCoreClient.mc.method_22683().method_4490(), button, 0, 0);
  }
}


