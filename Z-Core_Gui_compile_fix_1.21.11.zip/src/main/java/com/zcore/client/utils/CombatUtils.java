package com.zcore.client.utils;

import com.zcore.client.client.ZCoreClient;
import net.minecraft.class_1657;
import net.minecraft.class_243;

public class CombatUtils
{
  public static boolean isShieldFacingAway(class_1657 target) {
    if (ZCoreClient.mc.field_1724 == null || target == null) return false;
    
    class_243 playerPos = ZCoreClient.mc.field_1724.method_33571();
    class_243 targetPos = target.method_19538();
    
    class_243 toPlayer = playerPos.method_1020(targetPos);
    class_243 toPlayerHorizontal = new class_243(toPlayer.field_1352, 0.0D, toPlayer.field_1350);
    if (toPlayerHorizontal.method_1027() == 0.0D) return false; 
    toPlayerHorizontal = toPlayerHorizontal.method_1029();

    
    double yaw = Math.toRadians(target.method_36454());
    double pitch = Math.toRadians(target.method_36455());




    
    class_243 facing = (new class_243(-Math.sin(yaw) * Math.cos(pitch), -Math.sin(pitch), Math.cos(yaw) * Math.cos(pitch))).method_1029();
    
    double dot = facing.method_1026(toPlayerHorizontal);
    return (dot < 0.0D);
  }
}


