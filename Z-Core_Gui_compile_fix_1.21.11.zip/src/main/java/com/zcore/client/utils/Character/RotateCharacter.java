package com.zcore.client.utils.Character;

import java.util.Random;
import net.minecraft.class_310;
import net.minecraft.class_3532;


public class RotateCharacter
{
  private final class_310 mc;
  private final Random random = new Random();
  private boolean isRotating = false;
  private float targetYaw;
  private float targetPitch;
  private Runnable onComplete;
  
  public RotateCharacter(class_310 mc) {
    this.mc = mc;
  }
  
  public void rotate(float yaw, float pitch, Runnable onComplete) {
    this.targetYaw = yaw;
    this.targetPitch = pitch;
    this.onComplete = onComplete;
    this.isRotating = true;
  }
  
  public void update(boolean human, boolean fast) {
    if (!this.isRotating || this.mc.field_1724 == null)
      return; 
    float currentYaw = this.mc.field_1724.method_36454();
    float currentPitch = this.mc.field_1724.method_36455();

    
    float jitterYaw = human ? ((this.random.nextFloat() - 0.5F) * 0.1F) : 0.0F;
    float jitterPitch = human ? ((this.random.nextFloat() - 0.5F) * 0.1F) : 0.0F;
    
    float yawDiff = class_3532.method_15393(this.targetYaw + jitterYaw - currentYaw);
    float pitchDiff = this.targetPitch + jitterPitch - currentPitch;
    
    float speed = fast ? 3.5F : 1.2F;
    
    if (human) {
      
      float distance = (float)Math.sqrt((yawDiff * yawDiff + pitchDiff * pitchDiff));
      float easeFactor = Math.min(1.0F, distance / 25.0F);

      
      float fluctuation = (this.random.nextFloat() - 0.5F) * 0.4F;
      speed = (0.3F + 1.2F * easeFactor + fluctuation) * (fast ? 2.5F : 1.0F);

      
      if (distance > 10.0F && this.random.nextFloat() < 0.02F) {
        speed *= 0.05F;
      }
    } 
    
    float maxStep = Math.max(0.1F, speed);
    
    float deltaYaw = class_3532.method_15363(yawDiff, -maxStep, maxStep);
    float deltaPitch = class_3532.method_15363(pitchDiff, -maxStep, maxStep);

    
    float finalYaw = currentYaw + deltaYaw;
    float finalPitch = currentPitch + deltaPitch;
    
    this.mc.field_1724.method_36456(finalYaw);
    this.mc.field_1724.method_36457(class_3532.method_15363(finalPitch, -90.0F, 90.0F));
    
    if (Math.abs(yawDiff) < 0.3F && Math.abs(pitchDiff) < 0.3F) {
      this.mc.field_1724.method_36456(this.targetYaw);
      this.mc.field_1724.method_36457(class_3532.method_15363(this.targetPitch, -90.0F, 90.0F));
      this.isRotating = false;
      if (this.onComplete != null) this.onComplete.run();
    
    } 
  }
  
  public boolean isActive() {
    return this.isRotating;
  }
}


