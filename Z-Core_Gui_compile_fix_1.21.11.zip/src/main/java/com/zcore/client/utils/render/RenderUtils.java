package com.zcore.client.utils.render;

import com.mojang.blaze3d.systems.RenderSystem;
import com.zcore.client.client.ZCoreClient;
import com.zcore.client.utils.MathUtils;
import net.minecraft.class_10142;
import net.minecraft.class_10366;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_8685;
import org.joml.Matrix4f;

public final class RenderUtils
{
  public static void unscaledProjection() {
    RenderSystem.setProjectionMatrix((new Matrix4f()).setOrtho(0.0F, ZCoreClient.mc.method_22683().method_4489(), ZCoreClient.mc.method_22683().method_4506(), 0.0F, 1000.0F, 21000.0F), class_10366.field_54954);
  }
  
  public static void scaledProjection() {
    RenderSystem.setProjectionMatrix((new Matrix4f()).setOrtho(0.0F, (float)(ZCoreClient.mc.method_22683().method_4489() / ZCoreClient.mc.method_22683().method_4495()), (float)(ZCoreClient.mc.method_22683().method_4506() / ZCoreClient.mc.method_22683().method_4495()), 0.0F, 1000.0F, 21000.0F), class_10366.field_54954);
  }
  
  public static void customScaledProjection(double scale) {
    RenderSystem.setProjectionMatrix((new Matrix4f()).setOrtho(0.0F, (float)(ZCoreClient.mc.method_22683().method_4489() / scale), (float)(ZCoreClient.mc.method_22683().method_4506() / scale), 0.0F, 1000.0F, 21000.0F), class_10366.field_54954);
  }
  
  public static void fillRect(class_332 context, int x, int y, int w, int h, int color) {
    class_287 buf = getBuffer(class_293.class_5596.field_27382, class_290.field_1576);
    Matrix4f mat = context.method_51448().method_23760().method_23761();
    
    buf.method_22918(mat, x, y, 0.0F).method_39415(color);
    buf.method_22918(mat, (x + w), y, 0.0F).method_39415(color);
    buf.method_22918(mat, (x + w), (y + h), 0.0F).method_39415(color);
    buf.method_22918(mat, x, (y + h), 0.0F).method_39415(color);
    
    beginRendering();
    drawBuffer(buf);
    finishRendering();
  }
  
  public static void fillRadialGradient(class_332 context, int cX, int cY, int radius, int innerColor, int outerColor) {
    class_287 buf = getBuffer(class_293.class_5596.field_27381, class_290.field_1576);
    Matrix4f mat = context.method_51448().method_23760().method_23761();
    
    buf.method_22918(mat, cX, cY, 0.0F).method_39415(innerColor);
    
    for (int i = 0; i <= 360; i += 10) {
      double angle = Math.toRadians(i);
      float x = (float)(Math.cos(angle) * radius) + cX;
      float y = (float)(Math.sin(angle) * radius) + cY;
      buf.method_22918(mat, x, y, 0.0F).method_39415(outerColor);
    } 
    
    beginRendering();
    drawBuffer(buf);
    finishRendering();
  }
  
  public static void fillSidewaysGradient(class_332 context, int x, int y, int w, int h, int colorLeft, int colorRight) {
    class_287 buf = getBuffer(class_293.class_5596.field_27382, class_290.field_1576);
    Matrix4f mat = context.method_51448().method_23760().method_23761();
    
    buf.method_22918(mat, x, y, 0.0F).method_39415(colorLeft);
    buf.method_22918(mat, x, (y + h), 0.0F).method_39415(colorLeft);
    buf.method_22918(mat, (x + w), (y + h), 0.0F).method_39415(colorRight);
    buf.method_22918(mat, (x + w), y, 0.0F).method_39415(colorRight);
    
    beginRendering();
    drawBuffer(buf);
    finishRendering();
  }
  
  public static void fillSidewaysGradient(class_332 context, int x, int y, int w, int h, int... colors) {
    int amount = colors.length;
    if (amount == 0)
      return; 
    if (amount == 1) {
      fillRect(context, x, y, w, h, colors[0]); return;
    } 
    if (amount == 2) {
      fillSidewaysGradient(context, x, y, w, h, colors[0], colors[1]);
      
      return;
    } 
    Matrix4f mat = context.method_51448().method_23760().method_23761();
    class_287 buf = getBuffer(class_293.class_5596.field_27380, class_290.field_1576);
    int sectionLen = w / (amount - 1);
    
    for (int i = 0; i < amount; i++) {
      int color = colors[i];
      int tx = x + i * sectionLen;
      
      buf.method_22918(mat, tx, y, 0.0F).method_39415(color);
      buf.method_22918(mat, tx, (y + h), 0.0F).method_39415(color);
    } 
    buf.method_22918(mat, (x + w), y, 0.0F).method_39415(colors[amount - 1]);
    buf.method_22918(mat, (x + w), (y + h), 0.0F).method_39415(colors[amount - 1]);
    
    beginRendering();
    drawBuffer(buf);
    finishRendering();
  }
  
  public static void fillVerticalGradient(class_332 context, int x, int y, int w, int h, int colorTop, int colorBottom) {
    class_287 buf = getBuffer(class_293.class_5596.field_27382, class_290.field_1576);
    Matrix4f mat = context.method_51448().method_23760().method_23761();
    
    buf.method_22918(mat, x, y, 0.0F).method_39415(colorTop);
    buf.method_22918(mat, (x + w), y, 0.0F).method_39415(colorTop);
    buf.method_22918(mat, (x + w), (y + h), 0.0F).method_39415(colorBottom);
    buf.method_22918(mat, x, (y + h), 0.0F).method_39415(colorBottom);
    
    beginRendering();
    drawBuffer(buf);
    finishRendering();
  }
  
  public static void fillVerticalGradient(class_332 context, int x, int y, int w, int h, int... colors) {
    int amount = colors.length;
    if (amount == 0)
      return; 
    if (amount == 1) {
      fillRect(context, x, y, w, h, colors[0]); return;
    } 
    if (amount == 2) {
      fillVerticalGradient(context, x, y, w, h, colors[0], colors[1]);
      
      return;
    } 
    Matrix4f mat = context.method_51448().method_23760().method_23761();
    class_287 buf = getBuffer(class_293.class_5596.field_27380, class_290.field_1576);
    int sectionLen = h / (amount - 1);
    
    for (int i = 0; i < amount; i++) {
      int color = colors[i];
      int ty = y + i * sectionLen;
      
      buf.method_22918(mat, x, ty, 0.0F).method_39415(color);
      buf.method_22918(mat, (x + w), ty, 0.0F).method_39415(color);
    } 
    buf.method_22918(mat, x, (y + h), 0.0F).method_39415(colors[amount - 1]);
    buf.method_22918(mat, (x + w), (y + h), 0.0F).method_39415(colors[amount - 1]);
    
    beginRendering();
    drawBuffer(buf);
    finishRendering();
  }
  
  public static void fillAnnulusArcGradient(class_332 context, int cx, int cy, int radius, int start, int end, int thickness, int innerColor, int outerColor) {
    class_287 buf = getBuffer(class_293.class_5596.field_27380, class_290.field_1576);
    Matrix4f mat = context.method_51448().method_23760().method_23761();
    
    for (int i = start - 90; i <= end - 90; i++) {
      float angle = (float)Math.toRadians(i);
      float cos = (float)Math.cos(angle);
      float sin = (float)Math.sin(angle);
      float x1 = cx + cos * radius;
      float y1 = cy + sin * radius;
      float x2 = cx + cos * (radius + thickness);
      float y2 = cy + sin * (radius + thickness);
      buf.method_22918(mat, x1, y1, 0.0F).method_39415(innerColor);
      buf.method_22918(mat, x2, y2, 0.0F).method_39415(outerColor);
    } 
    
    beginRendering();
    drawBuffer(buf);
    finishRendering();
  }
  
  public static void fillArc(class_332 context, int cX, int cY, int radius, int start, int end, int color) {
    class_287 buf = getBuffer(class_293.class_5596.field_27381, class_290.field_1576);
    Matrix4f mat = context.method_51448().method_23760().method_23761();
    
    buf.method_22918(mat, cX, cY, 0.0F).method_39415(color);
    
    for (int i = start - 90; i <= end - 90; i++) {
      double angle = Math.toRadians(i);
      float x = (float)(Math.cos(angle) * radius) + cX;
      float y = (float)(Math.sin(angle) * radius) + cY;
      buf.method_22918(mat, x, y, 0.0F).method_39415(color);
    } 
    
    beginRendering();
    drawBuffer(buf);
    finishRendering();
  }
  
  public static void fillCircle(class_332 context, int cX, int cY, int radius, int color) {
    fillArc(context, cX, cY, radius, 0, 360, color);
  }
  
  public static void fillAnnulusArc(class_332 context, int cx, int cy, int radius, int start, int end, int thickness, int color) {
    class_287 buf = getBuffer(class_293.class_5596.field_27380, class_290.field_1576);
    Matrix4f mat = context.method_51448().method_23760().method_23761();
    
    for (int i = start - 90; i <= end - 90; i++) {
      float angle = (float)Math.toRadians(i);
      float cos = (float)Math.cos(angle);
      float sin = (float)Math.sin(angle);
      float x1 = cx + cos * radius;
      float y1 = cy + sin * radius;
      float x2 = cx + cos * (radius + thickness);
      float y2 = cy + sin * (radius + thickness);
      buf.method_22918(mat, x1, y1, 0.0F).method_39415(color);
      buf.method_22918(mat, x2, y2, 0.0F).method_39415(color);
    } 
    
    beginRendering();
    drawBuffer(buf);
    finishRendering();
  }
  
  public static void fillAnnulus(class_332 context, int cx, int cy, int radius, int thickness, int color) {
    fillAnnulusArc(context, cx, cy, radius, 0, 360, thickness, color);
  }
  
  public static void fillRoundRect(class_332 context, int x, int y, int w, int h, int r, int color) {
    r = MathUtils.clamp(r, 0, Math.min(w, h) / 2);
    
    class_287 buf = getBuffer(class_293.class_5596.field_27381, class_290.field_1576);
    Matrix4f mat = context.method_51448().method_23760().method_23761();
    
    buf.method_22918(mat, x + w / 2.0F, y + h / 2.0F, 0.0F).method_39415(color);
    
    int[][] corners = { { x + w - r, y + r }, { x + w - r, y + h - r }, { x + r, y + h - r }, { x + r, y + r } };





    
    for (int corner = 0; corner < 4; corner++) {
      int cornerStart = (corner - 1) * 90;
      int cornerEnd = cornerStart + 90;
      for (int i = cornerStart; i <= cornerEnd; i += 10) {
        float angle = (float)Math.toRadians(i);
        float rx = corners[corner][0] + (float)(Math.cos(angle) * r);
        float ry = corners[corner][1] + (float)(Math.sin(angle) * r);
        buf.method_22918(mat, rx, ry, 0.0F).method_39415(color);
      } 
    } 
    
    buf.method_22918(mat, corners[0][0], y, 0.0F).method_39415(color);
    
    beginRendering();
    drawBuffer(buf);
    finishRendering();
  }



  
  public static void fillRoundRect(class_332 context, int x, int y, int w, int h, int topLeft, int topRight, int bottomRight, int bottomLeft, int color) {
    topLeft = MathUtils.clamp(topLeft, 0, Math.min(w, h) / 2);
    topRight = MathUtils.clamp(topRight, 0, Math.min(w, h) / 2);
    bottomRight = MathUtils.clamp(bottomRight, 0, Math.min(w, h) / 2);
    bottomLeft = MathUtils.clamp(bottomLeft, 0, Math.min(w, h) / 2);
    
    class_287 buf = getBuffer(class_293.class_5596.field_27381, class_290.field_1576);
    Matrix4f mat = context.method_51448().method_23760().method_23761();

    
    buf.method_22918(mat, x + w / 2.0F, y + h / 2.0F, 0.0F).method_39415(color);

    
    buf.method_22918(mat, (x + topLeft), y, 0.0F).method_39415(color);
    buf.method_22918(mat, (x + w - topRight), y, 0.0F).method_39415(color);
    
    int i;
    for (i = -90; i <= 0; i += 2) {
      float angle = (float)Math.toRadians(i);
      float rx = (x + w - topRight) + (float)Math.cos(angle) * topRight;
      float ry = (y + topRight) + (float)Math.sin(angle) * topRight;
      buf.method_22918(mat, rx, ry, 0.0F).method_39415(color);
    } 

    
    buf.method_22918(mat, (x + w), (y + topRight), 0.0F).method_39415(color);
    buf.method_22918(mat, (x + w), (y + h - bottomRight), 0.0F).method_39415(color);

    
    for (i = 0; i <= 90; i += 2) {
      float angle = (float)Math.toRadians(i);
      float rx = (x + w - bottomRight) + (float)Math.cos(angle) * bottomRight;
      float ry = (y + h - bottomRight) + (float)Math.sin(angle) * bottomRight;
      buf.method_22918(mat, rx, ry, 0.0F).method_39415(color);
    } 

    
    buf.method_22918(mat, (x + w - bottomRight), (y + h), 0.0F).method_39415(color);
    buf.method_22918(mat, (x + bottomLeft), (y + h), 0.0F).method_39415(color);

    
    for (i = 90; i <= 180; i += 10) {
      float angle = (float)Math.toRadians(i);
      float rx = (x + bottomLeft) + (float)Math.cos(angle) * bottomLeft;
      float ry = (y + h - bottomLeft) + (float)Math.sin(angle) * bottomLeft;
      buf.method_22918(mat, rx, ry, 0.0F).method_39415(color);
    } 

    
    buf.method_22918(mat, x, (y + h - bottomLeft), 0.0F).method_39415(color);
    buf.method_22918(mat, x, (y + topLeft), 0.0F).method_39415(color);

    
    for (i = 180; i <= 270; i += 10) {
      float angle = (float)Math.toRadians(i);
      float rx = (x + topLeft) + (float)Math.cos(angle) * topLeft;
      float ry = (y + topLeft) + (float)Math.sin(angle) * topLeft;
      buf.method_22918(mat, rx, ry, 0.0F).method_39415(color);
    } 

    
    buf.method_22918(mat, (x + topLeft), y, 0.0F).method_39415(color);
    
    beginRendering();
    drawBuffer(buf);
    finishRendering();
  }
  
  public static void fillRoundTabTop(class_332 context, int x, int y, int w, int h, int r, int color) {
    class_287 buf = getBuffer(class_293.class_5596.field_27381, class_290.field_1576);
    Matrix4f mat = context.method_51448().method_23760().method_23761();
    
    buf.method_22918(mat, x + w / 2.0F, y + h / 2.0F, 0.0F).method_39415(color);
    
    int[][] corners = { { x + r, y + r }, { x + w - r, y + r } };



    
    for (int corner = 0; corner < 2; corner++) {
      int cornerStart = (corner - 2) * 90;
      int cornerEnd = cornerStart + 90;
      for (int i = cornerStart; i <= cornerEnd; i += 10) {
        float angle = (float)Math.toRadians(i);
        float rx = corners[corner][0] + (float)(Math.cos(angle) * r);
        float ry = corners[corner][1] + (float)(Math.sin(angle) * r);
        buf.method_22918(mat, rx, ry, 0.0F).method_39415(color);
      } 
    } 
    
    buf.method_22918(mat, (x + w), (y + h), 0.0F).method_39415(color);
    buf.method_22918(mat, x, (y + h), 0.0F).method_39415(color);
    buf.method_22918(mat, x, corners[0][1], 0.0F).method_39415(color);
    
    beginRendering();
    drawBuffer(buf);
    finishRendering();
  }
  
  public static void fillRoundTabBottom(class_332 context, int x, int y, int w, int h, int r, int color) {
    class_287 buf = getBuffer(class_293.class_5596.field_27381, class_290.field_1576);
    Matrix4f mat = context.method_51448().method_23760().method_23761();
    
    buf.method_22918(mat, x + w / 2.0F, y + h / 2.0F, 0.0F).method_39415(color);
    
    int[][] corners = { { x + w - r, y + h - r }, { x + r, y + h - r } };



    
    for (int corner = 0; corner < 2; corner++) {
      int cornerStart = corner * 90;
      int cornerEnd = cornerStart + 90;
      for (int i = cornerStart; i <= cornerEnd; i += 10) {
        float angle = (float)Math.toRadians(i);
        float rx = corners[corner][0] + (float)(Math.cos(angle) * r);
        float ry = corners[corner][1] + (float)(Math.sin(angle) * r);
        buf.method_22918(mat, rx, ry, 0.0F).method_39415(color);
      } 
    } 
    
    buf.method_22918(mat, x, y, 0.0F).method_39415(color);
    buf.method_22918(mat, (x + w), y, 0.0F).method_39415(color);
    buf.method_22918(mat, (x + w), corners[0][1], 0.0F).method_39415(color);
    
    beginRendering();
    drawBuffer(buf);
    finishRendering();
  }
  
  public static void fillRoundHoriLine(class_332 context, int x, int y, int length, int thickness, int color) {
    fillRoundRect(context, x, y, length, thickness, thickness / 2, color);
  }
  
  public static void fillRoundVertLine(class_332 context, int x, int y, int length, int thickness, int color) {
    fillRoundRect(context, x, y, thickness, length, thickness / 2, color);
  }

  
  public static void drawRect(class_332 context, int x, int y, int w, int h, int color) {
    drawHorLine(context, x, y, w, color);
    drawVerLine(context, x, y + 1, h - 2, color);
    drawVerLine(context, x + w - 1, y + 1, h - 2, color);
    drawHorLine(context, x, y + h - 1, w, color);
  }
  
  public static void drawBox(class_332 context, int x, int y, int w, int h, int color) {
    drawLine(context, x, y, x + w, y, color);
    drawLine(context, x, y + h, x + w, y + h, color);
    drawLine(context, x, y, x, y + h, color);
    drawLine(context, x + w, y, x + w, y + h, color);
  }
  
  public static void drawHorLine(class_332 context, int x, int y, int length, int color) {
    fillRect(context, x, y, length, 1, color);
  }
  
  public static void drawVerLine(class_332 context, int x, int y, int length, int color) {
    fillRect(context, x, y, 1, length, color);
  }
  
  public static void drawLine(class_332 context, int x1, int y1, int x2, int y2, int color) {
    class_287 buf = getBuffer(class_293.class_5596.field_29344, class_290.field_1576);
    Matrix4f mat = context.method_51448().method_23760().method_23761();
    
    buf.method_22918(mat, x1, y1, 0.0F).method_39415(color);
    buf.method_22918(mat, x2, y2, 0.0F).method_39415(color);
    
    beginRendering();
    drawBuffer(buf);
    finishRendering();
  }
  
  public static void drawArc(class_332 context, int cX, int cY, int radius, int start, int end, int color) {
    class_287 buf = getBuffer(class_293.class_5596.field_29345, class_290.field_1576);
    Matrix4f mat = context.method_51448().method_23760().method_23761();
    
    for (int i = start - 90; i <= end - 90; i++) {
      double angle = Math.toRadians(i);
      float x = (float)(Math.cos(angle) * radius) + cX;
      float y = (float)(Math.sin(angle) * radius) + cY;
      buf.method_22918(mat, x, y, 0.0F).method_39415(color);
    } 
    
    beginRendering();
    drawBuffer(buf);
    finishRendering();
  }
  
  public static void drawCircle(class_332 context, int cX, int cY, int radius, int color) {
    drawArc(context, cX, cY, radius, 0, 360, color);
  }
  
  public static void drawRoundRect(class_332 context, int x, int y, int w, int h, int r, int color) {
    r = MathUtils.clamp(r, 0, Math.min(w, h) / 2);
    
    class_287 buf = getBuffer(class_293.class_5596.field_29345, class_290.field_1576);
    Matrix4f mat = context.method_51448().method_23760().method_23761();
    
    int[][] corners = { { x + w - r, y + r }, { x + w - r, y + h - r }, { x + r, y + h - r }, { x + r, y + r } };





    
    for (int corner = 0; corner < 4; corner++) {
      int cornerStart = (corner - 1) * 90;
      int cornerEnd = cornerStart + 90;
      for (int i = cornerStart; i <= cornerEnd; i += 10) {
        float angle = (float)Math.toRadians(i);
        float rx = corners[corner][0] + (float)(Math.cos(angle) * r);
        float ry = corners[corner][1] + (float)(Math.sin(angle) * r);
        buf.method_22918(mat, rx, ry, 0.0F).method_39415(color);
      } 
    } 
    
    buf.method_22918(mat, corners[0][0], y, 0.0F).method_39415(color);
    
    beginRendering();
    drawBuffer(buf);
    finishRendering();
  }
  
  public static void drawRoundHoriLine(class_332 context, int x, int y, int length, int thickness, int color) {
    drawRoundRect(context, x, y, length, thickness, thickness / 2, color);
  }
  
  public static void drawRoundVertLine(class_332 context, int x, int y, int length, int thickness, int color) {
    drawRoundRect(context, x, y, thickness, length, thickness / 2, color);
  }
  
  public static void drawTextureQuad(class_332 context, class_2960 texture, int x, int y, int w, int h) {
    class_287 buf = getBuffer(class_293.class_5596.field_27382, class_290.field_1585);
    Matrix4f mat = context.method_51448().method_23760().method_23761();
    
    buf.method_22918(mat, x, y, 0.0F).method_22913(0.0F, 0.0F);
    buf.method_22918(mat, (x + w), y, 0.0F).method_22913(1.0F, 0.0F);
    buf.method_22918(mat, (x + w), (y + h), 0.0F).method_22913(1.0F, 1.0F);
    buf.method_22918(mat, x, (y + h), 0.0F).method_22913(0.0F, 1.0F);
    
    RenderSystem.disableCull();
    RenderSystem.enableBlend();
    RenderSystem.defaultBlendFunc();
    RenderSystem.setShader(class_10142.field_53879);
    RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
    RenderSystem.setShaderTexture(0, texture);
    
    drawBuffer(buf);
    
    RenderSystem.enableCull();
    RenderSystem.disableBlend();
  }
  
  public static void drawRoundTexture(class_332 context, class_2960 texture, int x, int y, int w, int h, int r) {
    r = MathUtils.clamp(r, 0, Math.min(w, h) / 2);
    
    class_287 buf = getBuffer(class_293.class_5596.field_27381, class_290.field_1585);
    Matrix4f mat = context.method_51448().method_23760().method_23761();
    
    buf.method_22918(mat, x + w / 2.0F, y + h / 2.0F, 0.0F).method_22913(0.5F, 0.5F);
    
    int[][] corners = { { x + w - r, y + r }, { x + w - r, y + h - r }, { x + r, y + h - r }, { x + r, y + r } };





    
    for (int corner = 0; corner < 4; corner++) {
      int cornerStart = (corner - 1) * 90;
      int cornerEnd = cornerStart + 90;
      for (int i = cornerStart; i <= cornerEnd; i += 10) {
        float angle = (float)Math.toRadians(i);
        float rx = corners[corner][0] + (float)(Math.cos(angle) * r);
        float ry = corners[corner][1] + (float)(Math.sin(angle) * r);
        float u = (rx - x) / w;
        float v = (ry - y) / h;
        buf.method_22918(mat, rx, ry, 0.0F).method_22913(u, v);
      } 
    } 
    
    buf.method_22918(mat, corners[0][0], y, 0.0F).method_22913((corners[0][0] - x) / w, 0.0F);
    
    RenderSystem.disableCull();
    RenderSystem.setShader(class_10142.field_53879);
    RenderSystem.setShaderTexture(0, texture);
    RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
    
    drawBuffer(buf);
    
    RenderSystem.enableCull();
  }
  
  public static void drawCircleTexture(class_332 context, class_2960 texture, int x, int y, int size) {
    int radius = size / 2;
    
    class_287 buf = getBuffer(class_293.class_5596.field_27381, class_290.field_1585);
    Matrix4f mat = context.method_51448().method_23760().method_23761();
    
    buf.method_22918(mat, x, y, 0.0F).method_22913(0.5F, 0.5F);
    for (int i = 0; i <= 360; i += 10) {
      float angle = (float)Math.toRadians(i);
      float cos = (float)Math.cos(angle) * radius + x;
      float sin = (float)Math.sin(angle) * radius + y;
      float tu = (cos - x + radius) / size;
      float tv = (sin - y + radius) / size;
      buf.method_22918(mat, cos, sin, 0.0F).method_22913(tu, tv);
    } 
    
    RenderSystem.disableCull();
    RenderSystem.enableBlend();
    RenderSystem.defaultBlendFunc();
    RenderSystem.setShader(class_10142.field_53879);
    RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
    RenderSystem.setShaderTexture(0, texture);
    
    drawBuffer(buf);
    
    RenderSystem.enableCull();
    RenderSystem.disableBlend();
  }
  
  public static void drawCirclePlayerHead(class_332 context, class_8685 texture, int x, int y, int size) {
    int radius = size / 2;
    float u = 0.125F;
    float v = 0.125F;
    
    class_287 buf = getBuffer(class_293.class_5596.field_27381, class_290.field_1585);
    Matrix4f mat = context.method_51448().method_23760().method_23761();
    
    buf.method_22918(mat, x, y, 0.0F).method_22913(0.5F * u + u, 0.5F * v + v); int i;
    for (i = 0; i <= 360; i += 10) {
      float angle = (float)Math.toRadians(i);
      float cos = (float)Math.cos(angle) * radius + x;
      float sin = (float)Math.sin(angle) * radius + y;
      float tu = (cos - x + radius) / size;
      float tv = (sin - y + radius) / size;
      buf.method_22918(mat, cos, sin, 0.0F).method_22913(tu * u + u, tv * v + v);
    } 
    
    RenderSystem.disableCull();
    RenderSystem.enableBlend();
    RenderSystem.defaultBlendFunc();
    RenderSystem.setShader(class_10142.field_53879);
    RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
    RenderSystem.setShaderTexture(0, texture.comp_1626());
    
    drawBuffer(buf);
    
    RenderSystem.enableCull();
    RenderSystem.disableBlend();
    
    buf = getBuffer(class_293.class_5596.field_27381, class_290.field_1585);
    buf.method_22918(mat, x, y, 0.006942F).method_22913(0.5F * u + u * 5.0F, 0.5F * v + v);
    for (i = 0; i <= 360; i += 10) {
      float angle = (float)Math.toRadians(i);
      float cos = (float)Math.cos(angle) * radius + x;
      float sin = (float)Math.sin(angle) * radius + y;
      float tu = (cos - x + radius) / size;
      float tv = (sin - y + radius) / size;
      buf.method_22918(mat, cos, sin, 0.006942F).method_22913(tu * u + u * 5.0F, tv * v + v);
    } 
    
    RenderSystem.disableCull();
    RenderSystem.enableBlend();
    RenderSystem.defaultBlendFunc();
    RenderSystem.setShader(class_10142.field_53879);
    RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
    RenderSystem.setShaderTexture(0, texture.comp_1626());
    
    drawBuffer(buf);
    
    RenderSystem.enableCull();
    RenderSystem.disableBlend();
  }
  
  public static void drawRoundedPlayerHead(class_332 context, class_8685 texture, int x, int y, int size, int r) {
    r = MathUtils.clamp(r, 0, size / 2);
    
    float u = 0.125F;
    float v = 0.125F;
    int[][] corners = { { x + size - r, y + r }, { x + size - r, y + size - r }, { x + r, y + size - r }, { x + r, y + r } };





    
    class_287 buf = getBuffer(class_293.class_5596.field_27381, class_290.field_1585);
    Matrix4f mat = context.method_51448().method_23760().method_23761();
    
    buf.method_22918(mat, x + size / 2.0F, y + size / 2.0F, 0.0F).method_22913(0.5F * u + u, 0.5F * v + v); int corner;
    for (corner = 0; corner < 4; corner++) {
      int cornerStart = (corner - 1) * 90;
      int cornerEnd = cornerStart + 90;
      for (int i = cornerStart; i <= cornerEnd; i += 10) {
        float angle = (float)Math.toRadians(i);
        float rx = corners[corner][0] + (float)(Math.cos(angle) * r);
        float ry = corners[corner][1] + (float)(Math.sin(angle) * r);
        float tu = (rx - x) / size * u + u;
        float tv = (ry - y) / size * v + v;
        buf.method_22918(mat, rx, ry, 0.0F).method_22913(tu, tv);
      } 
    } 
    buf.method_22918(mat, corners[0][0], y, 0.0F).method_22913((corners[0][0] - x) / size * u + u, 0.0F * v + v);
    
    RenderSystem.disableCull();
    RenderSystem.enableBlend();
    RenderSystem.defaultBlendFunc();
    RenderSystem.setShader(class_10142.field_53879);
    RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
    RenderSystem.setShaderTexture(0, texture.comp_1626());
    
    drawBuffer(buf);
    
    RenderSystem.enableCull();
    RenderSystem.disableBlend();
    
    buf = getBuffer(class_293.class_5596.field_27381, class_290.field_1585);
    buf.method_22918(mat, x + size / 2.0F, y + size / 2.0F, 0.0F).method_22913(0.5F * u + u * 5.0F, 0.5F * v + v);
    for (corner = 0; corner < 4; corner++) {
      int cornerStart = (corner - 1) * 90;
      int cornerEnd = cornerStart + 90;
      for (int i = cornerStart; i <= cornerEnd; i += 10) {
        float angle = (float)Math.toRadians(i);
        float rx = corners[corner][0] + (float)(Math.cos(angle) * r);
        float ry = corners[corner][1] + (float)(Math.sin(angle) * r);
        float tu = (rx - x) / size * u + u * 5.0F;
        float tv = (ry - y) / size * v + v;
        buf.method_22918(mat, rx, ry, 0.0F).method_22913(tu, tv);
      } 
    } 
    buf.method_22918(mat, corners[0][0], y, 0.0F).method_22913((corners[0][0] - x) / size * u + u * 5.0F, 0.0F * v + v);
    
    RenderSystem.disableCull();
    RenderSystem.enableBlend();
    RenderSystem.defaultBlendFunc();
    RenderSystem.setShader(class_10142.field_53879);
    RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
    RenderSystem.setShaderTexture(0, texture.comp_1626());
    
    drawBuffer(buf);
    
    RenderSystem.enableCull();
    RenderSystem.disableBlend();
  }

  
  public static void beginRendering() {
    RenderSystem.disableCull();
    RenderSystem.enableBlend();
    RenderSystem.defaultBlendFunc();
    RenderSystem.setShader(class_10142.field_53876);
    RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
  }
  
  public static void finishRendering() {
    RenderSystem.enableCull();
    RenderSystem.disableBlend();
    RenderSystem.setShader(class_10142.field_53879);
  }
  
  public static void check(boolean check, String msg) {
    if (!check) {
      throw new IllegalArgumentException(msg);
    }
  }
  
  public static void drawBuffer(class_287 buf) {
    class_286.method_43433(buf.method_60800());
  }
  
  public static class_287 getBuffer(class_293.class_5596 drawMode, class_293 format) {
    return class_289.method_1348().method_60827(drawMode, format);
  }
}


