package com.zcore.client.utils.font.fonts;

record Glyph(int u, int v, int width, int height, char value, GlyphMap owner) {}
