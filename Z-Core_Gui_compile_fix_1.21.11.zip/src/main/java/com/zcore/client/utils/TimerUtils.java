package com.zcore.client.utils;

public class TimerUtils
{
  private long lastTime = 0L;
  
  public boolean delay(float delay) {
    return delay(delay);
  }
  
  public boolean delay(double delay) {
    long currentTime = System.currentTimeMillis();
    if ((currentTime - this.lastTime) >= delay) {
      reset();
      return true;
    } 
    return false;
  }
  
  public void reset() {
    this.lastTime = System.currentTimeMillis();
  }
  
  public long getElapsedTime() {
    return System.currentTimeMillis() - this.lastTime;
  }
  
  public boolean hasElapsedTime(long delay) {
    return (getElapsedTime() >= delay);
  }
  
  public long getLastTime() {
    return this.lastTime;
  }
}


