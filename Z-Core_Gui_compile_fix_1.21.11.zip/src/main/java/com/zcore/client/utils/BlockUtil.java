package com.zcore.client.utils;

import com.zcore.client.client.ZCoreClient;
import java.util.Objects;
import java.util.stream.Stream;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1923;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2769;
import net.minecraft.class_2818;
import net.minecraft.class_3965;
import net.minecraft.class_4969;



public final class BlockUtil
{
  public static Stream<class_2818> getLoadedChunks() {
    int radius = Math.max(2, ZCoreClient.mc.field_1690.method_38521()) + 3;
    int diameter = radius * 2 + 1;
    
    class_1923 center = ZCoreClient.mc.field_1724.method_31476();
    class_1923 min = new class_1923(center.field_9181 - radius, center.field_9180 - radius);
    class_1923 max = new class_1923(center.field_9181 + radius, center.field_9180 + radius);
    
    return Stream.<class_1923>iterate(min, pos -> {
          int x = pos.field_9181;
          
          int z = pos.field_9180;
          
          if (++x > max.field_9181) {
            x = min.field_9181;
            z++;
          } 
          if (z > max.field_9180) {
            throw new IllegalStateException("Stream limit didn't work.");
          }
          return new class_1923(x, z);
        }).limit(diameter * diameter)
      .filter(c -> ZCoreClient.mc.field_1687.method_8393(c.field_9181, c.field_9180))
      .map(c -> ZCoreClient.mc.field_1687.method_8497(c.field_9181, c.field_9180)).filter(Objects::nonNull);
  }
  
  public static boolean isAnchorCharged(class_2338 pos) {
    if (isBlockAtPosition(pos, class_2246.field_23152)) {
      return (((Integer)ZCoreClient.mc.field_1687.method_8320(pos).method_11654((class_2769)class_4969.field_23153)).intValue() != 0);
    }
    return false;
  }
  
  public static boolean isAnchorNotCharged(class_2338 pos) {
    if (isBlockAtPosition(pos, class_2246.field_23152)) {
      return (((Integer)ZCoreClient.mc.field_1687.method_8320(pos).method_11654((class_2769)class_4969.field_23153)).intValue() == 0);
    }
    return false;
  }
  
  public static boolean isBlockAtPosition(class_2338 blockPos, class_2248 block) {
    return (ZCoreClient.mc.field_1687.method_8320(blockPos).method_26204() == block);
  }
  
  public static void interactWithBlock(class_3965 blockHitResult, boolean shouldSwingHand) {
    class_1269 result = ZCoreClient.mc.field_1761.method_2896(ZCoreClient.mc.field_1724, class_1268.field_5808, blockHitResult);
    if (result.method_23665() && shouldSwingHand)
      ZCoreClient.mc.field_1724.method_6104(class_1268.field_5808); 
  }
}


