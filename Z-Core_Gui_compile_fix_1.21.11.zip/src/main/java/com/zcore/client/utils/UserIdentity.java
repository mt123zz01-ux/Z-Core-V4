package com.zcore.client.utils;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.FileAttribute;
import java.util.UUID;
import net.fabricmc.loader.api.FabricLoader;

public class UserIdentity
{
  private static final String FILE_NAME = "zcore_id.txt";
  private static UUID cachedId;
  private static String cachedDiscordId;
  
  public static String getOrCreateId() {
    if (cachedId != null) return cachedId.toString(); 
    Path configDir = FabricLoader.getInstance().getConfigDir().resolve("zcore");
    Path idFile = configDir.resolve("zcore_id.txt");
    
    try {
      if (!Files.exists(configDir, new java.nio.file.LinkOption[0])) Files.createDirectories(configDir, (FileAttribute<?>[])new FileAttribute[0]); 
      if (Files.exists(idFile, new java.nio.file.LinkOption[0])) {
        cachedId = UUID.fromString(Files.readString(idFile).trim());
      } else {
        cachedId = UUID.randomUUID();
        Files.writeString(idFile, cachedId.toString(), new java.nio.file.OpenOption[0]);
      } 
    } catch (Exception e) {
      cachedId = UUID.randomUUID();
    } 
    return cachedId.toString();
  }


  
  public static String getDiscordId() {
    if (cachedDiscordId != null) {
      return cachedDiscordId;
    }

    
    cachedDiscordId = "123456789012345678";
    
    return cachedDiscordId;
  }
}


