package com.zcore.client.utils;

import com.zcore.client.client.ZCoreClient;
import com.zcore.client.modules.Module;
import com.zcore.client.modules.client.ClickGUI;
import net.minecraft.class_2390;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import net.minecraft.class_2400;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_638;
import org.joml.Vector3f;

public class ParticleUtils {
  private static final class_310 mc = class_310.method_1551();
  
  private static ClickGUI getClickGUI() {
    if (ZCoreClient.getModuleManager() == null) return null; 
    return (ClickGUI)ZCoreClient.getModuleManager().getModule(ClickGUI.class);
  }
  
  private static int getParticleCount() {
    return 12;
  }
  
  private static double getParticleSpread() {
    return 0.3D;
  }



  
  public static void spawnSuccessParticles(Module module) {
    if (mc.field_1724 == null || mc.field_1687 == null)
      return; 
    class_243 pos = mc.field_1724.method_19538().method_1031(0.0D, mc.field_1724.method_18381(mc.field_1724.method_18376()), 0.0D);
    double spread = getParticleSpread();
    int count = getParticleCount();

    
    spawnParticleBurst((class_2394)class_2398.field_11211, pos, spread, spread, spread, count);

    
    spawnColoredDustBurst(pos, 0.0F, 1.0F, 0.0F, (int)(count * 0.7D));
  }



  
  public static void spawnDisableParticles(Module module) {
    if (mc.field_1724 == null || mc.field_1687 == null)
      return; 
    class_243 pos = mc.field_1724.method_19538().method_1031(0.0D, mc.field_1724.method_18381(mc.field_1724.method_18376()), 0.0D);
    double spread = getParticleSpread();
    int count = getParticleCount();

    
    spawnColoredDustBurst(pos, 1.0F, 0.0F, 0.0F, count);

    
    spawnParticleBurst((class_2394)class_2398.field_11251, pos, spread * 0.7D, spread * 0.7D, spread * 0.7D, (int)(count * 0.6D));
  }



  
  public static void spawnCategoryParticles(Module module, boolean enabled) {
    if (enabled) {
      spawnCategorySuccessParticles(module);
    } else {
      spawnCategoryDisableParticles(module);
    } 
  } private static void spawnCategorySuccessParticles(Module module) {
    class_2400 class_24005, class_24004, class_24003, class_24002, class_24001;
    Vector3f color;
    if (mc.field_1724 == null || mc.field_1687 == null)
      return; 
    class_243 pos = mc.field_1724.method_19538().method_1031(0.0D, mc.field_1724.method_18381(mc.field_1724.method_18376()), 0.0D);

    
    double spread = getParticleSpread();
    int count = getParticleCount();
    
    switch (module.getCategory()) {
      
      case COMBAT:
        class_24005 = class_2398.field_11205;
        color = new Vector3f(1.0F, 0.2F, 0.2F);
        spawnParticleBurst((class_2394)class_24005, pos, spread, spread, spread, count);
        spawnColoredDustBurst(pos, color.x, color.y, color.z, (int)(count * 0.7D));
        return;

      
      case VISUAL:
        class_24004 = class_2398.field_11215;
        color = new Vector3f(0.2F, 0.8F, 1.0F);
        spawnParticleBurst((class_2394)class_24004, pos, spread, spread, spread, count);
        spawnColoredDustBurst(pos, color.x, color.y, color.z, (int)(count * 0.7D));
        return;

      
      case MISC:
        class_24003 = class_2398.field_11211;
        color = new Vector3f(1.0F, 0.8F, 0.2F);
        spawnParticleBurst((class_2394)class_24003, pos, spread, spread, spread, count);
        spawnColoredDustBurst(pos, color.x, color.y, color.z, (int)(count * 0.7D));
        return;

      
      case DONUT:
        class_24002 = class_2398.field_11249;
        color = new Vector3f(0.8F, 0.2F, 1.0F);
        spawnParticleBurst((class_2394)class_24002, pos, spread, spread, spread, count);
        spawnColoredDustBurst(pos, color.x, color.y, color.z, (int)(count * 0.7D));
        return;

      
      case CLIENT:
        class_24001 = class_2398.field_11220;
        color = new Vector3f(1.0F, 0.9F, 0.6F);
        spawnParticleBurst((class_2394)class_24001, pos, spread, spread, spread, count);
        spawnColoredDustBurst(pos, color.x, color.y, color.z, (int)(count * 0.8D));
        return;
    } 

    
    spawnSuccessParticles(module);
  }

  
  private static void spawnCategoryDisableParticles(Module module) {
    Vector3f color;
    if (mc.field_1724 == null || mc.field_1687 == null)
      return; 
    class_243 pos = mc.field_1724.method_19538().method_1031(0.0D, mc.field_1724.method_18381(mc.field_1724.method_18376()), 0.0D);
    
    double spread = getParticleSpread();
    int count = getParticleCount();
    
    switch (module.getCategory()) {
      case COMBAT:
        color = new Vector3f(0.7F, 0.1F, 0.1F);
        break;
      case VISUAL:
        color = new Vector3f(0.1F, 0.5F, 0.7F);
        break;
      case MISC:
        color = new Vector3f(0.7F, 0.5F, 0.1F);
        break;
      case DONUT:
        color = new Vector3f(0.5F, 0.1F, 0.7F);
        break;
      case CLIENT:
        color = new Vector3f(0.6F, 0.5F, 0.4F);
        break;
      default:
        color = new Vector3f(1.0F, 0.0F, 0.0F);
        break;
    } 
    
    spawnColoredDustBurst(pos, color.x, color.y, color.z, count);
    spawnParticleBurst((class_2394)class_2398.field_11251, pos, spread * 0.7D, spread * 0.7D, spread * 0.7D, (int)(count * 0.5D));
  }



  
  private static void spawnParticleBurst(class_2394 particle, class_243 pos, double spreadX, double spreadY, double spreadZ, int count) {
    class_638 world = mc.field_1687;
    if (world == null)
      return; 
    for (int i = 0; i < count; i++) {
      double offsetX = (Math.random() - 0.5D) * spreadX * 2.0D;
      double offsetY = (Math.random() - 0.5D) * spreadY * 2.0D;
      double offsetZ = (Math.random() - 0.5D) * spreadZ * 2.0D;
      
      double velocityX = (Math.random() - 0.5D) * 0.1D;
      double velocityY = (Math.random() - 0.5D) * 0.1D;
      double velocityZ = (Math.random() - 0.5D) * 0.1D;
      
      world.method_8406(particle, pos.field_1352 + offsetX, pos.field_1351 + offsetY, pos.field_1350 + offsetZ, velocityX, velocityY, velocityZ);
    } 
  }









  
  private static void spawnColoredDustBurst(class_243 pos, float r, float g, float b, int count) {
    class_638 world = mc.field_1687;
    if (world == null)
      return; 
    int colorInt = (int)(r * 255.0F) << 16 | (int)(g * 255.0F) << 8 | (int)(b * 255.0F);
    class_2390 dustEffect = new class_2390(colorInt, 1.0F);
    
    for (int i = 0; i < count; i++) {
      double offsetX = (Math.random() - 0.5D) * 0.6D;
      double offsetY = (Math.random() - 0.5D) * 0.6D;
      double offsetZ = (Math.random() - 0.5D) * 0.6D;
      
      double velocityX = (Math.random() - 0.5D) * 0.15D;
      double velocityY = (Math.random() - 0.5D) * 0.15D;
      double velocityZ = (Math.random() - 0.5D) * 0.15D;
      
      world.method_8406((class_2394)dustEffect, pos.field_1352 + offsetX, pos.field_1351 + offsetY, pos.field_1350 + offsetZ, velocityX, velocityY, velocityZ);
    } 
  }
}


