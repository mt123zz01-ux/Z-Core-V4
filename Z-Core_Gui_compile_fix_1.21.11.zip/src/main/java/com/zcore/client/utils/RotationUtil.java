package com.zcore.client.utils;

import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;

public class RotationUtil
{
  private static final class_310 mc = class_310.method_1551();
  
  private static boolean usingSilentRotation = false;
  
  private static float silentYaw = 0.0F;
  private static float silentPitch = 0.0F;
  private static float previousYaw = 0.0F;
  private static float previousPitch = 0.0F;

  
  public static float[] getRotationsTo(class_243 from, class_243 to) {
    double diffX = to.field_1352 - from.field_1352;
    double diffY = to.field_1351 - from.field_1351;
    double diffZ = to.field_1350 - from.field_1350;
    
    double distance = Math.sqrt(diffX * diffX + diffZ * diffZ);
    
    float yaw = (float)(Math.atan2(diffZ, diffX) * 180.0D / Math.PI) - 90.0F;
    float pitch = (float)-(Math.atan2(diffY, distance) * 180.0D / Math.PI);
    
    return new float[] { yaw, pitch };
  }

  
  public static float[] getRotationsToEntity(class_1297 entity) {
    if (mc.field_1724 == null) {
      return new float[] { 0.0F, 0.0F };
    }
    return getRotationsTo(mc.field_1724.method_33571(), entity.method_19538().method_1031(0.0D, (entity.method_17682() / 2.0F), 0.0D));
  }

  
  public static float[] getRotationsTo(class_243 to) {
    if (mc.field_1724 == null) {
      return new float[] { 0.0F, 0.0F };
    }
    return getRotationsTo(mc.field_1724.method_33571(), to);
  }

  
  public static void setSilentRotation(float yaw, float pitch) {
    if (mc.field_1724 == null)
      return; 
    if (!usingSilentRotation) {
      previousYaw = mc.field_1724.method_36454();
      previousPitch = mc.field_1724.method_36455();
      usingSilentRotation = true;
    } 
    
    silentYaw = normalizeYaw(yaw);
    silentPitch = class_3532.method_15363(pitch, -90.0F, 90.0F);
  }



  
  public static void resetSilentRotation() {
    if (mc.field_1724 == null || !usingSilentRotation)
      return; 
    mc.field_1724.method_36456(previousYaw);
    mc.field_1724.method_36457(previousPitch);
    
    usingSilentRotation = false;
    silentYaw = 0.0F;
    silentPitch = 0.0F;
  }

  
  public static float getSilentYaw() {
    if (usingSilentRotation) {
      return silentYaw;
    }
    return (mc.field_1724 != null) ? mc.field_1724.method_36454() : 0.0F;
  }

  
  public static float getSilentPitch() {
    if (usingSilentRotation) {
      return silentPitch;
    }
    return (mc.field_1724 != null) ? mc.field_1724.method_36455() : 0.0F;
  }

  
  public static boolean isUsingSilentRotation() {
    return usingSilentRotation;
  }

  
  public static float normalizeYaw(float yaw) {
    yaw %= 360.0F;
    if (yaw >= 180.0F) {
      yaw -= 360.0F;
    }
    if (yaw < -180.0F) {
      yaw += 360.0F;
    }
    return yaw;
  }

  
  public static float getAngleDifference(float a, float b) {
    float diff = Math.abs(a - b) % 360.0F;
    if (diff > 180.0F) {
      diff = 360.0F - diff;
    }
    return diff;
  }

  
  public static float smoothRotate(float current, float target, float speed) {
    float diff = normalizeYaw(target - current);
    
    if (Math.abs(diff) <= speed) {
      return target;
    }
    
    if (diff > 0.0F) {
      return current + speed;
    }
    return current - speed;
  }



  
  public static float[] smoothRotate(float currentYaw, float currentPitch, float targetYaw, float targetPitch, float speed) {
    float newYaw = smoothRotate(currentYaw, targetYaw, speed);
    float newPitch = smoothRotate(currentPitch, targetPitch, speed);
    return new float[] { newYaw, newPitch };
  }

  
  public static boolean isLookingAt(class_243 pos, float threshold) {
    if (mc.field_1724 == null) return false;
    
    float[] targetRotation = getRotationsTo(pos);
    float yawDiff = getAngleDifference(mc.field_1724.method_36454(), targetRotation[0]);
    float pitchDiff = getAngleDifference(mc.field_1724.method_36455(), targetRotation[1]);
    
    return (yawDiff <= threshold && pitchDiff <= threshold);
  }

  
  public static boolean isLookingAtEntity(class_1297 entity, float threshold) {
    if (mc.field_1724 == null) return false;
    
    float[] targetRotation = getRotationsToEntity(entity);
    float yawDiff = getAngleDifference(mc.field_1724.method_36454(), targetRotation[0]);
    float pitchDiff = getAngleDifference(mc.field_1724.method_36455(), targetRotation[1]);
    
    return (yawDiff <= threshold && pitchDiff <= threshold);
  }

  
  public static float getRotationDistance(class_243 pos) {
    if (mc.field_1724 == null) return 0.0F;
    
    float[] targetRotation = getRotationsTo(pos);
    float yawDiff = getAngleDifference(mc.field_1724.method_36454(), targetRotation[0]);
    float pitchDiff = getAngleDifference(mc.field_1724.method_36455(), targetRotation[1]);
    
    return (float)Math.sqrt((yawDiff * yawDiff + pitchDiff * pitchDiff));
  }
}


