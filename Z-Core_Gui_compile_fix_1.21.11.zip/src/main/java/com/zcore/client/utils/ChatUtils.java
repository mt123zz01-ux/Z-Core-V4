package com.zcore.client.utils;

import com.zcore.client.client.ZCoreClient;
import com.zcore.client.modules.Module;
import net.minecraft.class_2561;





public final class ChatUtils
{
  public static void m(String message) {
    send(buildPrefix() + "§f" + buildPrefix());
  }
  
  public static void w(String message) {
    send(buildPrefix() + "§e" + buildPrefix());
  }
  
  public static void e(String message) {
    send(buildPrefix() + "§c" + buildPrefix());
  }
  
  private static void send(String fullMessage) {
    if (ZCoreClient.mc != null && ZCoreClient.mc.field_1724 != null) {
      ZCoreClient.mc.field_1724.method_7353((class_2561)class_2561.method_43470(fullMessage), false);
    }
  }
  
  private static String buildPrefix() {
    String moduleName = inferCallerModuleName();
    if (moduleName == null || moduleName.isEmpty()) moduleName = "General"; 
    return "§d[Z-Core+] §b" + moduleName + " §f| ";
  }
  
  private static String inferCallerModuleName() {
    StackTraceElement[] stack = Thread.currentThread().getStackTrace();
    for (StackTraceElement element : stack) {
      String className = element.getClassName();
      if (className != null && 
        className.startsWith("com.zcore.client.modules.")) {
        try {
          Class<?> clazz = Class.forName(className);
          if (Module.class.isAssignableFrom(clazz)) {
            String simple = clazz.getSimpleName();
            
            if (ZCoreClient.getModuleManager() != null) {
              for (Module mod : ZCoreClient.getModuleManager().getModules()) {
                if (mod != null && mod.getClass() == clazz) {
                  return mod.getName();
                }
              } 
            }
            return simple;
          } 
        } catch (Throwable throwable) {}
      }
    } 
    return null;
  }
}


