package com.zcore.client.utils;
import net.minecraft.class_1109;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1921;
import net.minecraft.class_1935;
import net.minecraft.class_2960;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_3417;
import net.minecraft.class_368;
import net.minecraft.class_374;

public class ToastUtil implements class_368 {
  private static final class_2960 TEXTURE = class_2960.method_60656("toast/advancement");

  
  private static final int DEFAULT_DURATION_MS = 5000;

  
  private final class_1799 displayItem;
  
  private final String title;
  
  private final String message;
  
  private final boolean playSound;
  
  private boolean soundPlayed;
  
  private class_368.class_369 visibility;

  
  public ToastUtil(class_1935 item, String title, String message, boolean playSound) {
    this.visibility = class_368.class_369.field_2210;
    this.displayItem = new class_1799(item);
    this.title = title;
    this.message = message;
    this.playSound = playSound; } public class_368.class_369 method_61988() { return this.visibility; }
   public ToastUtil(String title, String message, boolean playSound) {
    this((class_1935)class_1802.field_8106, title, message, playSound);
  }
  public void method_61989(class_374 manager, long startTime) {
    if (this.playSound && !this.soundPlayed) {
      manager.method_1995().method_1483().method_4873(
          (class_1113)class_1109.method_4758(class_3417.field_14627, 1.0F));


      
      this.soundPlayed = true;
    } 
    
    if (startTime >= 5000.0D * manager.method_48221()) {
      this.visibility = class_368.class_369.field_2209;
    }
  }

  
  public void method_1986(class_332 context, class_327 textRenderer, long startTime) {
    context.method_52706(class_1921::method_62277, TEXTURE, 0, 0, method_29049(), method_29050());
    context.method_51433(textRenderer, this.title, 30, 7, -256, false);
    context.method_51433(textRenderer, this.message, 30, 18, -1, false);
    context.method_51427(this.displayItem, 8, 8);
  }
}


