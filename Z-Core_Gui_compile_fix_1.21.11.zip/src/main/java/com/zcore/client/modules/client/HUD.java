package com.zcore.client.modules.client;

import com.zcore.client.gui.settings.BooleanSetting;
import com.zcore.client.modules.Module;

public class HUD extends Module {
    public final BooleanSetting watermark = new BooleanSetting("Watermark", true);
    public HUD() {
        super("HUD", "Simple HUD placeholder for the GUI editor.", Category.CLIENT);
        addSetting(watermark);
    }
}
