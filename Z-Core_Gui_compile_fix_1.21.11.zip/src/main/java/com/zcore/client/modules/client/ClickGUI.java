package com.zcore.client.modules.client;

import com.zcore.client.client.ZCoreClient;
import com.zcore.client.gui.ClickGuiScreen;
import com.zcore.client.gui.settings.BooleanSetting;
import com.zcore.client.gui.settings.DoubleSetting;
import com.zcore.client.modules.Module;
import org.lwjgl.glfw.GLFW;

public class ClickGUI extends Module {
    public final BooleanSetting blur = new BooleanSetting("Blur", false);
    public final BooleanSetting glow = new BooleanSetting("Glow", true);
    public final BooleanSetting icons = new BooleanSetting("Icons", true);
    public final BooleanSetting toastNotifications = new BooleanSetting("Toast Notifications", false);
    public final BooleanSetting rounded = new BooleanSetting("Rounded Corners", true);
    public final DoubleSetting guiOpacity = new DoubleSetting("GUI Opacity", 90.0, 20.0, 100.0, 1.0);

    public ClickGUI() {
        super("Z-Core", "Open the Z-Core click GUI.", Category.CLIENT);
        setKeyBind(GLFW.GLFW_KEY_P);
        addSetting(blur);
        addSetting(glow);
        addSetting(icons);
        addSetting(rounded);
        addSetting(guiOpacity);
        addSetting(toastNotifications);
    }

    public boolean isRounded() {
        return rounded.getValue();
    }

    @Override
    public void onEnable() {
        if (ZCoreClient.mc != null) {
            ZCoreClient.mc.execute(() -> ZCoreClient.mc.method_1507(new ClickGuiScreen()));
        }
        setEnabled(false);
    }
}
