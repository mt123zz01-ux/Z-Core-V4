package com.zcore.client.modules.client;

import com.zcore.client.gui.settings.ColorSetting;
import com.zcore.client.gui.settings.DoubleSetting;
import com.zcore.client.modules.Module;
import java.awt.Color;

public class Themes extends Module {
    public final ColorSetting accent = new ColorSetting("Accent", new Color(255, 80, 120));
    public final DoubleSetting opacity = new DoubleSetting("Opacity", 90.0, 20.0, 100.0, 1.0);

    public Themes() {
        super("Themes", "Z-Core theme controls.", Category.CLIENT);
        addSetting(accent);
        addSetting(opacity);
    }
}
