package com.zcore.client.modules.client;

import com.zcore.client.gui.settings.BooleanSetting;
import com.zcore.client.gui.settings.DoubleSetting;
import com.zcore.client.gui.settings.StringSetting;
import com.zcore.client.modules.Module;

public class DemoModule extends Module {
    public DemoModule(String name, String description, Category category) {
        super(name, description, category);
        addSetting(new BooleanSetting("Enabled Option", true));
        addSetting(new DoubleSetting("Amount", 50.0, 0.0, 100.0, 1.0));
        addSetting(new StringSetting("Label", name));
    }
}
