package com.zcore.client.modules;

import com.zcore.client.gui.settings.Setting;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_310;

public class Module {
    public enum Category { CLIENT, COMBAT, MISC, VISUAL, DONUT }

    protected static class_310 mc = class_310.method_1551();
    private final String name;
    private final String description;
    private final Category category;
    private boolean enabled;
    private int keyBind = -1;
    private final List<Setting<?>> settings = new ArrayList<>();

    public Module(String name, String description, Category category) {
        this.name = name;
        this.description = description;
        this.category = category;
    }

    public String getName() { return name; }
    public String getDescription() { return description; }
    public Category getCategory() { return category; }
    public boolean isEnabled() { return enabled; }
    public int getKeyBind() { return keyBind; }
    public void setKeyBind(int keyBind) { this.keyBind = keyBind; }
    public List<Setting<?>> getSettings() { return settings; }
    public void addSetting(Setting<?> setting) { if (setting != null) settings.add(setting); }

    public void toggle() {
        enabled = !enabled;
        if (enabled) onEnable(); else onDisable();
    }

    public void setEnabled(boolean enabled) {
        if (this.enabled != enabled) toggle();
    }

    public void onEnable() {}
    public void onDisable() {}
    public void onTick() {}
}
