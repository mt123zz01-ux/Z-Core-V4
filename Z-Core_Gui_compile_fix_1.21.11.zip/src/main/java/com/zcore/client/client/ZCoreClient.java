package com.zcore.client.client;

import com.zcore.client.events.EventManager;
import com.zcore.client.modules.Module;
import com.zcore.client.modules.client.ClickGUI;
import com.zcore.client.modules.client.DemoModule;
import com.zcore.client.modules.client.HUD;
import com.zcore.client.modules.client.Themes;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.class_310;

public final class ZCoreClient {
    public static ModuleManager moduleManager;
    public static ConfigManager configManager;
    public static EventManager eventManager;
    public static KeybindManager keybindManager;
    public static class_310 mc;
    public static volatile ZCoreClient instance;
    private static ClickGUI clickGui;

    public ZCoreClient() {
        instance = this;
        initialize();
    }

    public static ZCoreClient getInstance() { return instance; }
    public static ModuleManager getModuleManager() { return moduleManager; }
    public static EventManager getEventManager() { return eventManager; }
    public static ConfigManager getConfigManager() { return configManager; }
    public static KeybindManager getKeybindManager() { return keybindManager; }
    public static ClickGUI getClickGui() { return clickGui; }
    public static void sendKeepAliveIfAllowed() {}

    private void initialize() {
        mc = class_310.method_1551();
        moduleManager = new ModuleManager();
        configManager = new ConfigManager();
        eventManager = new EventManager();
        keybindManager = new KeybindManager();

        clickGui = new ClickGUI();
        moduleManager.register(clickGui);
        moduleManager.register(new Themes());
        moduleManager.register(new HUD());

        // Clean placeholder modules so the GUI has real categories to display.
        moduleManager.register(new DemoModule("Combat Example", "Placeholder module for the Combat tab.", Module.Category.COMBAT));
        moduleManager.register(new DemoModule("Misc Example", "Placeholder module for the Misc tab.", Module.Category.MISC));
        moduleManager.register(new DemoModule("Visual Example", "Placeholder module for the Visual tab.", Module.Category.VISUAL));
        moduleManager.register(new DemoModule("Donut Example", "Placeholder module for the Donut tab.", Module.Category.DONUT));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (moduleManager != null) moduleManager.tick();
            if (keybindManager != null) keybindManager.handleKeybinds();
        });

        configManager.loadProfile();
    }
}
