package com.zcore.client.client;

import com.zcore.client.modules.Module;
import com.zcore.client.modules.client.ClickGUI;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import net.minecraft.class_310;
import net.minecraft.class_437;
import org.lwjgl.glfw.GLFW;

public class KeybindManager
{
  private static final int MOUSE_BUTTON_OFFSET = 1000;
  private final Map<Integer, Boolean> keyStates = new HashMap<>();
  private final class_310 mc = class_310.method_1551();



  
  public static String getKeyName(int keyCode) {
    if (keyCode <= 0) return "None";
    
    if (keyCode >= 1000) {
      return getMouseButtonName(keyCode - 1000);
    }
    
    switch (keyCode) {
      case 32:
        return "Space";
      case 256:
        return "Escape";
      case 257:
        return "Enter";
      case 258:
        return "Tab";
      case 259:
        return "Backspace";
      case 260:
        return "Insert";
      case 261:
        return "Delete";
      case 262:
        return "Right Arrow";
      case 263:
        return "Left Arrow";
      case 264:
        return "Down Arrow";
      case 265:
        return "Up Arrow";
      case 266:
        return "Page Up";
      case 267:
        return "Page Down";
      case 268:
        return "Home";
      case 269:
        return "End";
      case 280:
        return "Caps Lock";
      case 281:
        return "Scroll Lock";
      case 282:
        return "Num Lock";
      case 283:
        return "Print Screen";
      case 284:
        return "Pause";
      case 340:
        return "Left Shift";
      case 341:
        return "Left Ctrl";
      case 342:
        return "Left Alt";
      case 343:
        return "Left Super";
      case 80:
        return "Right Shift";
      case 345:
        return "Right Ctrl";
      case 346:
        return "Right Alt";
      case 347:
        return "Right Super";
    } 
    
    if (keyCode >= 290 && keyCode <= 314) {
      return "F" + keyCode - 290 + 1;
    }
    
    if (keyCode >= 320 && keyCode <= 329) {
      return "Numpad " + keyCode - 320;
    }
    
    if (keyCode >= 65 && keyCode <= 90) {
      return String.valueOf((char)keyCode);
    }
    
    if (keyCode >= 48 && keyCode <= 57) {
      return String.valueOf((char)keyCode);
    }
    
    switch (keyCode) { case 59: 
      case 61: 
      case 44: 
      case 45: 
      case 46: 
      case 47: 
      case 96: 
      case 91: 
      case 92: 
      case 93:
      
      case 39:
       }  return "Unknown (" + keyCode + ")";
  }


  
  private static String getMouseButtonName(int mouseButton) {
    switch (mouseButton) { case 0: 
      case 1: 
      case 2: 
      case 3: 
      case 4: 
      case 5: 
      case 6:
      
      case 7:
       }  return "Mouse " + mouseButton + 1;
  }

  
  public static int getMouseButtonKeyCode(int mouseButton) {
    return 1000 + mouseButton;
  }
  
  public static boolean isMouseButton(int keyCode) {
    return (keyCode >= 1000);
  }
  
  public static int getMouseButtonFromKeyCode(int keyCode) {
    if (isMouseButton(keyCode)) {
      return keyCode - 1000;
    }
    return -1;
  }
  
  public void checkKeybinds() {
    if (ZCoreClient.moduleManager == null) {
      return;
    }
    for (Module module : ZCoreClient.moduleManager.getModules()) {
      int keyCode = module.getKeyBind();
      if (keyCode > 0) {
        if (module.getName().equals("Z-Core")) {
          checkKey(keyCode, module);
        } else if (this.mc.field_1755 == null) {
          checkKey(keyCode, module);
        } 
      }
      if (keyCode <= 0 && module instanceof ClickGUI) {
        module.setKeyBind(80);
      }
    } 
  }

  
  private void checkKey(int keyCode, Module module) {
    if (module == null || this.mc == null) {
      return;
    }
    
    boolean currentState = (keyCode >= 1000) ? isMouseButtonPressed(keyCode - 1000) : isKeyPressed(keyCode);
    
    boolean previousState = ((Boolean)this.keyStates.getOrDefault(Integer.valueOf(keyCode), Boolean.valueOf(false))).booleanValue();
    
    if (module instanceof ClickGUI) { ClickGUI gui = (ClickGUI)module;
      int activeKey = (gui.getKeyBind() > 0) ? gui.getKeyBind() : 80;
      boolean activePressed = isKeyPressed(activeKey);
      boolean activePrevious = ((Boolean)this.keyStates.getOrDefault(Integer.valueOf(activeKey), Boolean.valueOf(false))).booleanValue();
      
      if (activePressed && !activePrevious) {
        this.mc.execute(() -> {
              class_437 screen = this.mc.field_1755;
              
              if (!(screen instanceof com.zcore.client.gui.ClickGuiScreen)) {
                gui.updateGuiScreen();
                if (gui.currentGuiScreen != null && gui.canOpenGUI()) {
                  this.mc.method_1507(gui.currentGuiScreen);
                }
              } else {
                try {
                  screen.method_25419();
                } catch (Exception exception) {}
              } 
            });
      }
      
      this.keyStates.put(Integer.valueOf(activeKey), Boolean.valueOf(activePressed)); }
    
    else if (currentState && !previousState)
    { module.toggle(); }

    
    this.keyStates.put(Integer.valueOf(keyCode), Boolean.valueOf(currentState));
  }
  
  private boolean isKeyPressed(int keyCode) {
    if (this.mc.method_22683() == null) return false;
    
    try {
      return (GLFW.glfwGetKey(this.mc.method_22683().method_4490(), keyCode) == 1);
    } catch (Exception e) {
      return false;
    } 
  }
  
  private boolean isMouseButtonPressed(int mouseButton) {
    if (this.mc.method_22683() == null) return false;
    
    try {
      return (GLFW.glfwGetMouseButton(this.mc.method_22683().method_4490(), mouseButton) == 1);
    } catch (Exception e) {
      return false;
    } 
  }
  
  public void autoAssignKeybinds() {
    if (ZCoreClient.moduleManager == null)
      return; 
    Set<Integer> usedKeys = new HashSet<>();
    for (Module module : ZCoreClient.moduleManager.getModules()) {
      if (module.getKeyBind() != -1) {
        usedKeys.add(Integer.valueOf(module.getKeyBind()));
      }
    } 
    
    usedKeys.add(Integer.valueOf(80));













    
    int[] defaultKeys = { 66, 67, 71, 72, 74, 75, 76, 77, 78, 79, 80, 81, 82, 85, 86, 88, 89, 90, 290, 291, 292, 293, 294, 295, 296, 297, 298, 299, 300, 301, getMouseButtonKeyCode(3), getMouseButtonKeyCode(4), getMouseButtonKeyCode(5), getMouseButtonKeyCode(6), getMouseButtonKeyCode(7) };

    
    int keyIndex = 0;
    for (Module module : ZCoreClient.moduleManager.getModules()) {
      if (module.getKeyBind() == -1 && keyIndex < defaultKeys.length) {
        while (keyIndex < defaultKeys.length && usedKeys.contains(Integer.valueOf(defaultKeys[keyIndex]))) {
          keyIndex++;
        }
        
        if (keyIndex < defaultKeys.length) {
          module.setKeyBind(defaultKeys[keyIndex]);
          usedKeys.add(Integer.valueOf(defaultKeys[keyIndex]));
          keyIndex++;
        } 
      } 
    } 
  }
}


