package com.zcore.client.client;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_1044;
import net.minecraft.class_2960;
import net.minecraft.class_310;

public class CapeManager {
  private final List<class_2960> availableCapes = new ArrayList<>();
  private final File customCapeDir = new File("config/zcore/capes");

  
  private class_2960 selectedCape;

  
  public void loadCapes() {
    if (class_310.method_1551().method_1531() == null)
      return;  this.availableCapes.clear();
    
    if (!this.customCapeDir.exists()) {
      this.customCapeDir.mkdirs();
    }
    
    File[] files = this.customCapeDir.listFiles((dir, name) -> name.toLowerCase().endsWith(".png"));
    if (files == null)
      return; 
    for (File file : files) {
      try {
        String validFileName = file.getName().toLowerCase().replaceAll("[^a-z0-9/._-]", "_");
        class_2960 id = class_2960.method_60655("zcore_capes", validFileName);
        
        if (!this.availableCapes.contains(id))
        
        { FileInputStream stream = new FileInputStream(file); 
          try { class_1011 image = class_1011.method_4309(stream);
            class_1043 texture = new class_1043(image);
            class_310.method_1551().method_1531().method_4616(id, (class_1044)texture);
            this.availableCapes.add(id);
            stream.close(); } catch (Throwable throwable) { try { stream.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  } 
      } catch (Exception e) {
        e.printStackTrace();
      } 
    } 
    
    if (this.selectedCape == null && !this.availableCapes.isEmpty()) {
      this.selectedCape = this.availableCapes.get(0);
    }
  }
  
  public List<class_2960> getAvailableCapes() {
    if (this.availableCapes.isEmpty()) loadCapes(); 
    return this.availableCapes;
  }
  
  public class_2960 getSelectedCape() {
    if (this.availableCapes.isEmpty()) loadCapes(); 
    return this.selectedCape;
  }
  
  public void setSelectedCape(class_2960 selectedCape) {
    this.selectedCape = selectedCape;
  }
}


