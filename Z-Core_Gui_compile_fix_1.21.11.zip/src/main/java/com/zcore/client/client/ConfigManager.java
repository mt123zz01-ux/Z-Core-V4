package com.zcore.client.client;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.zcore.client.gui.settings.BooleanSetting;
import com.zcore.client.gui.settings.DoubleSetting;
import com.zcore.client.gui.settings.EnchantmentSetting;
import com.zcore.client.gui.settings.ItemSetting;
import com.zcore.client.gui.settings.KeybindSetting;
import com.zcore.client.gui.settings.ModeSetting;
import com.zcore.client.gui.settings.NumberSetting;
import com.zcore.client.gui.settings.Setting;
import com.zcore.client.gui.settings.StringListSetting;
import com.zcore.client.gui.settings.StringSetting;
import com.zcore.client.modules.Module;
import com.zcore.client.modules.client.ClickGUI;
import java.awt.Color;
import java.io.File;
import java.io.FileWriter;
import java.util.List;
import net.minecraft.class_1792;
import net.minecraft.class_1887;
import net.minecraft.class_2960;
import net.minecraft.class_5321;

public class ConfigManager {
  private JsonObject profile;
  
  public ConfigManager() {
    if (ZCoreClient.mc != null) {
      File zcoreDir = new File(ZCoreClient.mc.field_1697, "zcore");
      if (!zcoreDir.exists()) {
        zcoreDir.mkdirs();
      }
      this.configFile = new File(zcoreDir, "config.json");
    } 
  }
  private File configFile;
  private File getConfigFile() {
    if (this.configFile == null && ZCoreClient.mc != null) {
      File zcoreDir = new File(ZCoreClient.mc.field_1697, "zcore");
      if (!zcoreDir.exists()) {
        zcoreDir.mkdirs();
      }
      this.configFile = new File(zcoreDir, "config.json");
    } 
    return this.configFile;
  }
  
  public void loadProfile() {
    File file = getConfigFile();
    if (file == null || !file.exists()) {
      this.profile = new JsonObject();
      
      return;
    } 
    try {
      JsonObject loaded = loadJsonFromFile(file.toPath());
      if (loaded != null) {
        this.profile = loaded;
        applyProfileFromJson(loaded);

        
        if (ZCoreClient.getModuleManager() != null) {
          ClickGUI clickGUI = ZCoreClient.getModuleManager().<ClickGUI>getModule(ClickGUI.class);
          if (clickGUI != null && ((Boolean)clickGUI.toastNotifications.getValue()).booleanValue()) {
            ToastNotificationManager.getInstance().show("Config Loaded", "Profile loaded successfully", ToastNotification.ToastType.CONFIG_LOAD);
          
          }
        }
      
      }
      else {
        
        this.profile = new JsonObject();
      } 
    } catch (Exception e) {
      this.profile = new JsonObject();
    } 
  }
  
  private void applyProfileFromJson(JsonObject profileJson) {
    if (profileJson == null) {
      this.profile = new JsonObject();
      
      return;
    } 
    this.profile = profileJson;
    
    boolean hadModules = false;
    boolean hadKeybinds = false;
    boolean hadSettings = false;
    
    if (this.profile.has("modules") && this.profile.get("modules").isJsonObject()) {
      JsonObject modulesJson = this.profile.getAsJsonObject("modules");
      for (Module module : ZCoreClient.moduleManager.getModules()) {
        if (modulesJson.has(module.getName())) {
          boolean enabled = modulesJson.get(module.getName()).getAsBoolean();
          if (enabled != module.isEnabled()) module.toggle(); 
          hadModules = true;
        } 
      } 
    } 
    
    if (this.profile.has("keybinds") && this.profile.get("keybinds").isJsonObject()) {
      JsonObject keybindsJson = this.profile.getAsJsonObject("keybinds");
      for (Module module : ZCoreClient.moduleManager.getModules()) {
        int keyCode = module.getKeyBind();
        if (keybindsJson.has(module.getName())) {
          try {
            JsonElement el = keybindsJson.get(module.getName());
            if (el.isJsonPrimitive() && el.getAsJsonPrimitive().isNumber())
              keyCode = el.getAsInt(); 
          } catch (Exception exception) {}
        }
        
        if ("Z-Core".equalsIgnoreCase(module.getName()) && keyCode <= 0)
          keyCode = 344; 
        module.setKeyBind(keyCode);
        hadKeybinds = true;
      } 
    } 
    
    if (this.profile.has("settings") && this.profile.get("settings").isJsonObject()) {
      JsonObject settingsJson = this.profile.getAsJsonObject("settings");
      loadSettingsFromJson(settingsJson);
      hadSettings = true;
    } 
    
    if (this.profile.has("guiPreference") && this.profile.get("guiPreference").isJsonPrimitive()) {
      String guiPreference = this.profile.get("guiPreference").getAsString();
      saveGuiPreference(guiPreference);
    } 
    
    if (!hadModules || !hadKeybinds || !hadSettings) {
      for (Module module : ZCoreClient.moduleManager.getModules()) {
        if (module.isEnabled()) module.toggle(); 
        module.setKeyBind(-1);
      } 
      
      Module discordPresence = ZCoreClient.moduleManager.getModule("Disabled Discord RPC");
      if (discordPresence != null && !discordPresence.isEnabled()) {
        discordPresence.toggle();
      }
    } 
  }
  
  public void saveProfile() {
    try {
      this.profile = buildConfigJson();
      File file = getConfigFile();
      if (file == null) {
        return;
      }
      File parent = file.getParentFile();
      if (parent != null && !parent.exists()) {
        parent.mkdirs();
      }
      
      FileWriter writer = new FileWriter(file); 
      try { Gson gson = (new GsonBuilder()).setPrettyPrinting().create();
        gson.toJson((JsonElement)this.profile, writer);

        
        if (ZCoreClient.getModuleManager() != null) {
          ClickGUI clickGUI = ZCoreClient.getModuleManager().<ClickGUI>getModule(ClickGUI.class);
          if (clickGUI != null && ((Boolean)clickGUI.toastNotifications.getValue()).booleanValue()) {
            ToastNotificationManager.getInstance().show("Config Saved", "Profile saved successfully", ToastNotification.ToastType.CONFIG_SAVE);
          }
        } 



        
        writer.close(); } catch (Throwable throwable) { try { writer.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; } 
    } catch (Exception e) {
      e.printStackTrace();
    } 
  }
  
  private JsonObject buildConfigJson() {
    if (this.profile == null) {
      this.profile = new JsonObject();
    }
    
    JsonObject modulesJson = new JsonObject();
    for (Module module : ZCoreClient.moduleManager.getModules()) {
      modulesJson.addProperty(module.getName(), Boolean.valueOf(module.isEnabled()));
    }
    this.profile.add("modules", (JsonElement)modulesJson);
    
    JsonObject keybindsJson = new JsonObject();
    for (Module module : ZCoreClient.moduleManager.getModules()) {
      if (module.getKeyBind() <= 0) {
        if (module == ZCoreClient.moduleManager.getModule(ClickGUI.class)) {
          keybindsJson.addProperty(module.getName(), Integer.valueOf(344)); continue;
        } 
        keybindsJson.addProperty(module.getName(), "None");
        continue;
      } 
      keybindsJson.addProperty(module.getName(), Integer.valueOf(module.getKeyBind()));
    } 
    
    this.profile.add("keybinds", (JsonElement)keybindsJson);
    
    JsonObject settingsJson = getSettingsAsJson();
    this.profile.add("settings", (JsonElement)settingsJson);
    
    if (!this.profile.has("guiPreference") || !this.profile.get("guiPreference").isJsonPrimitive())
    {
      if (this.profile.has("guiPreference"))
      {
        this.profile.remove("guiPreference");
      }
    }
    return this.profile;
  }
  
  public void saveKeybinds() {
    saveProfile();
  }
  
  public void saveSettings() {
    saveProfile();
  }
  
  public boolean hasGuiPreference() {
    return (this.profile != null && this.profile.has("guiPreference") && this.profile.get("guiPreference").isJsonPrimitive());
  }
  
  public void applyProfile(String cfg) {
    if (cfg.contains("NOT FOUND")) {
      this.profile = new JsonObject();
    } else {
      this.profile = JsonParser.parseString(cfg).getAsJsonObject();
    } 
    
    if (this.profile != null) {
      boolean hadModules = false;
      boolean hadKeybinds = false;
      boolean hadSettings = false;
      
      if (this.profile.has("modules") && this.profile.get("modules").isJsonObject()) {
        JsonObject modulesJson = this.profile.getAsJsonObject("modules");
        for (Module module : ZCoreClient.moduleManager.getModules()) {
          if (modulesJson.has(module.getName())) {
            boolean enabled = modulesJson.get(module.getName()).getAsBoolean();
            if (enabled != module.isEnabled()) module.toggle(); 
            hadModules = true;
          } 
        } 
      } 
      
      if (this.profile.has("keybinds") && this.profile.get("keybinds").isJsonObject()) {
        JsonObject keybindsJson = this.profile.getAsJsonObject("keybinds");
        for (Module module : ZCoreClient.moduleManager.getModules()) {
          int keyCode = module.getKeyBind();
          if (keybindsJson.has(module.getName())) {
            try {
              JsonElement el = keybindsJson.get(module.getName());
              if (el.isJsonPrimitive() && el.getAsJsonPrimitive().isNumber())
                keyCode = el.getAsInt(); 
            } catch (Exception exception) {}
          }
          
          if ("Z-Core".equalsIgnoreCase(module.getName()) && keyCode <= 0)
            keyCode = 344; 
          module.setKeyBind(keyCode);
          hadKeybinds = true;
        } 
      } 
      
      if (this.profile.has("settings") && this.profile.get("settings").isJsonObject()) {
        JsonObject settingsJson = this.profile.getAsJsonObject("settings");
        loadSettingsFromJson(settingsJson);
        hadSettings = true;
      } 
      
      if (this.profile.has("guiPreference") && this.profile.get("guiPreference").isJsonPrimitive()) {
        String guiPreference = this.profile.get("guiPreference").getAsString();
        saveGuiPreference(guiPreference);
      } 
      
      if (!hadModules || !hadKeybinds || !hadSettings) {
        for (Module module : ZCoreClient.moduleManager.getModules()) {
          if (module.isEnabled()) module.toggle(); 
          module.setKeyBind(-1);
        } 
        
        Module discordPresence = ZCoreClient.moduleManager.getModule("Disabled Discord RPC");
        if (discordPresence != null && !discordPresence.isEnabled()) {
          discordPresence.toggle();
        }
      } 
    } 
  }
  
  public JsonObject getSettingsAsJson() {
    JsonObject settingsJson = new JsonObject();
    
    for (Module module : ZCoreClient.moduleManager.getModules()) {
      JsonObject moduleSettings = new JsonObject();
      
      for (Setting<?> setting : (Iterable<Setting<?>>)module.getSettings()) {
        if (setting instanceof BooleanSetting) { BooleanSetting boolSetting = (BooleanSetting)setting;
          moduleSettings.addProperty(setting.getName(), (Boolean)boolSetting.getValue()); continue; }
         if (setting instanceof NumberSetting) { NumberSetting numSetting = (NumberSetting)setting;
          moduleSettings.addProperty(setting.getName(), (Number)numSetting.getValue()); continue; }
         if (setting instanceof DoubleSetting) { DoubleSetting doubleSetting = (DoubleSetting)setting;
          moduleSettings.addProperty(setting.getName(), (Number)doubleSetting.getValue()); continue; }
         if (setting instanceof StringSetting) { StringSetting strSetting = (StringSetting)setting;
          moduleSettings.addProperty(setting.getName(), (String)strSetting.getValue()); continue; }
         if (setting instanceof SliderSetting) { SliderSetting sliderSetting = (SliderSetting)setting;
          moduleSettings.addProperty(setting.getName(), (Number)sliderSetting.getValue()); continue; }
         if (setting instanceof ModeSetting) { ModeSetting modeSetting = (ModeSetting)setting;
          moduleSettings.addProperty(setting.getName(), modeSetting.getValue().toString()); continue; }
         if (setting instanceof EnchantmentSetting) { EnchantmentSetting enchSetting = (EnchantmentSetting)setting;
          
          JsonObject enchObj = new JsonObject();

          
          JsonArray vanillaArr = new JsonArray();
          for (class_5321<class_1887> enchKey : (Iterable<class_5321<class_1887>>)enchSetting.getEnchantments()) {
            try {
              vanillaArr.add(enchKey.method_29177().toString());
            } catch (Exception exception) {}
          } 
          
          enchObj.add("vanilla", (JsonElement)vanillaArr);

          
          JsonArray amethystArr = new JsonArray();
          for (String name : enchSetting.getAmethystEnchants()) {
            amethystArr.add(name);
          }
          enchObj.add("amethyst", (JsonElement)amethystArr);

          
          JsonObject metadataObj = new JsonObject();
          JsonArray selectedArr = new JsonArray();
          for (String name : enchSetting.getAmethystEnchants()) {
            selectedArr.add(name);
          }
          metadataObj.add("selectedAmethystEnchants", (JsonElement)selectedArr);
          enchObj.add("metadata", (JsonElement)metadataObj);
          
          moduleSettings.add(setting.getName(), (JsonElement)enchObj); continue; }
         if (setting instanceof KeybindSetting) { KeybindSetting keybindSetting = (KeybindSetting)setting;
          if (!setting.getName().equalsIgnoreCase("Keybind"))
            moduleSettings.addProperty(setting.getName(), (Number)keybindSetting.getValue());  continue; }
        
        if (setting instanceof ColorSetting) { ColorSetting colorSetting = (ColorSetting)setting;
          Color c = colorSetting.getValue();
          String hex = String.format("#%02x%02x%02x%02x", new Object[] {
                Integer.valueOf(c.getRed()), Integer.valueOf(c.getGreen()), Integer.valueOf(c.getBlue()), Integer.valueOf(c.getAlpha()) });
          moduleSettings.addProperty(setting.getName(), hex); continue; }
         if (setting instanceof StringListSetting) { StringListSetting stringListSetting = (StringListSetting)setting;
          JsonArray stringArray = new JsonArray();
          for (String str : stringListSetting.getValue()) {
            stringArray.add(str);
          }
          moduleSettings.add(setting.getName(), (JsonElement)stringArray); continue; }
         if (setting instanceof ItemSetting) { ItemSetting itemSetting = (ItemSetting)setting;
          class_1792 item = (class_1792)itemSetting.getValue();
          if (item != null) {
            class_2960 itemId = class_7923.field_41178.method_10221(item);
            moduleSettings.addProperty(setting.getName(), itemId.toString());
          }  }
      
      } 
      
      if (!moduleSettings.isEmpty()) settingsJson.add(module.getName(), (JsonElement)moduleSettings);
    
    } 
    return settingsJson;
  }
  
  public void loadSettingsFromJson(JsonObject settingsJson) {
    for (Module module : ZCoreClient.moduleManager.getModules()) {
      if (!settingsJson.has(module.getName()))
        continue;  JsonObject moduleSettings = settingsJson.getAsJsonObject(module.getName());
      
      for (Setting<?> setting : (Iterable<Setting<?>>)module.getSettings()) {
        if (!moduleSettings.has(setting.getName()))
          continue; 
        try {
          if (setting instanceof BooleanSetting) { BooleanSetting boolSetting = (BooleanSetting)setting;
            boolSetting.setValue(Boolean.valueOf(moduleSettings.get(setting.getName()).getAsBoolean())); continue; }
           if (setting instanceof NumberSetting) { NumberSetting numSetting = (NumberSetting)setting;
            numSetting.setValue(Double.valueOf(moduleSettings.get(setting.getName()).getAsDouble())); continue; }
           if (setting instanceof DoubleSetting) { DoubleSetting doubleSetting = (DoubleSetting)setting;
            doubleSetting.setValue(Double.valueOf(moduleSettings.get(setting.getName()).getAsDouble())); continue; }
           if (setting instanceof StringSetting) { StringSetting strSetting = (StringSetting)setting;
            strSetting.setValue(moduleSettings.get(setting.getName()).getAsString()); continue; }
           if (setting instanceof SliderSetting) { SliderSetting sliderSetting = (SliderSetting)setting;
            sliderSetting.setValue(Double.valueOf(moduleSettings.get(setting.getName()).getAsDouble())); continue; }
           if (setting instanceof ModeSetting) { ModeSetting modeSetting = (ModeSetting)setting;
            modeSetting.setValue(moduleSettings.get(setting.getName()).getAsString()); continue; }
           if (setting instanceof EnchantmentSetting) { EnchantmentSetting enchSetting = (EnchantmentSetting)setting;
            
            JsonElement el = moduleSettings.get(setting.getName());
            if (!el.isJsonObject()) {
              
              try {
                JsonArray oldArray = moduleSettings.getAsJsonArray(setting.getName());
                enchSetting.clear();
                for (JsonElement e : oldArray) {
                  String idStr = e.getAsString();
                  try {
                    class_2960 id = class_2960.method_60654(idStr);
                    class_5321<class_1887> key = class_5321.method_29179(class_7924.field_41265, id);
                    enchSetting.addEnchantment(key);
                  } catch (Exception exception) {}
                }
              
              } catch (Exception exception) {}
              continue;
            } 
            JsonObject enchObj = el.getAsJsonObject();
            enchSetting.clear();

            
            if (enchObj.has("vanilla") && enchObj.get("vanilla").isJsonArray()) {
              JsonArray vanillaArr = enchObj.getAsJsonArray("vanilla");
              for (JsonElement e : vanillaArr) {
                try {
                  String idStr = e.getAsString();
                  class_2960 id = class_2960.method_60654(idStr);
                  class_5321<class_1887> key = class_5321.method_29179(class_7924.field_41265, id);
                  enchSetting.addEnchantment(key);
                } catch (Exception exception) {}
              } 
            } 


            
            List<String> amethystListForMetadata = new ArrayList<>();
            if (enchObj.has("amethyst") && enchObj.get("amethyst").isJsonArray()) {
              JsonArray amethystArr = enchObj.getAsJsonArray("amethyst");
              for (JsonElement e : amethystArr) {
                try {
                  String name = e.getAsString();
                  if (name != null && !name.isEmpty()) {
                    enchSetting.addAmethystEnchant(name);
                    amethystListForMetadata.add(name);
                  } 
                } catch (Exception exception) {}
              } 
            } 


            
            if (enchObj.has("metadata") && enchObj.get("metadata").isJsonObject()) {
              JsonObject metadataObj = enchObj.getAsJsonObject("metadata");
              for (String key : metadataObj.keySet()) {
                JsonElement mEl = metadataObj.get(key);
                if (mEl.isJsonArray()) {
                  List<String> list = new ArrayList<>();
                  for (JsonElement arrEl : mEl.getAsJsonArray()) {
                    try {
                      list.add(arrEl.getAsString());
                    } catch (Exception exception) {}
                  } 

                  
                  enchSetting.setMetadata(key, list);

                  
                  if ("selectedAmethystEnchants".equals(key))
                    for (String s : list) {
                      if (!enchSetting.hasAmethystEnchant(s))
                        enchSetting.addAmethystEnchant(s); 
                    }   continue;
                } 
                if (mEl.isJsonPrimitive()) {
                  if (mEl.getAsJsonPrimitive().isBoolean()) {
                    enchSetting.setMetadata(key, Boolean.valueOf(mEl.getAsBoolean())); continue;
                  }  if (mEl.getAsJsonPrimitive().isNumber()) {
                    enchSetting.setMetadata(key, mEl.getAsNumber()); continue;
                  } 
                  enchSetting.setMetadata(key, mEl.getAsString());
                }
              
              }
            
            }
            else if (!amethystListForMetadata.isEmpty()) {
              enchSetting.setMetadata("selectedAmethystEnchants", amethystListForMetadata);
            } 


            
            try {
              enchSetting.loadAmethystFromMetadata();
            } catch (Exception exception) {}
            continue; }
          
          if (setting instanceof KeybindSetting) { KeybindSetting keybindSetting = (KeybindSetting)setting;
            if (!setting.getName().equalsIgnoreCase("Keybind"))
              keybindSetting.setValue(Integer.valueOf(moduleSettings.get(setting.getName()).getAsInt()));  continue; }
          
          if (setting instanceof ColorSetting) { ColorSetting colorSetting = (ColorSetting)setting;
            String hex = moduleSettings.get(setting.getName()).getAsString();
            
            try {
              Color c = Color.decode(hex.substring(0, Math.min(hex.length(), 7)));
              if (hex.length() >= 9) {
                int alpha = Integer.parseInt(hex.substring(7, 9), 16);
                c = new Color(c.getRed(), c.getGreen(), c.getBlue(), alpha);
              } 
              colorSetting.setValue(c);
            } catch (Exception exception) {} continue; }
          
          if (setting instanceof StringListSetting) { StringListSetting stringListSetting = (StringListSetting)setting;
            JsonArray stringArray = moduleSettings.getAsJsonArray(setting.getName());
            stringListSetting.clear();
            for (int i = 0; i < stringArray.size(); i++) {
              String str = stringArray.get(i).getAsString();
              if (str != null && !str.trim().isEmpty())
                stringListSetting.add(str); 
            }  continue; }
          
          if (setting instanceof ItemSetting) { ItemSetting itemSetting = (ItemSetting)setting;
            String itemIdStr = moduleSettings.get(setting.getName()).getAsString();
            try {
              class_2960 itemId = class_2960.method_60654(itemIdStr);
              class_1792 item = (class_1792)class_7923.field_41178.method_63535(itemId);
              if (item != null) {
                itemSetting.setValue(item);
              }
            } catch (Exception exception) {} }

        
        } catch (Exception exception) {}
      } 
    } 
  }

  
  private JsonObject loadJsonFromFile(Path path) {
    if (!Files.exists(path, new java.nio.file.LinkOption[0])) return null;  
    try { Reader reader = new FileReader(path.toFile()); 
      try { JsonObject jsonObject = JsonParser.parseReader(reader).getAsJsonObject();
        reader.close(); return jsonObject; } catch (Throwable throwable) { try { reader.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  } catch (Exception e)
    { return null; }
  
  }

  
  public void saveGuiPreference(String guiType) {
    if (this.profile == null) {
      this.profile = new JsonObject();
    }
    this.profile.addProperty("guiPreference", guiType);
  }
  
  public String loadGuiPreference() {
    if (this.profile != null && this.profile.has("guiPreference") && this.profile.get("guiPreference").isJsonPrimitive()) {
      return this.profile.get("guiPreference").getAsString();
    }
    return "DEFAULT";
  }
  
  public void saveHudPositions() {
    try {
      File zcoreDir = new File(ZCoreClient.mc.field_1697, "zcore");
      if (!zcoreDir.exists()) {
        zcoreDir.mkdirs();
      }
      File posFile = new File(zcoreDir, "pos.json");
      
      JsonObject posJson = new JsonObject();
      
      Module hudModule = ZCoreClient.moduleManager.getModule("HUD");
      if (hudModule != null) {
        for (Setting<?> setting : (Iterable<Setting<?>>)hudModule.getSettings()) {
          if (setting instanceof NumberSetting) { NumberSetting numSetting = (NumberSetting)setting;
            String name = setting.getName();
            if (name.endsWith(" X") || name.endsWith(" Y")) {
              posJson.addProperty(name, (Number)numSetting.getValue());
            } }
          
          if (setting instanceof BooleanSetting) { BooleanSetting boolSetting = (BooleanSetting)setting;
            String name = setting.getName();
            if (name.endsWith(" Centered")) {
              posJson.addProperty(name, (Boolean)boolSetting.getValue());
            } }
        
        } 
      }
      
      Module mediaPlayer = ZCoreClient.moduleManager.getModule("DisabledMediaPlayer");
      if (mediaPlayer != null) {
        for (Setting<?> setting : (Iterable<Setting<?>>)mediaPlayer.getSettings()) {
          if (setting instanceof NumberSetting) { NumberSetting numSetting = (NumberSetting)setting;
            String name = setting.getName();
            if (name.equals("X") || name.equals("Y") || name.equals("Position X") || name.equals("Position Y")) {
              posJson.addProperty("DisabledMediaPlayer " + name, (Number)numSetting.getValue());
            } }
        
        } 
      }
      
      FileWriter writer = new FileWriter(posFile); 
      try { Gson gson = (new GsonBuilder()).setPrettyPrinting().create();
        gson.toJson((JsonElement)posJson, writer);
        writer.close(); } catch (Throwable throwable) { try { writer.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; } 
    } catch (Exception e) {
      e.printStackTrace();
    } 
  }
  
  public void loadHudPositions() {
    try {
      File zcoreDir = new File(ZCoreClient.mc.field_1697, "zcore");
      File posFile = new File(zcoreDir, "pos.json");
      
      if (!posFile.exists()) {
        return;
      }
      
      JsonObject posJson = loadJsonFromFile(posFile.toPath());
      if (posJson == null) {
        return;
      }
      
      Module hudModule = ZCoreClient.moduleManager.getModule("HUD");
      if (hudModule != null) {
        for (Setting<?> setting : (Iterable<Setting<?>>)hudModule.getSettings()) {
          String name = setting.getName();
          if (posJson.has(name)) {
            if (setting instanceof NumberSetting) { NumberSetting numSetting = (NumberSetting)setting;
              numSetting.setValue(Double.valueOf(posJson.get(name).getAsDouble())); }
            
            if (setting instanceof BooleanSetting) { BooleanSetting boolSetting = (BooleanSetting)setting;
              boolSetting.setValue(Boolean.valueOf(posJson.get(name).getAsBoolean())); }
          
          } 
        } 
      }
      
      Module mediaPlayer = ZCoreClient.moduleManager.getModule("DisabledMediaPlayer");
      if (mediaPlayer != null) {
        for (Setting<?> setting : (Iterable<Setting<?>>)mediaPlayer.getSettings()) {
          String name = setting.getName();
          String posName = "DisabledMediaPlayer " + name;
          if (posJson.has(posName) && setting instanceof NumberSetting) { NumberSetting numSetting = (NumberSetting)setting;
            numSetting.setValue(Double.valueOf(posJson.get(posName).getAsDouble())); }
        
        } 
      }
    } catch (Exception e) {
      e.printStackTrace();
    } 
  }
}


