package com.zcore.client.client;

import com.zcore.client.modules.Module;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.CopyOnWriteArrayList;

public class ModuleManager
{
  private final List<Module> modules = new CopyOnWriteArrayList<>();




  
  public void register(Module module) {
    if (module == null) {
      return;
    }
    this.modules.add(module);
  }
  
  public void tick() {
    for (Module module : this.modules) {
      try {
        if (module != null && module.isEnabled()) {
          module.onTick();
        }
      } catch (Exception e) {
        
        System.err.println("Error in module " + ((module != null) ? module.getName() : "null") + ": " + e.getMessage());
        e.printStackTrace();
      } 
    } 
  }
  
  public List<Module> getModules() {
    return new ArrayList<>(this.modules);
  }
  
  public List<Module> getModulesByCategory(Module.Category category) {
    return this.modules.stream()
      .filter(module -> (module.getCategory() == category))
      .toList();
  }
  
  public Module getModule(String name) {
    return this.modules.stream()
      .filter(module -> module.getName().equalsIgnoreCase(name))
      .findFirst()
      .orElse(null);
  }

  
  public <T extends Module> T getModule(Class<T> clazz) {
    Objects.requireNonNull(clazz);
    Objects.requireNonNull(clazz); return (T)this.modules.stream().filter(clazz::isInstance).map(clazz::cast)
      .findFirst()
      .orElse(null);
  }
}


