package com.zcore.util;
public final class VString extends Record { private final String string;
  
  public VString(String string) { this.string = string; }
   public final int hashCode() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> hashCode : (Lcom/zcore/util/VString;)I
    //   6: ireturn
    // Line number table:
    //   Java source line number -> byte code offset
    //   #4	-> 0
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	7	0	this	Lcom/zcore/util/VString;
  } public String string() {
    return (this.string != null) ? this.string : "";
  } public final boolean equals(Object o) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: <illegal opcode> equals : (Lcom/zcore/util/VString;Ljava/lang/Object;)Z
    //   7: ireturn
    // Line number table:
    //   Java source line number -> byte code offset
    //   #4	-> 0
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	8	0	this	Lcom/zcore/util/VString;
    //   0	8	1	o	Ljava/lang/Object;
  } public int codePointAt(int index) {
    if (index < 0 || index >= this.string.length()) {
      return -1;
    }
    return Character.codePointAt(this.string, index);
  }

  
  public String toString() {
    return string();
  } }


