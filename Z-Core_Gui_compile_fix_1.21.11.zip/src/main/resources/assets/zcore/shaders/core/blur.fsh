#version 150

uniform sampler2D DiffuseSampler;

in vec2 texCoord;
out vec4 fragColor;

uniform vec2 OutSize;
uniform vec2 Dir;
uniform float Radius;

void main() {
    vec4 color = vec4(0.0);
    float totalWeight = 0.0;

    for (float i = -Radius; i <= Radius; i++) {
        float weight = exp(-(i * i) / (2.0 * Radius * Radius));
        color += texture(DiffuseSampler, texCoord + (i * Dir) / OutSize) * weight;
        totalWeight += weight;
    }

    fragColor = color / totalWeight;
}
