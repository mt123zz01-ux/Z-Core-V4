#version 150

uniform sampler2D DiffuseSampler;

in vec2 texCoord;
out vec4 fragColor;

void main() {
    vec2 texelSize = 1.0 / textureSize(DiffuseSampler, 0);
    vec4 color = vec4(0.0);
    float totalWeight = 0.0;
    float radius = 4.0;

    for (float x = -radius; x <= radius; x++) {
        for (float y = -radius; y <= radius; y++) {
            float weight = exp(-(x*x + y*y) / (2.0 * radius * radius));
            color += texture(DiffuseSampler, texCoord + vec2(x, y) * texelSize) * weight;
            totalWeight += weight;
        }
    }

    fragColor = vec4((color / totalWeight).rgb, 1.0);
}
