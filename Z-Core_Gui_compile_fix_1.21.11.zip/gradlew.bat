@echo off
set GRADLE_VERSION=9.2.1
set ROOT_DIR=%~dp0
set GRADLE_HOME=%ROOT_DIR%\.gradle-download\gradle-%GRADLE_VERSION%
if not exist "%GRADLE_HOME%\bin\gradle.bat" (
  mkdir "%ROOT_DIR%\.gradle-download" 2>nul
  powershell -Command "Invoke-WebRequest -Uri https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip -OutFile '%ROOT_DIR%\.gradle-download\gradle-%GRADLE_VERSION%-bin.zip'"
  powershell -Command "Expand-Archive -Force '%ROOT_DIR%\.gradle-download\gradle-%GRADLE_VERSION%-bin.zip' '%ROOT_DIR%\.gradle-download'"
)
call "%GRADLE_HOME%\bin\gradle.bat" %*
