package com.zcore.client.client;

import com.zcore.client.modules.ModuleManager;
import com.zcore.client.themes.ThemeManager;

public final class ZCoreClient {
    public static final ThemeManager THEMES = new ThemeManager();
    public static final ModuleManager MODULES = new ModuleManager();

    private ZCoreClient() {
    }

    public static void init() {
        THEMES.initDefaults();
        MODULES.initDefaults();
    }
}
