package com.zcore.client.themes;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class ThemeManager {
    private final List<Theme> themes = new ArrayList<>();
    private int selectedIndex = 0;

    public void initDefaults() {
        if (!themes.isEmpty()) return;
        themes.add(new Theme("Z-Core Red", 0xEE101014, 0xEE19191F, 0xFFFF3B3B, 0xFFFFFFFF, 0xFFB8B8C8));
        themes.add(new Theme("Glass Dark", 0xDD0E1118, 0xAA202836, 0xFF7DD3FC, 0xFFFFFFFF, 0xFFB6C2D1));
        themes.add(new Theme("Neon Purple", 0xEE120B1D, 0xEE21122E, 0xFFC084FC, 0xFFFFFFFF, 0xFFD8B4FE));
        themes.add(new Theme("Ocean", 0xEE071923, 0xEE0D2B3A, 0xFF38BDF8, 0xFFFFFFFF, 0xFFBAE6FD));
        themes.add(new Theme("Forest", 0xEE08140D, 0xEE102016, 0xFF4ADE80, 0xFFFFFFFF, 0xFFBBF7D0));
    }

    public List<Theme> getThemes() {
        return Collections.unmodifiableList(themes);
    }

    public Theme current() {
        if (themes.isEmpty()) initDefaults();
        return themes.get(Math.floorMod(selectedIndex, themes.size()));
    }

    public void nextTheme() {
        if (themes.isEmpty()) initDefaults();
        selectedIndex = Math.floorMod(selectedIndex + 1, themes.size());
    }
}
