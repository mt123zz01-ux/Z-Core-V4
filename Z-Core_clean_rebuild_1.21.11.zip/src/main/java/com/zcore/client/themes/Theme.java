package com.zcore.client.themes;

public record Theme(String name, int background, int panel, int accent, int text, int mutedText) {
}
