package com.zcore.client.modules;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class ModuleManager {
    private final List<Module> modules = new ArrayList<>();

    public void initDefaults() {
        if (!modules.isEmpty()) return;
        modules.add(new Module("Click GUI", "Client", true));
        modules.add(new Module("HUD", "Client", true));
        modules.add(new Module("Themes", "Client", true));
        modules.add(new Module("Z-Core Example", "Misc", false));
    }

    public List<Module> all() {
        return Collections.unmodifiableList(modules);
    }
}
