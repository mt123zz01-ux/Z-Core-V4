package com.zcore.client.utils.font.fonts;

import it.unimi.dsi.fastutil.chars.Char2IntArrayMap;




























class null
  extends Char2IntArrayMap
{
  null() {
    put('0', 0);
    put('1', 170);
    put('2', 43520);
    put('3', 43690);
    put('4', 11141120);
    put('5', 11141290);
    put('6', 16755200);
    put('7', 11184810);
    put('8', 5592405);
    put('9', 5592575);
    put('A', 5635925);
    put('B', 5636095);
    put('C', 16733525);
    put('D', 16733695);
    put('E', 16777045);
    put('F', 16777215);
  }
}


