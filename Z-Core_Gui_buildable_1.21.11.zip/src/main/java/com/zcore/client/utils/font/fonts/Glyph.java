package com.zcore.client.utils.font.fonts;final class Glyph extends Record { private final int u; private final int v; private final int width; private final int height;
  private final char value;
  private final GlyphMap owner;
  
  Glyph(int u, int v, int width, int height, char value, GlyphMap owner) { this.u = u; this.v = v; this.width = width; this.height = height; this.value = value; this.owner = owner; } public final int hashCode() { // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> hashCode : (Lcom/zcore/client/utils/font/fonts/Glyph;)I
    //   6: ireturn
    // Line number table:
    //   Java source line number -> byte code offset
    //   #5	-> 0
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	7	0	this	Lcom/zcore/client/utils/font/fonts/Glyph; } public int u() { return this.u; } public final boolean equals(Object o) { // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: <illegal opcode> equals : (Lcom/zcore/client/utils/font/fonts/Glyph;Ljava/lang/Object;)Z
    //   7: ireturn
    // Line number table:
    //   Java source line number -> byte code offset
    //   #5	-> 0
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	8	0	this	Lcom/zcore/client/utils/font/fonts/Glyph;
    //   0	8	1	o	Ljava/lang/Object; } public int v() { return this.v; } public int width() { return this.width; } public int height() { return this.height; } public char value() { return this.value; } public GlyphMap owner() { return this.owner; }

  
  public String toString() {
    return "Glyph[u=" + this.u + ", v=" + this.v + ", width=" + this.width + ", height=" + this.height + ", value=" + this.value + ", owner=" + String.valueOf(this.owner) + "]";
  } }


