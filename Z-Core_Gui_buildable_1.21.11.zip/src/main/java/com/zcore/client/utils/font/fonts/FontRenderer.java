package com.zcore.client.utils.font.fonts;

import com.google.common.base.Preconditions;
import com.mojang.blaze3d.systems.RenderSystem;
import com.zcore.client.utils.font.util.BufferUtils;
import com.zcore.client.utils.font.util.Colors;
import com.zcore.client.utils.font.util.RendererUtils;
import it.unimi.dsi.fastutil.chars.Char2IntArrayMap;
import it.unimi.dsi.fastutil.chars.Char2ObjectArrayMap;
import it.unimi.dsi.fastutil.objects.Object2ObjectArrayMap;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import it.unimi.dsi.fastutil.objects.ObjectIterator;
import it.unimi.dsi.fastutil.objects.ObjectList;
import it.unimi.dsi.fastutil.objects.ObjectListIterator;
import java.awt.Color;
import java.awt.Font;
import java.io.Closeable;
import java.util.List;
import net.minecraft.class_10142;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;




public class FontRenderer
  implements Closeable
{
  private static final Char2IntArrayMap colorCodes = new Char2IntArrayMap()
    {
    
    };














  
  private static final Object2ObjectArrayMap<class_2960, ObjectList<DrawEntry>> GLYPH_PAGE_CACHE = new Object2ObjectArrayMap();
  private final float originalSize;
  private final ObjectList<GlyphMap> maps = (ObjectList<GlyphMap>)new ObjectArrayList();
  private final Char2ObjectArrayMap<Glyph> allGlyphs = new Char2ObjectArrayMap();
  private final int charsPerPage;
  private final int padding;
  private int scaleMul = 0;
  private Font[] fonts;
  private int previousGameScale = -1;








  
  public FontRenderer(Font[] fonts, float sizePx, int charactersPerPage, int paddingBetweenCharacters) {
    Preconditions.checkArgument((fonts.length > 0), "fonts.length == 0");
    Preconditions.checkArgument((charactersPerPage > 4), "Unreasonable charactersPerPage count");
    Preconditions.checkArgument((paddingBetweenCharacters > 0), "paddingBetweenCharacters > 0");
    this.originalSize = sizePx;
    this.charsPerPage = charactersPerPage;
    this.padding = paddingBetweenCharacters;
    init(fonts, sizePx);
  }






  
  public FontRenderer(Font[] fonts, float sizePx) {
    this(fonts, sizePx, 256, 5);
  }
  
  private static int floorNearestMulN(int x, int n) {
    return n * (int)Math.floor(x / n);
  }






  
  public static String stripControlCodes(String text) {
    char[] chars = text.toCharArray();
    StringBuilder f = new StringBuilder();
    for (int i = 0; i < chars.length; i++) {
      char c = chars[i];
      if (c == '§') {
        i++;
      } else {
        
        f.append(c);
      } 
    }  return f.toString();
  }
  
  private void sizeCheck() {
    int gs = RendererUtils.getGuiScale();
    if (gs != this.previousGameScale) {
      close();
      init(this.fonts, this.originalSize);
    } 
  }
  
  private void init(Font[] fonts, float sizePx) {
    this.previousGameScale = RendererUtils.getGuiScale();
    this.scaleMul = this.previousGameScale;
    this.fonts = new Font[fonts.length];
    for (int i = 0; i < fonts.length; i++) {
      this.fonts[i] = fonts[i].deriveFont(sizePx * this.scaleMul);
    }
  }
  
  private GlyphMap generateMap(char from, char to) {
    GlyphMap gm = new GlyphMap(from, to, this.fonts, RendererUtils.randomIdentifier(), this.padding);
    this.maps.add(gm);
    return gm;
  }
  
  private Glyph locateGlyph0(char glyph) {
    for (ObjectListIterator<GlyphMap> objectListIterator = this.maps.iterator(); objectListIterator.hasNext(); ) { GlyphMap map = objectListIterator.next();
      if (map.contains(glyph)) {
        return map.getGlyph(glyph);
      } }
    
    int base = floorNearestMulN(glyph, this.charsPerPage);
    GlyphMap glyphMap = generateMap((char)base, (char)(base + this.charsPerPage));
    return glyphMap.getGlyph(glyph);
  }
  
  private Glyph locateGlyph1(char glyph) {
    return (Glyph)this.allGlyphs.computeIfAbsent(glyph, this::locateGlyph0);
  }









  
  public void drawString(class_4587 stack, String s, float x, float y, Color color) {
    float r = color.getRed() / 255.0F;
    float g = color.getGreen() / 255.0F;
    float b = color.getBlue() / 255.0F;
    float a = color.getAlpha() / 255.0F;
    sizeCheck();
    float r2 = r, g2 = g, b2 = b;
    stack.method_22903();
    stack.method_46416(x, y, 0.0F);
    stack.method_22905(1.0F / this.scaleMul, 1.0F / this.scaleMul, 1.0F);
    
    RenderSystem.enableBlend();
    RenderSystem.defaultBlendFunc();
    RenderSystem.disableCull();
    GL11.glTexParameteri(3553, 10241, 9729);
    GL11.glTexParameteri(3553, 10240, 9729);
    
    RenderSystem.setShader(class_10142.field_53880);
    
    Matrix4f mat = stack.method_23760().method_23761();
    char[] chars = s.toCharArray();
    float xOffset = 0.0F;
    float yOffset = 0.0F;
    boolean inSel = false;
    int lineStart = 0;
    for (int i = 0; i < chars.length; i++) {
      char c = chars[i];
      if (inSel) {
        inSel = false;
        char c1 = Character.toUpperCase(c);
        if (colorCodes.containsKey(c1)) {
          int ii = colorCodes.get(c1);
          int[] col = Colors.RGBIntToRGB(ii);
          r2 = col[0] / 255.0F;
          g2 = col[1] / 255.0F;
          b2 = col[2] / 255.0F;
        } else if (c1 == 'R') {
          r2 = r;
          g2 = g;
          b2 = b;
        }
      
      }
      else if (c == '§') {
        inSel = true;
      }
      else if (c == '\n') {
        yOffset += getStringHeight(s.substring(lineStart, i)) * this.scaleMul;
        xOffset = 0.0F;
        lineStart = i + 1;
      } else {
        
        Glyph glyph = locateGlyph1(c);
        if (glyph.value() != ' ') {
          class_2960 i1 = (glyph.owner()).bindToTexture;
          DrawEntry entry = new DrawEntry(xOffset, yOffset, r2, g2, b2, glyph);
          ((ObjectList)GLYPH_PAGE_CACHE.computeIfAbsent(i1, integer -> new ObjectArrayList())).add(entry);
        } 
        xOffset += glyph.width();
      } 
    }  for (ObjectIterator<class_2960> objectIterator = GLYPH_PAGE_CACHE.keySet().iterator(); objectIterator.hasNext(); ) { class_2960 identifier = objectIterator.next();
      RenderSystem.setShaderTexture(0, identifier);
      List<DrawEntry> objects = (List<DrawEntry>)GLYPH_PAGE_CACHE.get(identifier);
      
      class_287 bb = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1575);
      
      for (DrawEntry object : objects) {
        float xo = object.atX;
        float yo = object.atY;
        float cr = object.r;
        float cg = object.g;
        float cb = object.b;
        Glyph glyph = object.toDraw;
        GlyphMap owner = glyph.owner();
        float w = glyph.width();
        float h = glyph.height();
        float u1 = glyph.u() / owner.width;
        float v1 = glyph.v() / owner.height;
        float u2 = (glyph.u() + glyph.width()) / owner.width;
        float v2 = (glyph.v() + glyph.height()) / owner.height;
        
        bb.method_22918(mat, xo + 0.0F, yo + h, 0.0F).method_22913(u1, v2).method_22915(cr, cg, cb, a);
        bb.method_22918(mat, xo + w, yo + h, 0.0F).method_22913(u2, v2).method_22915(cr, cg, cb, a);
        bb.method_22918(mat, xo + w, yo + 0.0F, 0.0F).method_22913(u2, v1).method_22915(cr, cg, cb, a);
        bb.method_22918(mat, xo + 0.0F, yo + 0.0F, 0.0F).method_22913(u1, v1).method_22915(cr, cg, cb, a);
      } 
      BufferUtils.draw(bb); }

    
    stack.method_22909();
    GLYPH_PAGE_CACHE.clear();
  }












  
  public int drawString(class_4587 matrices, String text, float x, float y, int color, boolean dropShadow) {
    if (dropShadow) {
      int shadowColor = (color & 0xFCFCFC) >> 2 | color & 0xFF000000;
      drawString(matrices, text, x + 1.0F, y + 1.0F, new Color(shadowColor, true));
    } 
    drawString(matrices, text, x, y, new Color(color, true));
    return (int)(x + getStringWidth(text));
  }









  
  public void drawCenteredString(class_4587 stack, String s, float x, float y, Color color) {
    drawString(stack, s, x - getStringWidth(s) / 2.0F, y, color);
  }






  
  public float getStringWidth(String text) {
    char[] c = stripControlCodes(text).toCharArray();
    float currentLine = 0.0F;
    float maxPreviousLines = 0.0F;
    for (char c1 : c) {
      if (c1 == '\n') {
        maxPreviousLines = Math.max(currentLine, maxPreviousLines);
        currentLine = 0.0F;
      } else {
        
        Glyph glyph = locateGlyph1(c1);
        currentLine += glyph.width() / this.scaleMul;
      } 
    }  return Math.max(currentLine, maxPreviousLines);
  }






  
  public float getStringHeight(String text) {
    char[] c = stripControlCodes(text).toCharArray();
    if (c.length == 0) {
      c = new char[] { ' ' };
    }
    float currentLine = 0.0F;
    float previous = 0.0F;
    for (char c1 : c) {
      if (c1 == '\n') {
        if (currentLine == 0.0F)
        {
          currentLine = locateGlyph1(' ').height() / this.scaleMul;
        }
        previous += currentLine;
        currentLine = 0.0F;
      } else {
        
        Glyph glyph = locateGlyph1(c1);
        currentLine = Math.max(glyph.height() / this.scaleMul, currentLine);
      } 
    }  return currentLine + previous;
  }
  
  public int getFontHeight() {
    return (int)(getStringHeight("A") / 2.0F);
  }




  
  public void close() {
    for (ObjectListIterator<GlyphMap> objectListIterator = this.maps.iterator(); objectListIterator.hasNext(); ) { GlyphMap map = objectListIterator.next();
      map.destroy(); }
    
    this.maps.clear();
    this.allGlyphs.clear();
  }
  static final class DrawEntry extends Record { private final float atX; private final float atY; private final float r; private final float g; private final float b; private final Glyph toDraw;
    DrawEntry(float atX, float atY, float r, float g, float b, Glyph toDraw) { this.atX = atX; this.atY = atY; this.r = r; this.g = g; this.b = b; this.toDraw = toDraw; } public final int hashCode() { // Byte code:
      //   0: aload_0
      //   1: <illegal opcode> hashCode : (Lcom/zcore/client/utils/font/fonts/FontRenderer$DrawEntry;)I
      //   6: ireturn
      // Line number table:
      //   Java source line number -> byte code offset
      //   #357	-> 0
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	7	0	this	Lcom/zcore/client/utils/font/fonts/FontRenderer$DrawEntry; } public float atX() { return this.atX; } public final boolean equals(Object o) { // Byte code:
      //   0: aload_0
      //   1: aload_1
      //   2: <illegal opcode> equals : (Lcom/zcore/client/utils/font/fonts/FontRenderer$DrawEntry;Ljava/lang/Object;)Z
      //   7: ireturn
      // Line number table:
      //   Java source line number -> byte code offset
      //   #357	-> 0
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	8	0	this	Lcom/zcore/client/utils/font/fonts/FontRenderer$DrawEntry;
      //   0	8	1	o	Ljava/lang/Object; } public float atY() { return this.atY; } public float r() { return this.r; } public float g() { return this.g; } public float b() { return this.b; } public Glyph toDraw() { return this.toDraw; }

    
    public String toString() {
      return "DrawEntry[atX=" + this.atX + ", atY=" + this.atY + ", r=" + this.r + ", g=" + this.g + ", b=" + this.b + ", toDraw=" + String.valueOf(this.toDraw) + "]";
    } }

}


