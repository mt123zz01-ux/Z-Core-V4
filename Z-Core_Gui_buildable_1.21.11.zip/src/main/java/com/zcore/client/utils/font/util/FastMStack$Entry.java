package com.zcore.client.utils.font.util;

import org.joml.Matrix3f;
import org.joml.Matrix4f;































































































final class Entry
  extends Record
{
  private final Matrix4f positionMatrix;
  private final Matrix3f normalMatrix;
  
  public final int hashCode() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> hashCode : (Lcom/zcore/client/utils/font/util/FastMStack$Entry;)I
    //   6: ireturn
    // Line number table:
    //   Java source line number -> byte code offset
    //   #115	-> 0
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	7	0	this	Lcom/zcore/client/utils/font/util/FastMStack$Entry;
  }
  
  public final boolean equals(Object o) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: <illegal opcode> equals : (Lcom/zcore/client/utils/font/util/FastMStack$Entry;Ljava/lang/Object;)Z
    //   7: ireturn
    // Line number table:
    //   Java source line number -> byte code offset
    //   #115	-> 0
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	8	0	this	Lcom/zcore/client/utils/font/util/FastMStack$Entry;
    //   0	8	1	o	Ljava/lang/Object;
  }
  
  Entry(Matrix4f positionMatrix, Matrix3f normalMatrix) {
    this.positionMatrix = positionMatrix; this.normalMatrix = normalMatrix; } public Matrix4f positionMatrix() { return this.positionMatrix; } public Matrix3f normalMatrix() { return this.normalMatrix; }

  
  public String toString() {
    return "Entry[positionMatrix=" + String.valueOf(this.positionMatrix) + ", normalMatrix=" + String.valueOf(this.normalMatrix) + "]";
  }
}


