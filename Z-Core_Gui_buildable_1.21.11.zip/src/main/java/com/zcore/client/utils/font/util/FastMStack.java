package com.zcore.client.utils.font.util;

import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import net.minecraft.class_4587;
import org.joml.Matrix3f;
import org.joml.Matrix3fc;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.joml.Quaternionf;
import org.joml.Quaternionfc;

public class FastMStack
  extends class_4587
{
  private static final MethodHandle MATRIXSTACK_ENTRY_CTOR;
  
  static {
    try {
      MethodHandles.Lookup lookup = MethodHandles.privateLookupIn(class_4587.class_4665.class, 
          MethodHandles.lookup());
      MATRIXSTACK_ENTRY_CTOR = lookup.findConstructor(class_4587.class_4665.class, 
          MethodType.methodType(void.class, Matrix4f.class, new Class[] { Matrix3f.class }));
    } catch (IllegalAccessException|NoSuchMethodException e) {
      throw new RuntimeException(e);
    } 
  }
  
  private final ObjectArrayList<Entry> fEntries = new ObjectArrayList(8);
  private Entry top;
  
  public FastMStack() {
    this.fEntries.add(this.top = new Entry(new Matrix4f(), new Matrix3f()));
  }

  
  public void method_46416(float x, float y, float z) {
    this.top.positionMatrix.translate(x, y, z);
  }

  
  public void method_22905(float x, float y, float z) {
    this.top.positionMatrix.scale(x, y, z);
    if (x == y && y == z) {

      
      if (x != 0.0F) {
        this.top.normalMatrix.scale(Math.signum(x));
      }
      return;
    } 
    float inverseX = 1.0F / x;
    float inverseY = 1.0F / y;
    float inverseZ = 1.0F / z;
    
    float scalar = (float)(1.0D / Math.cbrt((inverseX * inverseY * inverseZ)));
    this.top.normalMatrix.scale(scalar * inverseX, scalar * inverseY, scalar * inverseZ);
  }

  
  public void method_22907(Quaternionf quaternion) {
    this.top.positionMatrix.rotate((Quaternionfc)quaternion);
    this.top.normalMatrix.rotate((Quaternionfc)quaternion);
  }

  
  public void method_49278(Quaternionf quaternion, float originX, float originY, float originZ) {
    this.top.positionMatrix.rotateAround((Quaternionfc)quaternion, originX, originY, originZ);
    this.top.normalMatrix.rotate((Quaternionfc)quaternion);
  }

  
  public void method_34425(Matrix4f matrix) {
    this.top.positionMatrix.mul((Matrix4fc)matrix);
  }

  
  public void method_22903() {
    this.fEntries.add(this.top = new Entry(new Matrix4f((Matrix4fc)this.top.positionMatrix), new Matrix3f((Matrix3fc)this.top.normalMatrix)));
  }

  
  public void method_22909() {
    if (this.fEntries.size() == 1) {
      throw new IllegalStateException("Trying to pop an empty stack");
    }
    this.fEntries.pop();
    this.top = (Entry)this.fEntries.top();
  }


  
  public class_4587.class_4665 method_23760() {
    try {
      return MATRIXSTACK_ENTRY_CTOR.invoke(this.top.positionMatrix, this.top.normalMatrix);
    } catch (Throwable e) {
      throw new RuntimeException("Failed to invoke MATRIXSTACK_ENTRY_CTOR", e);
    } 
  }


  
  public boolean method_22911() {
    return (this.fEntries.size() == 1);
  }

  
  public void method_34426() {
    this.top.positionMatrix.identity();
    this.top.normalMatrix.identity();
  }
  static final class Entry extends Record { private final Matrix4f positionMatrix; private final Matrix3f normalMatrix;
    Entry(Matrix4f positionMatrix, Matrix3f normalMatrix) { this.positionMatrix = positionMatrix; this.normalMatrix = normalMatrix; } public final int hashCode() { // Byte code:
      //   0: aload_0
      //   1: <illegal opcode> hashCode : (Lcom/zcore/client/utils/font/util/FastMStack$Entry;)I
      //   6: ireturn
      // Line number table:
      //   Java source line number -> byte code offset
      //   #115	-> 0
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	7	0	this	Lcom/zcore/client/utils/font/util/FastMStack$Entry; } public Matrix4f positionMatrix() { return this.positionMatrix; } public final boolean equals(Object o) { // Byte code:
      //   0: aload_0
      //   1: aload_1
      //   2: <illegal opcode> equals : (Lcom/zcore/client/utils/font/util/FastMStack$Entry;Ljava/lang/Object;)Z
      //   7: ireturn
      // Line number table:
      //   Java source line number -> byte code offset
      //   #115	-> 0
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	8	0	this	Lcom/zcore/client/utils/font/util/FastMStack$Entry;
      //   0	8	1	o	Ljava/lang/Object; } public Matrix3f normalMatrix() { return this.normalMatrix; }

    
    public String toString() {
      return "Entry[positionMatrix=" + String.valueOf(this.positionMatrix) + ", normalMatrix=" + String.valueOf(this.normalMatrix) + "]";
    } }

}


