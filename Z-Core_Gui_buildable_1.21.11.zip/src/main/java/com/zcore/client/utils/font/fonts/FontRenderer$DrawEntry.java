package com.zcore.client.utils.font.fonts;
















































































































































































































































































































































final class DrawEntry
  extends Record
{
  private final float atX;
  private final float atY;
  private final float r;
  private final float g;
  private final float b;
  private final Glyph toDraw;
  
  public final int hashCode() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> hashCode : (Lcom/zcore/client/utils/font/fonts/FontRenderer$DrawEntry;)I
    //   6: ireturn
    // Line number table:
    //   Java source line number -> byte code offset
    //   #357	-> 0
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	7	0	this	Lcom/zcore/client/utils/font/fonts/FontRenderer$DrawEntry;
  }
  
  public final boolean equals(Object o) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: <illegal opcode> equals : (Lcom/zcore/client/utils/font/fonts/FontRenderer$DrawEntry;Ljava/lang/Object;)Z
    //   7: ireturn
    // Line number table:
    //   Java source line number -> byte code offset
    //   #357	-> 0
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	8	0	this	Lcom/zcore/client/utils/font/fonts/FontRenderer$DrawEntry;
    //   0	8	1	o	Ljava/lang/Object;
  }
  
  DrawEntry(float atX, float atY, float r, float g, float b, Glyph toDraw) {
    this.atX = atX; this.atY = atY; this.r = r; this.g = g; this.b = b; this.toDraw = toDraw; } public float atX() { return this.atX; } public float atY() { return this.atY; } public float r() { return this.r; } public float g() { return this.g; } public float b() { return this.b; } public Glyph toDraw() { return this.toDraw; }

  
  public String toString() {
    return "DrawEntry[atX=" + this.atX + ", atY=" + this.atY + ", r=" + this.r + ", g=" + this.g + ", b=" + this.b + ", toDraw=" + String.valueOf(this.toDraw) + "]";
  }
}


