package com.zcore.client.events;






















































final class PrioritizedListener<L extends Listener>
  extends Record
{
  private final L listener;
  private final int priority;
  
  public int priority() {
    return this.priority; } public L listener() { return this.listener; } public final boolean equals(Object o) { // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: <illegal opcode> equals : (Lcom/zcore/client/events/EventManager$PrioritizedListener;Ljava/lang/Object;)Z
    //   7: ireturn
    // Line number table:
    //   Java source line number -> byte code offset
    //   #63	-> 0
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	8	0	this	Lcom/zcore/client/events/EventManager$PrioritizedListener;
    //   0	8	1	o	Ljava/lang/Object;
    // Local variable type table:
    //   start	length	slot	name	signature
    //   0	8	0	this	Lcom/zcore/client/events/EventManager$PrioritizedListener<TL;>; } private PrioritizedListener(L listener, int priority) { this.listener = listener; this.priority = priority; }
  public final int hashCode() { // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> hashCode : (Lcom/zcore/client/events/EventManager$PrioritizedListener;)I
    //   6: ireturn
    // Line number table:
    //   Java source line number -> byte code offset
    //   #63	-> 0
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	7	0	this	Lcom/zcore/client/events/EventManager$PrioritizedListener;
    // Local variable type table:
    //   start	length	slot	name	signature
    //   0	7	0	this	Lcom/zcore/client/events/EventManager$PrioritizedListener<TL;>; }
  public final String toString() { // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> toString : (Lcom/zcore/client/events/EventManager$PrioritizedListener;)Ljava/lang/String;
    //   6: areturn
    // Line number table:
    //   Java source line number -> byte code offset
    //   #63	-> 0
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	7	0	this	Lcom/zcore/client/events/EventManager$PrioritizedListener;
    // Local variable type table:
    //   start	length	slot	name	signature
    //   0	7	0	this	Lcom/zcore/client/events/EventManager$PrioritizedListener<TL;>; } public PrioritizedListener(L listener) { this(listener, 0); }

}


