package com.zcore.client.events;

import com.zcore.client.client.ZCoreClient;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Objects;






public final class EventManager
{
  private final HashMap<Class<? extends Listener>, ArrayList<PrioritizedListener<? extends Listener>>> listenerMap = new HashMap<>();

  
  public static <L extends Listener, E extends Event<L>> void fire(E event) {
    EventManager eventManager = ZCoreClient.getEventManager();
    if (eventManager != null) {
      eventManager.fireImpl(event);
    }
  }
  
  private <L extends Listener, E extends Event<L>> void fireImpl(E event) {
    Class<L> listenerType = event.getListenerType();
    ArrayList<PrioritizedListener<L>> listeners = (ArrayList<PrioritizedListener<L>>)this.listenerMap.get(listenerType);
    
    if (listeners == null || listeners.isEmpty()) {
      return;
    }
    ArrayList<PrioritizedListener<L>> listeners2 = new ArrayList<>(listeners);
    listeners2.removeIf(Objects::isNull);
    listeners2.sort(Comparator.comparing(listener -> Integer.valueOf(Integer.MAX_VALUE - listener.priority())));
    
    ArrayList<L> listeners3 = new ArrayList<>();
    listeners2.forEach(listener -> listeners3.add(listener.listener()));
    
    event.fire(listeners3);
  }
  
  public <L extends Listener> void add(Class<L> type, L listener) {
    add(type, listener, 0);
  }
  
  public <L extends Listener> void add(Class<L> type, L listener, int priority) {
    ArrayList<PrioritizedListener<L>> listeners = (ArrayList<PrioritizedListener<L>>)this.listenerMap.get(type);
    if (listeners == null) {
      listeners = new ArrayList<>();
      this.listenerMap.put(type, listeners);
    } 
    listeners.add(new PrioritizedListener<>(listener, priority));
  }
  
  public <L extends Listener> void remove(Class<L> type, L listener) {
    ArrayList<PrioritizedListener<L>> listeners = (ArrayList<PrioritizedListener<L>>)this.listenerMap.get(type);
    if (listeners != null)
      listeners.removeIf(l -> l.listener().equals(listener)); 
  }
  private static final class PrioritizedListener<L extends Listener> extends Record { private final L listener; private final int priority;
    
    public int priority() { return this.priority; } public L listener() { return this.listener; } public final boolean equals(Object o) { // Byte code:
      //   0: aload_0
      //   1: aload_1
      //   2: <illegal opcode> equals : (Lcom/zcore/client/events/EventManager$PrioritizedListener;Ljava/lang/Object;)Z
      //   7: ireturn
      // Line number table:
      //   Java source line number -> byte code offset
      //   #63	-> 0
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	8	0	this	Lcom/zcore/client/events/EventManager$PrioritizedListener;
      //   0	8	1	o	Ljava/lang/Object;
      // Local variable type table:
      //   start	length	slot	name	signature
      //   0	8	0	this	Lcom/zcore/client/events/EventManager$PrioritizedListener<TL;>; } private PrioritizedListener(L listener, int priority) { this.listener = listener; this.priority = priority; }
    public final int hashCode() { // Byte code:
      //   0: aload_0
      //   1: <illegal opcode> hashCode : (Lcom/zcore/client/events/EventManager$PrioritizedListener;)I
      //   6: ireturn
      // Line number table:
      //   Java source line number -> byte code offset
      //   #63	-> 0
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	7	0	this	Lcom/zcore/client/events/EventManager$PrioritizedListener;
      // Local variable type table:
      //   start	length	slot	name	signature
      //   0	7	0	this	Lcom/zcore/client/events/EventManager$PrioritizedListener<TL;>; }
    public final String toString() { // Byte code:
      //   0: aload_0
      //   1: <illegal opcode> toString : (Lcom/zcore/client/events/EventManager$PrioritizedListener;)Ljava/lang/String;
      //   6: areturn
      // Line number table:
      //   Java source line number -> byte code offset
      //   #63	-> 0
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	7	0	this	Lcom/zcore/client/events/EventManager$PrioritizedListener;
      // Local variable type table:
      //   start	length	slot	name	signature
      //   0	7	0	this	Lcom/zcore/client/events/EventManager$PrioritizedListener<TL;>; } public PrioritizedListener(L listener) { this(listener, 0); }
     }

}


