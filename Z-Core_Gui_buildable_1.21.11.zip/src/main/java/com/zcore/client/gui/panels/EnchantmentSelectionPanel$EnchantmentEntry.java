package com.zcore.client.gui.panels;

import net.minecraft.class_1887;
import net.minecraft.class_5321;
































































































































































































































































































































































































































final class EnchantmentEntry
  extends Record
{
  private final String name;
  private final class_5321<class_1887> enchantmentKey;
  private final boolean isAmethyst;
  
  public final String toString() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> toString : (Lcom/zcore/client/gui/panels/EnchantmentSelectionPanel$EnchantmentEntry;)Ljava/lang/String;
    //   6: areturn
    // Line number table:
    //   Java source line number -> byte code offset
    //   #441	-> 0
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	7	0	this	Lcom/zcore/client/gui/panels/EnchantmentSelectionPanel$EnchantmentEntry;
  }
  
  public final int hashCode() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> hashCode : (Lcom/zcore/client/gui/panels/EnchantmentSelectionPanel$EnchantmentEntry;)I
    //   6: ireturn
    // Line number table:
    //   Java source line number -> byte code offset
    //   #441	-> 0
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	7	0	this	Lcom/zcore/client/gui/panels/EnchantmentSelectionPanel$EnchantmentEntry;
  }
  
  public final boolean equals(Object o) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: <illegal opcode> equals : (Lcom/zcore/client/gui/panels/EnchantmentSelectionPanel$EnchantmentEntry;Ljava/lang/Object;)Z
    //   7: ireturn
    // Line number table:
    //   Java source line number -> byte code offset
    //   #441	-> 0
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	8	0	this	Lcom/zcore/client/gui/panels/EnchantmentSelectionPanel$EnchantmentEntry;
    //   0	8	1	o	Ljava/lang/Object;
  }
  
  private EnchantmentEntry(String name, class_5321<class_1887> enchantmentKey, boolean isAmethyst) {
    this.name = name; this.enchantmentKey = enchantmentKey; this.isAmethyst = isAmethyst; } public String name() { return this.name; } public class_5321<class_1887> enchantmentKey() { return this.enchantmentKey; } public boolean isAmethyst() { return this.isAmethyst; }

}


