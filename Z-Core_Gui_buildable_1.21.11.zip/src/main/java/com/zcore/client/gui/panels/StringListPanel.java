package com.zcore.client.gui.panels;

import com.zcore.client.gui.ZCoreGuiTheme;
import com.zcore.client.gui.settings.StringListSetting;
import com.zcore.client.gui.utils.DragHandler;
import com.zcore.client.gui.utils.GuiUtils;
import com.zcore.client.gui.utils.TextEditor;
import com.zcore.client.utils.render.RenderUtils;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_1044;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;

public class StringListPanel
{
  private final DragHandler dragHandler;
  private final class_310 client = class_310.method_1551();
  private final int panelWidth = 125;
  private final int minPanelHeight = 75;
  private final int maxPanelHeight = 150;
  private final int itemHeight = 14;
  private final int padding = 4;
  private final int headerHeight = 15;
  private final int maxVisibleItems = 3;
  private final int addButtonHeight = 14;
  private final int searchBarHeight = 11;
  private final TextEditor editingTextEditor = new TextEditor();
  private final TextEditor searchEditor = new TextEditor();
  private final Map<String, class_2960> headTextureCache = new ConcurrentHashMap<>();
  private final Map<String, Boolean> loadingHeads = new ConcurrentHashMap<>();
  private StringListSetting editingList;
  private int panelX = 500, panelY = 200;
  private int panelHeight = 75;
  private int scrollOffset = 0;
  private int editingIndex = -1;
  private boolean isAddingNew = false;
  
  public StringListPanel() {
    this.dragHandler = new DragHandler();
  }
  
  private void updatePanelHeight() {
    if (this.editingList == null) {
      this.panelHeight = 75;
      return;
    } 
    int itemsCount = getFilteredItems().size();
    int contentHeight = 34;
    if (itemsCount == 0) {
      this.panelHeight = Math.max(75, contentHeight + 14 + 8);
    } else if (itemsCount <= 3) {
      this.panelHeight = contentHeight + itemsCount * 18 + 4 + 14 + 4;
      this.panelHeight = Math.min(this.panelHeight, 150);
    } else {
      int visibleItemsHeight = 54;
      this.panelHeight = contentHeight + visibleItemsHeight + 4 + 14 + 4;
      this.panelHeight = Math.min(this.panelHeight, 150);
    } 
  }
  
  private List<String> getFilteredItems() {
    if (this.editingList == null) return Collections.emptyList(); 
    if (this.searchEditor.getText().isEmpty()) return this.editingList.getList(); 
    String query = this.searchEditor.getText().toLowerCase();
    return (List<String>)this.editingList.getList().stream()
      .filter(item -> (item != null && item.toLowerCase().contains(query)))
      .collect(Collectors.toList());
  }
  
  public StringListSetting getEditingList() {
    return this.editingList;
  }
  
  public void setEditingList(StringListSetting list) {
    this.editingList = list;
    if (list != null) {
      this.scrollOffset = 0;
      this.editingIndex = -1;
      this.editingTextEditor.setText("");
      this.editingTextEditor.stopEditing();
      this.isAddingNew = false;
      updatePanelHeight();

      
      int screenWidth = this.client.method_22683().method_4489() / 2;
      int screenHeight = this.client.method_22683().method_4506() / 2;
      setPosition((screenWidth - 125) / 2, (screenHeight - this.panelHeight) / 2);
    } 
  }
  
  public void setPosition(int x, int y) {
    this.panelX = x;
    this.panelY = y;
    this.dragHandler.setPosition(x, y);
  }
  
  public void render(class_332 context, int mouseX, int mouseY, float progress) {
    String searchDisplay, addText;
    if (this.editingList == null)
      return; 
    updatePanelHeight();
    int[] pos = this.dragHandler.getAnimatedPosition();
    this.panelX = pos[0];
    this.panelY = pos[1];
    
    boolean isDragging = this.dragHandler.isDragging();
    int cornerRadius = 6;

    
    int purpleBase = ZCoreGuiTheme.getAccentColor();
    int darkPurple = ZCoreGuiTheme.blendColors(purpleBase, -16777216, 0.8F);
    int panelBgColor = ZCoreGuiTheme.applyAlpha(darkPurple, progress * 0.4F);
    RenderUtils.fillRoundRect(context, this.panelX, this.panelY, 125, this.panelHeight, cornerRadius, panelBgColor);

    
    int glowColor = ZCoreGuiTheme.applyAlpha(ZCoreGuiTheme.getAccentColor(), progress * 0.15F);
    if (glowColor != 0) {
      RenderUtils.drawRoundRect(context, this.panelX + 1, this.panelY + 1, 123, this.panelHeight - 2, cornerRadius - 1, glowColor);
    }

    
    float borderAlpha = isDragging ? 1.0F : 0.7F;
    int borderColor = ZCoreGuiTheme.applyAlpha(ZCoreGuiTheme.getAccentColor(), progress * borderAlpha);
    RenderUtils.drawRoundRect(context, this.panelX, this.panelY, 125, this.panelHeight, cornerRadius, borderColor);

    
    int headerColor = ZCoreGuiTheme.applyAlpha(darkPurple, progress * 0.4F);
    RenderUtils.fillRoundTabTop(context, this.panelX, this.panelY, 125, 15, cornerRadius, headerColor);

    
    int titleColor = ZCoreGuiTheme.applyAlpha(ZCoreGuiTheme.getTextColor(), (int)(progress * 255.0F)) | 0xFF000000;
    String title = this.editingList.getName();
    context.method_51433(this.client.field_1772, title, this.panelX + 4, this.panelY + 3, titleColor, false);

    
    int closeButtonX = this.panelX + 125 - 9;
    int closeButtonY = this.panelY + 5;
    boolean closeHovered = GuiUtils.isHovered(mouseX, mouseY, closeButtonX - 2, closeButtonY, 7, 5);

    
    int closeBgColor = closeHovered ? ZCoreGuiTheme.applyAlpha(ZCoreGuiTheme.getAccentColor(), progress * 0.8F) : ZCoreGuiTheme.applyAlpha(0, 0.0F);
    if (closeBgColor != 0) {
      RenderUtils.fillRoundRect(context, closeButtonX - 2, closeButtonY, 7, 5, 2, closeBgColor);
    }
    int closeTextColor = ZCoreGuiTheme.applyAlpha(-1, (int)(progress * 255.0F)) | 0xFF000000;
    context.method_51433(this.client.field_1772, "✕", closeButtonX - 1, closeButtonY, closeTextColor, false);

    
    int searchY = this.panelY + 15 + 4;
    int searchX = this.panelX + 4;
    int searchWidth = 117;
    boolean searchHovered = GuiUtils.isHovered(mouseX, mouseY, searchX, searchY, searchWidth, 11);

    
    int searchBgColor = (this.searchEditor.isActive() || searchHovered) ? ZCoreGuiTheme.applyAlpha(ZCoreGuiTheme.getHoverColor(), progress * 0.2F) : ZCoreGuiTheme.applyAlpha(-13421773, progress * 0.2F);
    RenderUtils.fillRoundRect(context, searchX, searchY, searchWidth, 11, 2, searchBgColor);
    
    String searchPlaceholder = (this.editingList != null) ? ("Search " + this.editingList.getName().toLowerCase() + "...") : "Search...";
    String searchText = this.searchEditor.getText();
    
    if (this.searchEditor.isActive()) {
      int cursorPos = this.searchEditor.getCursorPosition();
      String beforeCursor = searchText.substring(0, cursorPos);
      String afterCursor = searchText.substring(cursorPos);
      searchDisplay = beforeCursor + "_" + beforeCursor;
    } else if (searchText.isEmpty()) {
      searchDisplay = searchPlaceholder;
    } else {
      searchDisplay = searchText;
    } 
    int searchTextColor = ZCoreGuiTheme.applyAlpha(
        this.searchEditor.getText().isEmpty() ? ZCoreGuiTheme.getDisabledTextColor() : ZCoreGuiTheme.getTextColor(), (int)(progress * 255.0F)) | 0xFF000000;
    
    context.method_51433(this.client.field_1772, searchDisplay, searchX + 2, searchY + 1, searchTextColor, false);

    
    List<String> filteredItems = getFilteredItems();
    int listY = searchY + 11 + 4;
    int listHeight = this.panelHeight - 15 - 11 - 14 - 16;
    int visibleItemsHeight = 54;
    int actualListHeight = Math.min(listHeight, visibleItemsHeight);
    
    context.method_44379(this.panelX, listY, this.panelX + 125, listY + actualListHeight);
    
    int yOffset = listY - this.scrollOffset;
    int maxScroll = Math.max(0, filteredItems.size() * 18 - actualListHeight);
    if (this.scrollOffset > maxScroll) this.scrollOffset = maxScroll;

    
    if (filteredItems.isEmpty()) {
      String itemName = (this.editingList != null) ? this.editingList.getName().toLowerCase() : "items";
      String emptyText = this.searchEditor.getText().isEmpty() ? ("No " + itemName + " yet") : ("No " + itemName + " found");
      int emptyTextX = this.panelX + (125 - this.client.field_1772.method_1727(emptyText)) / 2;
      int emptyTextY = listY + actualListHeight / 2 - 4;
      int emptyTextColor = ZCoreGuiTheme.applyAlpha(ZCoreGuiTheme.getDisabledTextColor(), (int)(progress * 255.0F)) | 0xFF000000;
      context.method_51433(this.client.field_1772, emptyText, emptyTextX, emptyTextY, emptyTextColor, false);
    } else {
      for (int i = 0; i < filteredItems.size(); i++) {
        if (yOffset + 14 < listY || yOffset > listY + actualListHeight) {
          yOffset += 18;
        }
        else {
          
          String item = filteredItems.get(i);
          String displayText = (item != null) ? item : "";

          
          int originalIndex = this.editingList.getList().indexOf(item);
          if (this.editingIndex == originalIndex) {
            String editorText = this.editingTextEditor.getText();
            int cursorPos = this.editingTextEditor.getCursorPosition();
            String beforeCursor = editorText.substring(0, cursorPos);
            String afterCursor = editorText.substring(cursorPos);
            displayText = beforeCursor + "_" + beforeCursor;
          } 
          
          int itemX = this.panelX + 4;
          int itemWidth = 113;
          int itemY = yOffset;
          
          boolean itemHovered = GuiUtils.isHovered(mouseX, mouseY, itemX, itemY, itemWidth, 14);
          boolean isEditing = (this.editingIndex == originalIndex);



          
          int itemBgColor = (isEditing || itemHovered) ? ZCoreGuiTheme.applyAlpha(ZCoreGuiTheme.getHoverColor(), progress * 0.2F) : ZCoreGuiTheme.applyAlpha(-13421773, progress * 0.2F);
          RenderUtils.fillRoundRect(context, itemX, itemY, itemWidth, 14, 4, itemBgColor);

          
          int headSize = 8;
          int headX = itemX + 4;
          int headY = itemY + 3;
          boolean headDrawn = false;
          
          if (item != null && !item.trim().isEmpty()) {
            try {
              String username = item.trim();
              String usernameLower = username.toLowerCase();
              class_2960 headTexture = this.headTextureCache.get(usernameLower);

              
              if (headTexture == null && !((Boolean)this.loadingHeads.getOrDefault(usernameLower, Boolean.valueOf(false))).booleanValue()) {
                this.loadingHeads.put(usernameLower, Boolean.valueOf(true));
                fetchHeadFromVZGE(username);
              } 

              
              if (headTexture != null) {
                RenderUtils.drawRoundTexture(context, headTexture, headX, headY, headSize, headSize, 2);
                headDrawn = true;
              } 
            } catch (Exception exception) {}
          }



          
          if (!headDrawn) {
            int placeholderColor = ZCoreGuiTheme.applyAlpha(-10066330, progress * 0.2F);
            RenderUtils.fillRoundRect(context, headX, headY, headSize, headSize, 2, placeholderColor);
          } 

          
          int textX = headX + headSize + 3;
          int textY = itemY + 3;
          int textColor = ZCoreGuiTheme.applyAlpha(ZCoreGuiTheme.getTextColor(), (int)(progress * 255.0F)) | 0xFF000000;
          int maxTextWidth = itemWidth - headSize - 3 - 22;
          String display = (displayText.length() > 20) ? (displayText.substring(0, 17) + "...") : displayText;
          if (this.client.field_1772.method_1727(display) > maxTextWidth) {
            display = this.client.field_1772.method_27523(display, maxTextWidth - this.client.field_1772.method_1727("...")) + "...";
          }
          context.method_51433(this.client.field_1772, display, textX, textY, textColor, false);

          
          int deleteButtonWidth = 20;
          int deleteButtonHeight = 12;
          int deleteButtonX = itemX + itemWidth - deleteButtonWidth - 2;
          int deleteButtonY = itemY + 1;
          boolean deleteHovered = GuiUtils.isHovered(mouseX, mouseY, deleteButtonX, deleteButtonY, deleteButtonWidth, deleteButtonHeight);

          
          int deleteBgColor = deleteHovered ? ZCoreGuiTheme.applyAlpha(ZCoreGuiTheme.getAccentColor(), progress * 0.8F) : ZCoreGuiTheme.applyAlpha(-13421773, progress * 0.2F);
          RenderUtils.fillRoundRect(context, deleteButtonX, deleteButtonY, deleteButtonWidth, deleteButtonHeight, 2, deleteBgColor);
          int deleteTextColor = ZCoreGuiTheme.applyAlpha(-1, (int)(progress * 255.0F)) | 0xFF000000;
          String deleteText = "×";
          int deleteTextX = deleteButtonX + (deleteButtonWidth - this.client.field_1772.method_1727(deleteText)) / 2;
          context.method_51433(this.client.field_1772, deleteText, deleteTextX, deleteButtonY + (deleteButtonHeight - 8) / 2, deleteTextColor, false);
          
          yOffset += 18;
        } 
      } 
    } 
    context.method_44380();

    
    int addButtonY = this.panelY + this.panelHeight - 14 - 4;
    int addButtonX = this.panelX + 4;
    int addButtonWidth = 117;
    boolean addHovered = GuiUtils.isHovered(mouseX, mouseY, addButtonX, addButtonY, addButtonWidth, 14);

    
    int addBgColor = addHovered ? ZCoreGuiTheme.applyAlpha(ZCoreGuiTheme.getAccentColor(), progress * 0.8F) : ZCoreGuiTheme.applyAlpha(-11184811, progress * 0.3F);
    RenderUtils.fillRoundRect(context, addButtonX, addButtonY, addButtonWidth, 14, 3, addBgColor);

    
    if (this.isAddingNew && this.editingTextEditor.isActive()) {
      String editorText = this.editingTextEditor.getText();
      int cursorPos = this.editingTextEditor.getCursorPosition();
      String beforeCursor = editorText.substring(0, cursorPos);
      String afterCursor = editorText.substring(cursorPos);
      addText = beforeCursor + "_" + beforeCursor;
    } else {
      addText = "Add";
    } 
    int addTextX = addButtonX + (addButtonWidth - this.client.field_1772.method_1727(addText)) / 2;
    int addTextY = addButtonY + 3;
    int addTextColor = ZCoreGuiTheme.applyAlpha(-1, (int)(progress * 255.0F)) | 0xFF000000;
    context.method_51433(this.client.field_1772, addText, addTextX, addTextY, addTextColor, false);

    
    if (filteredItems.size() > 3 && maxScroll > 0) {
      int scrollbarX = this.panelX + 125 - 4;
      int scrollbarY = listY;
      int scrollbarWidth = 2;
      int scrollbarHeight = actualListHeight;
      int scrollbarBgColor = ZCoreGuiTheme.applyAlpha(-13421773, progress * 0.3F);
      RenderUtils.fillRoundRect(context, scrollbarX, scrollbarY, scrollbarWidth, scrollbarHeight, 1, scrollbarBgColor);
      
      int thumbHeight = Math.max(10, (int)(actualListHeight / filteredItems.size() * 3.0D));
      int thumbY = scrollbarY + (int)(this.scrollOffset / maxScroll * (scrollbarHeight - thumbHeight));
      int thumbColor = ZCoreGuiTheme.applyAlpha(ZCoreGuiTheme.getAccentColor(), progress * 0.8F);
      RenderUtils.fillRoundRect(context, scrollbarX, thumbY, scrollbarWidth, thumbHeight, 1, thumbColor);
    } 
  }
  
  public boolean handleClick(double mx, double my, int button) {
    if (this.editingList == null) return false;

    
    int closeButtonX = this.panelX + 125 - 9;
    int closeButtonY = this.panelY + 5;
    if (GuiUtils.isHovered(mx, my, closeButtonX - 2, closeButtonY, 7, 5)) {
      this.editingList = null;
      this.editingIndex = -1;
      this.editingTextEditor.setText("");
      this.editingTextEditor.stopEditing();
      this.isAddingNew = false;
      this.searchEditor.setText("");
      this.searchEditor.stopEditing();
      return true;
    } 

    
    if (button == 0 && GuiUtils.isHovered(mx, my, this.panelX, this.panelY, 116, 15)) {
      this.dragHandler.startDrag(mx, my, this.panelX, this.panelY);
      return true;
    } 

    
    int searchY = this.panelY + 15 + 4;
    int searchX = this.panelX + 4;
    int searchWidth = 117;
    if (GuiUtils.isHovered(mx, my, searchX, searchY, searchWidth, 11)) {
      this.searchEditor.startEditing(this.searchEditor.getText());
      this.isAddingNew = false;
      this.editingIndex = -1;
      return true;
    } 

    
    List<String> filteredItems = getFilteredItems();
    int listY = searchY + 11 + 4;
    int listHeight = this.panelHeight - 15 - 11 - 14 - 16;
    int visibleItemsHeight = 54;
    int actualListHeight = Math.min(listHeight, visibleItemsHeight);
    int itemStartY = listY - this.scrollOffset;
    
    for (int i = 0; i < filteredItems.size(); i++) {
      int itemY = itemStartY + i * 18;
      if (itemY + 14 >= listY && itemY <= listY + actualListHeight) {
        
        String item = filteredItems.get(i);
        int originalIndex = this.editingList.getList().indexOf(item);
        
        int itemX = this.panelX + 4;
        int itemWidth = 113;
        int deleteButtonWidth = 20;
        int deleteButtonHeight = 12;
        int deleteButtonX = itemX + itemWidth - deleteButtonWidth - 2;
        int deleteButtonY = itemY + 1;

        
        if (GuiUtils.isHovered(mx, my, deleteButtonX, deleteButtonY, deleteButtonWidth, deleteButtonHeight)) {
          this.editingList.remove(originalIndex);
          if (this.editingIndex == originalIndex) {
            this.editingIndex = -1;
            this.editingTextEditor.setText("");
            this.editingTextEditor.stopEditing();
          } else if (this.editingIndex > originalIndex) {
            this.editingIndex--;
          } 
          updatePanelHeight();
          return true;
        } 

        
        int headSize = 11;
        int clickAreaX = itemX + headSize + 3;
        int clickAreaWidth = itemWidth - headSize - 3 - deleteButtonWidth - 3;
        if (GuiUtils.isHovered(mx, my, clickAreaX, itemY, clickAreaWidth, 14)) {
          this.editingIndex = originalIndex;
          this.editingTextEditor.startEditing((item != null) ? item : "");
          this.isAddingNew = false;
          this.searchEditor.stopEditing();
          return true;
        } 
      } 
    } 
    
    int addButtonY = this.panelY + this.panelHeight - 14 - 4;
    int addButtonX = this.panelX + 4;
    int addButtonWidth = 117;
    if (GuiUtils.isHovered(mx, my, addButtonX, addButtonY, addButtonWidth, 14)) {
      if (this.isAddingNew) {
        String text = this.editingTextEditor.getText().trim();
        if (!text.isEmpty()) {
          this.editingList.add(text);
          updatePanelHeight();
        } 
        this.isAddingNew = false;
        this.editingTextEditor.setText("");
        this.editingTextEditor.stopEditing();
      } else {
        this.isAddingNew = true;
        this.editingIndex = -1;
        this.editingTextEditor.setText("");
        this.editingTextEditor.startEditing("");
        this.searchEditor.stopEditing();
      } 
      return true;
    } 

    
    if (this.searchEditor.isActive() && !GuiUtils.isHovered(mx, my, searchX, searchY, searchWidth, 11)) {
      this.searchEditor.stopEditing();
    }
    
    return GuiUtils.isHovered(mx, my, this.panelX, this.panelY, 125, this.panelHeight);
  }
  
  public boolean handleScroll(double mx, double my, double hAmount, double vAmount) {
    if (this.editingList == null) return false; 
    int searchY = this.panelY + 15 + 4;
    int listY = searchY + 11 + 4;
    int listHeight = this.panelHeight - 15 - 11 - 14 - 16;
    int visibleItemsHeight = 54;
    int actualListHeight = Math.min(listHeight, visibleItemsHeight);
    
    if (!GuiUtils.isHovered(mx, my, this.panelX, listY, 125, actualListHeight)) {
      return false;
    }
    
    List<String> filteredItems = getFilteredItems();
    int maxScroll = Math.max(0, filteredItems.size() * 18 - actualListHeight);
    this.scrollOffset = (int)(this.scrollOffset - vAmount * 15.0D);
    if (this.scrollOffset < 0) this.scrollOffset = 0; 
    if (this.scrollOffset > maxScroll) this.scrollOffset = maxScroll; 
    return true;
  }
  
  public boolean handleDrag(double mx, double my, int button, double dx, double dy) {
    if (this.editingList == null) return false;
    
    if (this.dragHandler.isDragging()) {
      this.dragHandler.updatePosition(mx, my);
      return true;
    } 
    
    return false;
  }
  
  public boolean handleRelease(double mx, double my, int button) {
    if (button == 0) {
      this.dragHandler.stopDrag();
    }
    return false;
  }
  
  public boolean handleKeyPress(int keyCode, int scanCode, int modifiers) {
    if (this.editingList == null) return false;

    
    if (this.searchEditor.isActive()) {
      if (this.searchEditor.handleKeyPress(keyCode, scanCode, modifiers)) {
        if (keyCode == 256) {
          this.searchEditor.setText("");
        }
        return true;
      } 
      return false;
    } 

    
    if (this.editingIndex == -1 && !this.isAddingNew) return false; 
    if (!this.editingTextEditor.isActive()) return false;
    
    if (this.editingTextEditor.handleKeyPress(keyCode, scanCode, modifiers)) {
      if (keyCode == 256) {
        this.editingIndex = -1;
        this.isAddingNew = false;
        this.editingTextEditor.cancelEditing();
      } else if (keyCode == 257) {
        String text = this.editingTextEditor.getText().trim();
        if (this.isAddingNew) {
          if (!text.isEmpty()) {
            this.editingList.add(text);
            updatePanelHeight();
          } 
          this.isAddingNew = false;
          this.editingTextEditor.stopEditing();
        } else if (this.editingIndex >= 0) {
          if (this.editingIndex < this.editingList.size()) {
            if (!text.isEmpty()) {
              this.editingList.set(this.editingIndex, text);
            } else {
              this.editingList.remove(this.editingIndex);
              updatePanelHeight();
            } 
          }
          this.editingIndex = -1;
          this.editingTextEditor.stopEditing();
        } 
      } 
      return true;
    } 
    
    return false;
  }
  
  public boolean handleCharType(char chr, int modifiers) {
    if (this.editingList == null) return false;

    
    if (this.searchEditor.isActive()) {
      if (this.searchEditor.handleCharType(chr, modifiers)) {
        this.scrollOffset = 0;
        return true;
      } 
      return false;
    } 

    
    if (this.editingIndex == -1 && !this.isAddingNew) return false; 
    if (!this.editingTextEditor.isActive()) return false;
    
    return this.editingTextEditor.handleCharType(chr, modifiers);
  }
  
  public boolean isOpen() {
    return (this.editingList != null);
  }
  
  private void fetchHeadFromVZGE(String username) {
    if (username == null || username.trim().isEmpty())
      return; 
    CompletableFuture.runAsync(() -> {
          try {
            String url = "https://minotar.net/helm/" + username + "/64.png";

            
            HttpURLConnection connection = (HttpURLConnection)(new URL(url)).openConnection();
            
            connection.setRequestMethod("GET");
            
            connection.setRequestProperty("User-Agent", "ZCoreClient/1.0 (+https://zcoreclient.com)");
            
            connection.setConnectTimeout(5000);
            
            connection.setReadTimeout(5000);
            
            if (connection.getResponseCode() != 200) {
              this.loadingHeads.remove(username.toLowerCase());
              
              return;
            } 
            
            InputStream inputStream = connection.getInputStream();
            
            class_1011 image = class_1011.method_4309(inputStream);
            
            inputStream.close();
            
            class_2960 textureId = class_2960.method_60655("zcore", "friends/heads/" + username.toLowerCase());
            
            this.client.execute(());
          } catch (Exception e) {
            this.loadingHeads.remove(username.toLowerCase());
          } 
        });
  }
}


